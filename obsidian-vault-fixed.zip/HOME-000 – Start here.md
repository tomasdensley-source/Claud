# Home

Welcome to your vault. Use the folders below to organise your notes.

- [[00_Inbox]] — Triage and capture
- [[01_Daily]] — Daily notes
- [[02_Action]] — Projects and tasks
- [[03_Notes]] — Concepts and ideas
- [[04_Maps]] — Maps of content / hubs
- [[05_Sources]] — Books, articles, PDFs
- [[06_Reference]] — Reference material
- [[07_Persona]] — People and contacts
- [[08_System]] — System and config notes
- [[90_Archive]] — Archived items
- [[99_Templates]] — Note templates
- [[_Assets]] — Images and attachments

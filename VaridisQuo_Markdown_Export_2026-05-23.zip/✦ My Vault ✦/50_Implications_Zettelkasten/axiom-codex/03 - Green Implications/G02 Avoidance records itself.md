---
class: A
tags:
  - Inaction As Stance
---
# G02 Avoidance records itself

## Assertion
Avoidance records itself because the refusal to act is still a witnessed position.

## Upward Abstraction Link
[[B02b Refusal Becomes a Recorded Position]]
[[O02 Awareness Equals Enlistment]]

---
class: A
tags:
  - Many-Voices One-Deeper-Saying
---
# G Plausibility Can Replace Accuracy - Convergence

## Assertion
Plausibility Can Replace Accuracy exists because several implications say the same deeper thing.

## Upward Abstraction Link
[[B04 Plausibility Can Replace Accuracy]]

---
class: A
tags:
  - administrative-precursor-symptom
---
# G05 Paperwork Is the First Bleed

## Assertion
Paperwork is the first bleed when the failing category announces itself administratively before it announces itself violently.

## Upward Abstraction Links
[[B05d Backrooms Externalize Unmaintained Categories]]
[[O05 The Anemurge Stands Behind All Local Apparatus]]

---
class: A
tags:
  - Flesh Retains Unsettled Debt
  - Tertiary Grounding Step
---
# G13c Embodied Marks Preserve Account - Third Ground

## Assertion
Embodied marks preserve account because the body carries what the mind cannot fully discharge. This is the third grounded implication converging into the assertion.

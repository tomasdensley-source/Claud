---
class: A
tags:
  - self-supplied-repair-trap
---
# G05 Exit Requires More Than Internal Correction

## Assertion
Exit requires more than internal correction when the system needing repair supplies the tools of repair.

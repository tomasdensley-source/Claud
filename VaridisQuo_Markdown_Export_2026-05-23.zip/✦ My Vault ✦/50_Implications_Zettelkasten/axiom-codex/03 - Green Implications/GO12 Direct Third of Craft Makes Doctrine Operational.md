---
class: A
tags:
  - skill-actualized-teaching
  - third-derivable-offspring
---
# GO12 Direct Third of Craft Makes Doctrine Operational

## Assertion
Craft makes doctrine operational. Therefore its third immediate implication can be carried as a child of the assertion.

## Upward Abstraction Links
[[O12 Craft Makes Doctrine Operational]]

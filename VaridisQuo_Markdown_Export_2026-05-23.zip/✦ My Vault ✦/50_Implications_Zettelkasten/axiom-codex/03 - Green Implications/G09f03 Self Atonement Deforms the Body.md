---
class: A
tags:
  - uncontained-weight-distortion
---
# G09f03 Self Atonement Deforms the Body

## Assertion
Self atonement deforms the body because the creature tries to carry world-weight without the category that can hold it.

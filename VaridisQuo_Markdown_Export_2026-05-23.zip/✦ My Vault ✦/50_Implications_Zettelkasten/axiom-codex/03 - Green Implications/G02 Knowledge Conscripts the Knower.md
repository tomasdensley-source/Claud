---
class: A
tags:
  - Knowing Compels Response
---
# G02 Knowledge Conscripts the Knower

## Assertion
Knowledge conscripts the knower because known reality demands a response from the one who knows.

## Upward Abstraction Link
[[O02 Awareness Equals Enlistment]]

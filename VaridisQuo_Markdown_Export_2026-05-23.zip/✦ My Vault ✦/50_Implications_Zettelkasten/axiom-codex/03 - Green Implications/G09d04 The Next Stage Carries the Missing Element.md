---
class: A
tags:
  - upward-exported-flaw
---
# G09d04 The Next Stage Carries the Missing Element

## Assertion
The next stage carries the missing element because every uncompleted transformation exports its flaw upward.

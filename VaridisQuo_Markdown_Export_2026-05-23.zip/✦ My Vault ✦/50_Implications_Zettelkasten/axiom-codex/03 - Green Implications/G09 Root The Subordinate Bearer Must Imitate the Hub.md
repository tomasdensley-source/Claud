---
class: A
tags:
  - Lesser-Bearer Mimics Center
---
# G09 Root The Subordinate Bearer Must Imitate the Hub

## Assertion
The subordinate bearer must imitate the Hub because Part 9 asks what a lesser bearer must do after the opened center has been named.

## Upward Abstraction Link
[[O09 The Cornerstone Choice Mirrors the Hub]]

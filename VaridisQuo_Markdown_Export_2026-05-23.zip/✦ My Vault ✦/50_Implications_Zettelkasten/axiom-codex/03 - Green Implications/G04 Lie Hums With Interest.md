---
class: A
tags:
  - Deferred Truth Accrues Charge
---
# G04 Lie Hums With Interest

## Assertion
Lie hums with interest because delayed truth continues to charge the self that tried to avoid it.

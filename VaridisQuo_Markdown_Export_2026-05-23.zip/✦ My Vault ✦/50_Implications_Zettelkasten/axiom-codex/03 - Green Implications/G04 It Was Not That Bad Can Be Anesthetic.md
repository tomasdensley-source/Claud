---
class: A
tags:
  - premature-harm-minimization
---
# G04 It Was Not That Bad Can Be Anesthetic

## Assertion
It was not that bad can be anesthetic when it lowers the felt cost of harm before the harm has been measured.

---
class: A
tags:
  - Refusal Hardens Normalcy
---
# G03 Not Seeing Becomes Installed

## Assertion
Not-seeing becomes installed when repeated refusal hardens into an apparatus that feels normal.

---
class: A
tags:
  - Shared-Depth Restatement
---
# G Distinction Enters the Record - Convergence

## Assertion
Distinction Enters the Record exists because several implications say the same deeper thing.

## Upward Abstraction Link
[[B01a Distinction Enters the Record]]

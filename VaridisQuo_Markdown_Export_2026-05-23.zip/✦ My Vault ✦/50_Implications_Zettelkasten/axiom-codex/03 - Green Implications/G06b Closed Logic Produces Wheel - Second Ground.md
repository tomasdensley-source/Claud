---
class: A
tags:
  - Frame-Trapped Recursion
  - Paired-Footing Merge
---
# G06b Closed Logic Produces Wheel - Second Ground

## Assertion
Closed logic produces the wheel because reason inside its own frame cannot supply an outside. This is the second grounded implication converging into the assertion.

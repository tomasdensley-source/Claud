---
class: A
tags:
  - Source-Exclusion Falsifier
---
# G09e04 The Specific Source Tests Universal Charity

## Assertion
The specific source tests universal charity because love for humanity remains unproven when the father-source is excluded.

---
class: A
tags:
  - Measured-Tone Denial
---
# G03 The Wall Is Made of Reasonable Explanations

## Assertion
The Wall is made of reasonable explanations because denial survives best when it sounds measured.

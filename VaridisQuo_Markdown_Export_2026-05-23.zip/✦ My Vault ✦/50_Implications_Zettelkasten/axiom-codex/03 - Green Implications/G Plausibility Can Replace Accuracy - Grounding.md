---
class: A
tags:
  - No-External-Premise Validity
---
# G Plausibility Can Replace Accuracy - Grounding

## Assertion
Plausibility Can Replace Accuracy is valid only when its children need no premise outside the parent meaning.

## Upward Abstraction Link
[[B04 Plausibility Can Replace Accuracy]]

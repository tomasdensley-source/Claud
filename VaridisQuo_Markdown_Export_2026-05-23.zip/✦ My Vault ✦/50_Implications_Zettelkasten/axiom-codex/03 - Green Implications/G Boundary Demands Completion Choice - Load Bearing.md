---
class: A
tags:
  - vagueness-free-weight-carrying
---
# G Boundary Demands Completion Choice - Load Bearing

## Assertion
Boundary Demands Completion Choice must carry the weight of its children without vagueness.

## Upward Abstraction Link
[[B14 Boundary Demands Completion Choice]]

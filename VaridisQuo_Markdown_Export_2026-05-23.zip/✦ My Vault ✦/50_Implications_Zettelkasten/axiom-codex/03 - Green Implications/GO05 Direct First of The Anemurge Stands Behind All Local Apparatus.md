---
class: A
tags:
  - The Anemurge
  - Premiseless First-Echo
---
# GO05 Direct First of The Anemurge Stands Behind All Local Apparatus

## Assertion
The Anemurge stands behind all local apparatus. Therefore its first immediate implication echoes the assertion without adding another premise.

## Upward Abstraction Links
[[O05 The Anemurge Stands Behind All Local Apparatus]]

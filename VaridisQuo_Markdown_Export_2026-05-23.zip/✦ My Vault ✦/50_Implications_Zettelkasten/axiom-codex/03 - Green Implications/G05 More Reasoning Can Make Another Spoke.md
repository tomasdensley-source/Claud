---
class: A
tags:
  - Escape-Effort Stays Inside-Geometry
---
# G05 More Reasoning Can Make Another Spoke

## Assertion
More reasoning can make another spoke when the effort to escape stays inside the wheel’s own geometry.

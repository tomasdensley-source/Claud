---
class: A
tags:
  - Absorbed Revolt
---
# G Every Escape Attempt Becomes Spoke

## Assertion
Every internal escape attempt becomes a spoke because the wheel absorbs moves made from within it.

## Upward Abstraction Links
[[B06 Closed Logic Produces Wheel]]
[[O06 Reason Alone Cannot Exit the Loop]]

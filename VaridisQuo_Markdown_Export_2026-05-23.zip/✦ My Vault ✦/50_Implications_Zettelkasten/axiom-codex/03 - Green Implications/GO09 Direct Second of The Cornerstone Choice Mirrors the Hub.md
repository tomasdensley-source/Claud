---
class: A
tags:
  - Subordinate Echoes Hub-Choice
  - Second-Implication Inheritance
---
# GO09 Direct Second of The Cornerstone Choice Mirrors the Hub

## Assertion
The cornerstone choice for any subordinate being is the choice the hub itself made. Therefore its second immediate implication remains true from the assertion itself.

## Upward Abstraction Links
[[O09 The Cornerstone Choice Mirrors the Hub]]

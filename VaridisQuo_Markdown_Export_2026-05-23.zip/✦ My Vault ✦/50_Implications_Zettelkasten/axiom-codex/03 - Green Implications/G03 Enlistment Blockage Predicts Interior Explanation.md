---
class: A
tags:
  - Avoidance-Livability Story
---
# G03 Enlistment Blockage Predicts Interior Explanation

## Assertion
Enlistment blockage predicts interior explanation because avoided obligation requires a story that makes avoidance livable.

---
class: A
tags:
  - Abstraction Yields Extra Downstream
---
# GX Continued Implication 005 for B01d Lies Move Load Downstream

## Assertion
B01d Lies Move Load Downstream generates an additional downstream consequence when its assertion is treated as a load-bearing abstraction rather than a decorative summary.

## Upward Abstraction Link
[[B01d Lies Move Load Downstream]]

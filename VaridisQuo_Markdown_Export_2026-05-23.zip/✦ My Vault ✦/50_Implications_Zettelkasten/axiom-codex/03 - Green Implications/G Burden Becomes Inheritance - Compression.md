---
class: A
tags:
  - Child-Claim Condensation
---
# G Burden Becomes Inheritance - Compression

## Assertion
Burden Becomes Inheritance compresses multiple child claims into one cleaner parent assertion.

## Upward Abstraction Link
[[B11 Burden Becomes Inheritance]]

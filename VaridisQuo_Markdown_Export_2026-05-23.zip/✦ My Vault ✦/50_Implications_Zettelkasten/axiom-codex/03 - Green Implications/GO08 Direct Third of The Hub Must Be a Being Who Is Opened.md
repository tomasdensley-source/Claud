---
class: A
tags:
  - opened-personal-center
  - tertiary-inheritable-claim
---
# GO08 Direct Third of The Hub Must Be a Being Who Is Opened

## Assertion
The hub must be a being who is opened. Therefore its third immediate implication can be carried as a child of the assertion.

## Upward Abstraction Links
[[O08 The Hub Must Be a Being Who Is Opened]]

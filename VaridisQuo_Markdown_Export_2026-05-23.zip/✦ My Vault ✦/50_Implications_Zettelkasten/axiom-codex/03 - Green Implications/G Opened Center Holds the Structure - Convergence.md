---
class: A
tags:
  - Shared-Depth Echo Origin
---
# G Opened Center Holds the Structure - Convergence

## Assertion
Opened Center Holds the Structure exists because several implications say the same deeper thing.

## Upward Abstraction Link
[[B08 Opened Center Holds the Structure]]

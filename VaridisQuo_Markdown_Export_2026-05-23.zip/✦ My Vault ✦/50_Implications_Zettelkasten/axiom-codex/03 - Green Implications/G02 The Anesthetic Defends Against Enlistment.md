---
class: A
tags:
  - Cost-Avoidance Shield
---
# G02 The Anesthetic Defends Against Enlistment

## Assertion
The Anesthetic defends against enlistment because awareness has a real cost that the self may try to avoid.

## Upward Abstraction Link
[[O02 Awareness Equals Enlistment]]

---
class: A
tags:
  - sextuple-perception-naming
---
# G02 Six Laws Name the Awareness Field

## Assertion
The six laws name the awareness field because they describe how seen reality binds, fades, explains, weighs, shames, and listens.

## Upward Abstraction Link
[[O02 Awareness Equals Enlistment]]

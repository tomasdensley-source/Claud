---
class: A
tags:
  - Parent Sustains Offspring-Weight
---
# G Recurrent Convergence Warrants Trust - Load Bearing

## Assertion
Recurrent Convergence Warrants Trust must carry the weight of its children without vagueness.

## Upward Abstraction Link
[[B10 Recurrent Convergence Warrants Trust]]

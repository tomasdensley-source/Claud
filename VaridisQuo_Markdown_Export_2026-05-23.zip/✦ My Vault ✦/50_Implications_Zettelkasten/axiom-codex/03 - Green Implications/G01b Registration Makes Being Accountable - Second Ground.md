---
class: A
tags:
  - identifiability-induces-liability
  - second-grounded-implication
---
# G01b Registration Makes Being Accountable - Second Ground

## Assertion
Registration makes being accountable because distinguishability enters a thing into obligation. This is the second grounded implication converging into the assertion.

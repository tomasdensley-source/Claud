---
class: A
tags:
  - rigor-trapped-inside-frame
---
# G The Exit Is Not Higher Logic

## Assertion
The exit is not higher logic because deeper rigor remains inside the same frame.

## Upward Abstraction Links
[[B07 The Needed Exit Must Be Other]]
[[O07 The Exit Must Be Ontological]]

---
class: A
tags:
  - Excuse Binds Next-Refusal
---
# G03 Plausible Deniability Mortars the Wall

## Assertion
Plausible deniability mortars the Wall because each reasonable excuse binds the next refusal into structure.

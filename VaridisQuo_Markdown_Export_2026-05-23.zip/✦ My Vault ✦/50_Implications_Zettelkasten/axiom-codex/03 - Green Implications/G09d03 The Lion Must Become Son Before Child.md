---
class: A
tags:
  - Ordered Healing Sequence
---
# G09d03 The Lion Must Become Son Before Child

## Assertion
The lion must become son before child because the source relation must be healed before free creation can become clean.

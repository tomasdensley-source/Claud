---
class: A
tags:
  - Numbing Disclaimer
---
# G04 You Did Not Mean It Can Be Anesthetic

## Assertion
You did not mean it can be anesthetic when it reduces responsibility without clarifying intention.

---
class: A
tags:
  - stimulus-bought-deafness
---
# G03 Noise Purchases Numbness

## Assertion
Noise purchases numbness because surplus stimulation prevents the question from becoming audible.

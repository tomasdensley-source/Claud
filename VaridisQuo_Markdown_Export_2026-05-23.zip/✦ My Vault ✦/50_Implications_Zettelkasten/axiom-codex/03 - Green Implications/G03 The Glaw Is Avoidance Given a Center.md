---
class: A
tags:
  - centered-evasion-organizer
---
# G03 The Glaw Is Avoidance Given a Center

## Assertion
The Glaw is avoidance given a center because an ignored fault becomes the hidden organizer of behavior.

---
class: A
tags:
  - Knowing Incurs Owing
---
# GO01 Direct First of Existence is Accountability

## Assertion
Knowing creates owing because perceived truth becomes registered constraint.

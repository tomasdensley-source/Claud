---
class: A
tags:
  - Motion-Outpaced Duty
---
# G03 Speed Outruns the Question

## Assertion
Speed outruns the question because motion can keep awareness from gathering into obligation.

---
class: A
tags:
  - Comfort Defers Payment
---
# G04 Reassurance Can Invoice the Self

## Assertion
Reassurance can invoice the self when comfort now becomes deferred payment against clear seeing later.

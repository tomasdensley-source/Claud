---
class: A
tags:
  - Motion Substitutes Meaning
---
# G05 Corridors Repeat Without Arrival

## Assertion
Corridors repeat without arrival when movement substitutes for maintained meaning.

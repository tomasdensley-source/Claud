---
class: A
tags:
  - Non-Contradictory Backflow
---
# G Boundary Demands Completion Choice - Return Test

## Assertion
Boundary Demands Completion Choice can imply its children back without contradiction.

## Upward Abstraction Link
[[B14 Boundary Demands Completion Choice]]

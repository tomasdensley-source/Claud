---
class: A
tags:
  - weight-bearing-descent
  - third-carriable-child
---
# GO11 Direct Third of Burden Creates Lineage

## Assertion
The burdened become a lineage when they receive and carry accountable weight. Therefore its third immediate implication can be carried as a child of the assertion.

## Upward Abstraction Links
[[O11 Burden Creates Lineage]]

---
class: A
tags:
  - Implicated Witness
---
# G There Is No Neutral Observation

## Assertion
There is no neutral observation because the witness is already party to what has been seen.

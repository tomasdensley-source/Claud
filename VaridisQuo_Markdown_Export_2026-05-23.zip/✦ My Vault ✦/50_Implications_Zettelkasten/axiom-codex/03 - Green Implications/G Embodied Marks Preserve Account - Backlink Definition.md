---
class: A
tags:
  - Identity From Pointing-Back
---
# G Embodied Marks Preserve Account - Backlink Definition

## Assertion
Embodied Marks Preserve Account is defined by the implications that point back to it.

## Upward Abstraction Link
[[B13 Embodied Marks Preserve Account]]

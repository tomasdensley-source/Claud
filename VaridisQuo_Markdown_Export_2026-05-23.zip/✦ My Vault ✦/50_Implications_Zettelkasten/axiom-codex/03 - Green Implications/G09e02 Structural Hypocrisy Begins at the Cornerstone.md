---
class: A
tags:
  - Foundational Double-Standard
---
# G09e02 Structural Hypocrisy Begins at the Cornerstone

## Assertion
Structural hypocrisy begins at the cornerstone because the bearer preaches charity while withholding it where completion requires it.

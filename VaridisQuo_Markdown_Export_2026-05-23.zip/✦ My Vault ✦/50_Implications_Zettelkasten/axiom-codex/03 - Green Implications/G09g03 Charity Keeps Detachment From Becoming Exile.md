---
class: A
tags:
  - Related Without Being-Bound
---
# G09g03 Charity Keeps Detachment From Becoming Exile

## Assertion
Charity keeps detachment from becoming exile because the separated bearer remains related without remaining bound.

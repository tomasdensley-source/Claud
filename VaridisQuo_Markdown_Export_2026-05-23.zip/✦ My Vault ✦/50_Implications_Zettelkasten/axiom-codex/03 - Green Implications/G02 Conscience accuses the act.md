---
class: A
tags:
  - Guilt-Pointing Repair-Finder
---
# G02 Conscience accuses the act

## Assertion
Conscience accuses the act because guilt can identify what must be repaired.

## Upward Abstraction Link
[[B02e Shame Counterfeits Conscience]]
[[O02 Awareness Equals Enlistment]]

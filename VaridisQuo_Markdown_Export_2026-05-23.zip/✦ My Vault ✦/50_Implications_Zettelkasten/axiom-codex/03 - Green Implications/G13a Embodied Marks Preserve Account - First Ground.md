---
class: A
tags:
  - Body Holds Undischarged Residue
  - Initial Grounding Step
---
# G13a Embodied Marks Preserve Account - First Ground

## Assertion
Embodied marks preserve account because the body carries what the mind cannot fully discharge. This is the first grounded implication converging into the assertion.

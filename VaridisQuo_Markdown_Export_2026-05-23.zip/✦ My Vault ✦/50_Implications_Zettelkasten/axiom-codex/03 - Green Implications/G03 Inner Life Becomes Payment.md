---
class: A
tags:
  - Felt-Experience Services Awareness
---
# G03 Inner Life Becomes Payment

## Assertion
Inner life becomes payment when most felt experience is spent servicing unaddressed awareness.

---
class: A
tags:
  - Irreversible Witness
---
# G02 Looking becomes a position

## Assertion
Looking becomes a position because the witness cannot return to untouched ignorance.

---
class: A
tags:
  - contradiction-free-backward-implication
---
# G Neglected Distinction Evaporates - Return Test

## Assertion
Neglected Distinction Evaporates can imply its children back without contradiction.

## Upward Abstraction Link
[[B05 Neglected Distinction Evaporates]]

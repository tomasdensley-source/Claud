---
class: A
tags:
  - Meaning Via Referring Implications
---
# G Vocation Imitates the Opened Hub - Backlink Definition

## Assertion
Vocation Imitates the Opened Hub is defined by the implications that point back to it.

## Upward Abstraction Link
[[B09 Vocation Imitates the Opened Hub]]

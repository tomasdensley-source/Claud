---
class: A
tags:
  - Self-Contained Parentage
---
# G Perception Enlists the Knower - Grounding

## Assertion
Perception Enlists the Knower is valid only when its children need no premise outside the parent meaning.

## Upward Abstraction Link
[[B01b Perception Enlists the Knower]]

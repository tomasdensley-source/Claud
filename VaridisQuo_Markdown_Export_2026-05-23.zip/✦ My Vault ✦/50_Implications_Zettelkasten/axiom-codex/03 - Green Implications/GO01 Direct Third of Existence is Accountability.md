---
class: A
tags:
  - Downstream Cost Shunt
---
# GO01 Direct Third of Existence is Accountability

## Assertion
Lies redistribute load because denied truth sends its cost downstream instead of destroying it.

---
class: A
tags:
  - Refuse-And-Love Pair
---
# G09a02 The Bearer Needs Two Directed Motions

## Assertion
The bearer needs two directed motions because the world must be refused as false claim while the source must be loved as origin.

---
class: A
tags:
  - multiplicity-into-parent
---
# G Perception Enlists the Knower - Compression

## Assertion
Perception Enlists the Knower compresses multiple child claims into one cleaner parent assertion.

## Upward Abstraction Link
[[B01b Perception Enlists the Knower]]

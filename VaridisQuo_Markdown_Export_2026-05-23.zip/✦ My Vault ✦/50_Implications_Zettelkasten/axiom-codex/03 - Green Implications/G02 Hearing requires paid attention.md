---
class: A
tags:
  - Unsimulatable Listening Toll
---
# G02 Hearing requires paid attention

## Assertion
Hearing requires paid attention because listening cannot be simulated by mere sound contact.

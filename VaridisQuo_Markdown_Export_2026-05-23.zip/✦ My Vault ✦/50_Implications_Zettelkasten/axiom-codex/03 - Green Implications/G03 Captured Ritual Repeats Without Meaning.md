---
class: A
tags:
  - Form Persists Past Attention
---
# G03 Captured Ritual Repeats Without Meaning

## Assertion
Captured ritual repeats without meaning when the form continues after attention has withdrawn.

---
class: A
tags:
  - Self-Rescue Impossibility
  - Triple-Ground Confluence
---
# G07c The Needed Exit Must Be Other - Third Ground

## Assertion
The needed exit must be other because a system cannot rescue itself by adding another internal spoke. This is the third grounded implication converging into the assertion.

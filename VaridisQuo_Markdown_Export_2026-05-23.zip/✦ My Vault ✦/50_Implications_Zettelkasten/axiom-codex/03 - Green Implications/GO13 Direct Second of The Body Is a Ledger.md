---
class: A
tags:
  - corporeal-accounting-record
  - second-self-evident-entailment
---
# GO13 Direct Second of The Body Is a Ledger

## Assertion
The body is a ledger. Therefore its second immediate implication remains true from the assertion itself.

## Upward Abstraction Links
[[O13 The Body Is a Ledger]]

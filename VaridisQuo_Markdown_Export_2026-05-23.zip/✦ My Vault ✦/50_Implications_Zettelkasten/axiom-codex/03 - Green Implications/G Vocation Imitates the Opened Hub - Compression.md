---
class: A
tags:
  - Child-Claim Compaction
---
# G Vocation Imitates the Opened Hub - Compression

## Assertion
Vocation Imitates the Opened Hub compresses multiple child claims into one cleaner parent assertion.

## Upward Abstraction Link
[[B09 Vocation Imitates the Opened Hub]]

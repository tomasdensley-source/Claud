---
class: A
tags:
  - disclosed-duty-inaction-cost
---
# G02 Inaction carries debit when awareness has already disclosed an obligation.

## Assertion
Inaction carries debit when awareness has already disclosed an obligation.

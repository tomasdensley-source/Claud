---
class: A
tags:
  - Anti-Fog Upkeep
---
# G05 Distinctions Require Energy

## Assertion
Distinctions require energy because separation must be continually renewed against fog.

## Upward Abstraction Links
[[B05a Attention Maintains Distinction]]
[[O05 The Anemurge Stands Behind All Local Apparatus]]

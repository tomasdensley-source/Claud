---
class: A
tags:
  - inbound-implication-self-definition
---
# G Perception Enlists the Knower - Backlink Definition

## Assertion
Perception Enlists the Knower is defined by the implications that point back to it.

## Upward Abstraction Link
[[B01b Perception Enlists the Knower]]

---
class: A
tags:
  - elected-form-finishing
  - second-self-standing-entailment
---
# GO14 Direct Second of Boundary Completion Requires Chosen Form

## Assertion
Boundary completion requires a chosen form. Therefore its second immediate implication remains true from the assertion itself.

## Upward Abstraction Links
[[O14 Boundary Completion Requires Chosen Form]]

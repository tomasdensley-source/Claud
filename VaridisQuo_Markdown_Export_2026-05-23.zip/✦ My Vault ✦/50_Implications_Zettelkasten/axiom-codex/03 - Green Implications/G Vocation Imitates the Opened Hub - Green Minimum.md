---
class: A
tags:
  - trio-prerequisite-for-blue
---
# G Vocation Imitates the Opened Hub - Green Minimum

## Assertion
Vocation Imitates the Opened Hub requires at least three green implications before blue status is justified.

## Upward Abstraction Link
[[B09 Vocation Imitates the Opened Hub]]

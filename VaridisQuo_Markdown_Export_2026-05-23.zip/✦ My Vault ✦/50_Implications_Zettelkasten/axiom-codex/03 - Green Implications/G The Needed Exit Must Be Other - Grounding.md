---
class: A
tags:
  - no-external-premise-validity
---
# G The Needed Exit Must Be Other - Grounding

## Assertion
The Needed Exit Must Be Other is valid only when its children need no premise outside the parent meaning.

## Upward Abstraction Link
[[B07 The Needed Exit Must Be Other]]

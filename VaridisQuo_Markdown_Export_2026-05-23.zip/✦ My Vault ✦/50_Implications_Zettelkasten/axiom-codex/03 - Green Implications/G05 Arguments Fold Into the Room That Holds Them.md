---
class: A
tags:
  - Container-Shaped Reasoning
---
# G05 Arguments Fold Into the Room That Holds Them

## Assertion
Arguments fold into the room that holds them when the loop shapes the reasoning performed inside it.

## Upward Abstraction Links
[[B05f Hollowed Reason Cannot Exit the Loop]]
[[O05 The Anemurge Stands Behind All Local Apparatus]]
[[O06 Reason Alone Cannot Exit the Loop]]

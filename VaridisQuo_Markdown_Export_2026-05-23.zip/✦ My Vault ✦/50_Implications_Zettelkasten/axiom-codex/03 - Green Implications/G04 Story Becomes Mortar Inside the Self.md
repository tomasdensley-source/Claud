---
class: A
tags:
  - Explanation Hardens Avoidance-Structure
---
# G04 Story Becomes Mortar Inside the Self

## Assertion
Story becomes mortar inside the self when repeated explanation hardens into the structure that preserves avoidance.

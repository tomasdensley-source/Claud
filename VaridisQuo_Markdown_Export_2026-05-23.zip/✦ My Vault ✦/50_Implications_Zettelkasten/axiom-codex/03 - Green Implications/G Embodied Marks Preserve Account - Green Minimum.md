---
class: A
tags:
  - Minimum-Three Before Blue
---
# G Embodied Marks Preserve Account - Green Minimum

## Assertion
Embodied Marks Preserve Account requires at least three green implications before blue status is justified.

## Upward Abstraction Link
[[B13 Embodied Marks Preserve Account]]

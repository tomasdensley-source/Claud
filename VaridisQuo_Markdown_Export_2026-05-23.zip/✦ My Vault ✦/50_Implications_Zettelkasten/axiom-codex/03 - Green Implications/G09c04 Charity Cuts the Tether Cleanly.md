---
class: A
tags:
  - love-releases-the-source
---
# G09c04 Charity Cuts the Tether Cleanly

## Assertion
Charity cuts the tether cleanly because love releases the source from being used as the bearer's final enemy.

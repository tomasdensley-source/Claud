---
class: A
tags:
  - negation-mirrors-burden
---
# G09c03 Inverted Submission Still Serves the Load

## Assertion
Inverted submission still serves the load because negation can mirror the old burden instead of transcending it.

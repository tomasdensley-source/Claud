---
class: A
tags:
  - Final-Commitment Reenters Accountability
---
# G The Closing Vow Returns To First Record

## Assertion
The closing vow returns to first record because the final commitment re-enters accountability.

## Upward Abstraction Links
[[B15 Closure Returns to First Accountability]]
[[O15 The Vow Closes the Curve]]
[[O01 Existence is Accountability]]

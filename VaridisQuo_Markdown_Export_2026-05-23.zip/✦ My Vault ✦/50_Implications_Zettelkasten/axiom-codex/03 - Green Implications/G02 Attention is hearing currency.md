---
class: A
tags:
  - Heard-Presence Cost
  - Convergence Lineage
---

# G02 Attention is hearing currency

## Assertion
Attention is hearing currency because being heard requires another being to spend presence.

## Definition
This non-definition implication is green because it follows from Axiom Two through the named blue convergence.

## Upward Abstraction Link
[[B02d Listening Creates Reciprocal Debt]]
[[O02 Awareness Equals Enlistment]]

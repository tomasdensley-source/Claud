---
class: A
tags:
  - triple-green-promotion-threshold
---
# G Avoidance Builds Apparatus - Green Minimum

## Assertion
Avoidance Builds Apparatus requires at least three green implications before blue status is justified.

## Upward Abstraction Link
[[B03 Avoidance Builds Apparatus]]

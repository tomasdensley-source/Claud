---
class: A
tags:
  - parent-contained-meaning-test
---
# G Truth Bears Weight - Grounding

## Assertion
Truth Bears Weight is valid only when its children need no premise outside the parent meaning.

## Upward Abstraction Link
[[B01c Truth Bears Weight]]

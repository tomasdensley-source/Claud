---
class: A
tags:
  - Vagueness-Free Carrying
---
# G Truth Bears Weight - Load Bearing

## Assertion
Truth Bears Weight must carry the weight of its children without vagueness.

## Upward Abstraction Link
[[B01c Truth Bears Weight]]

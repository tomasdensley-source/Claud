---
class: A
tags:
  - Thinned-Substrate Blindness
---
# G05 The Seer Is Rendered Unable to Distinguish

## Assertion
The seer is rendered unable to distinguish when the substrate of experience is thinned rather than killed.

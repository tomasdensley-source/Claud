---
class: A
tags:
  - recognition-dependent-presence
---
# G05 The World Thins When Distinction Is Not Maintained

## Assertion
The world thins when distinction is not maintained because presence depends on repeated recognition.

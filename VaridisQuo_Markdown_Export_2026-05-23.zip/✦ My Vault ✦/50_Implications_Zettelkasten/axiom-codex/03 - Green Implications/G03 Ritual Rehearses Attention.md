---
class: A
tags:
  - Category-Keeping Repetition
---
# G03 Ritual Rehearses Attention

## Assertion
Ritual rehearses attention because repeated form trains the soul to keep categories alive.

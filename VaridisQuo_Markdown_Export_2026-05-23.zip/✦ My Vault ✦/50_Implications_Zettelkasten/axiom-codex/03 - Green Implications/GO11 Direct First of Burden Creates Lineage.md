---
class: A
tags:
  - inherited-accountable-weight
  - premiseless-echo-implication
---
# GO11 Direct First of Burden Creates Lineage

## Assertion
The burdened become a lineage when they receive and carry accountable weight. Therefore its first immediate implication echoes the assertion without adding another premise.

## Upward Abstraction Links
[[O11 Burden Creates Lineage]]

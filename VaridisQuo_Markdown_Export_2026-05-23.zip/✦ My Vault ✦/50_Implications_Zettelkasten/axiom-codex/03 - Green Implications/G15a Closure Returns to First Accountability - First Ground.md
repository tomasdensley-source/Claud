---
class: A
tags:
  - Vow Reenters Record
  - First Grounding Convergence
---
# G15a Closure Returns to First Accountability - First Ground

## Assertion
Closure returns to first accountability because the final vow re-enters the first record. This is the first grounded implication converging into the assertion.

## Upward Abstraction Links
[[B15 Closure Returns to First Accountability]]
[[O15 The Vow Closes the Curve]]

---
class: A
tags:
  - Refusal Patterns Rooms-And-Thoughts
---
# G03 Outer Architecture Has Inner Equivalent

## Assertion
Outer architecture has inner equivalent because the same refusal pattern can organize rooms and thoughts.

---
class: A
tags:
  - distinguishability-entails-obligation
  - third-converging-ground
---
# G01c Registration Makes Being Accountable - Third Ground

## Assertion
Registration makes being accountable because distinguishability enters a thing into obligation. This is the third grounded implication converging into the assertion.

---
class: A
tags:
  - Avoidance Conscripts Adjacent Habits
---
# G03 Untended Wound Recruits Surrounding Tissue

## Assertion
An untended wound recruits surrounding tissue because avoidance forces nearby habits to arrange themselves around it.

---
class: A
tags:
  - Deferred-Repair Cost Swell
---
# G03 Correction Becomes Too Expensive

## Assertion
Correction becomes too expensive when deferred repair compounds beyond the original wound.

## Upward Abstraction Links
[[B03c The Glaw Organizes Avoidance Around the Fault]]
[[O03 The Anesthetic Exists]]

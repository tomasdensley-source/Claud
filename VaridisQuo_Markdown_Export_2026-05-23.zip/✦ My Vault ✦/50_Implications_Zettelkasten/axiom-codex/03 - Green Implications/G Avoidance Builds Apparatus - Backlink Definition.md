---
class: A
tags:
  - Defined-By-Incoming-Links
  - Concrete-Consequence Greenness
---

# G Avoidance Builds Apparatus - Backlink Definition

## Assertion
Avoidance Builds Apparatus is defined by the implications that point back to it.

## Definition
This non-definition implication is green because it states a concrete consequence of its blue parent.

## Upward Abstraction Link
[[B03 Avoidance Builds Apparatus]]

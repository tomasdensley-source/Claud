---
class: B
tags:
  - rootless-transit-toleration
---
# G05 Airports Tolerate Use Without Belonging

## Assertion
Airports tolerate use without belonging because their ritual is transit without rooted witness.

## Upward Abstraction Links
[[B05c Non Places Are Collective Ritual Engines]]
[[O05 The Anemurge Stands Behind All Local Apparatus]]

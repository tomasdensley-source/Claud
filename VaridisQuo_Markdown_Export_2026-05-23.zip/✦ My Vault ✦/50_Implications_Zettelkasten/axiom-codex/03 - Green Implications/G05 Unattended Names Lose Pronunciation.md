---
class: A
tags:
  - Referent Starvation
---
# G05 Unattended Names Lose Pronunciation

## Assertion
Unattended names lose pronunciation when the mouth no longer has a living referent to serve.

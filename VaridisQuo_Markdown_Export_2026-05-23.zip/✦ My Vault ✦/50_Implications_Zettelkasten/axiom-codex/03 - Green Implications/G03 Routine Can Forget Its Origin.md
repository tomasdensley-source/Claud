---
class: A
tags:
  - Repetition Outlives Purpose
---
# G03 Routine Can Forget Its Origin

## Assertion
Routine can forget its origin when repetition survives after purpose evaporates.

---
class: A
tags:
  - Refusal-Preserving Scaffold
  - Twin-Footing Convergence
---
# G03b Avoidance Builds Apparatus - Second Ground

## Assertion
Avoidance builds apparatus because resisted awareness requires structures that preserve refusal. This is the second grounded implication converging into the assertion.

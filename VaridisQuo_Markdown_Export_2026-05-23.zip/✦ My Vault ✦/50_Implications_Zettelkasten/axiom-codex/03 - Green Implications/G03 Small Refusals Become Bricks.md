---
class: A
tags:
  - Accreted Barrier
---
# G03 Small Refusals Become Bricks

## Assertion
Small refusals become bricks because repeated absence from presence eventually becomes a barrier.

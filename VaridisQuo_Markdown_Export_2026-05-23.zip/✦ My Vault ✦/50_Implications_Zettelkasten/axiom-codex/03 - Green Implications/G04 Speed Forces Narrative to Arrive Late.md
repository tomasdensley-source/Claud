---
class: A
tags:
  - event-outrunning-explanation
---
# G04 Speed Forces Narrative to Arrive Late

## Assertion
Speed forces narrative to arrive late because events can outrun explanation while the mind still demands an account.

---
class: A
tags:
  - Shared-Depth Births Node
---
# G Truth Bears Weight - Convergence

## Assertion
Truth Bears Weight exists because several implications say the same deeper thing.

## Upward Abstraction Link
[[B01c Truth Bears Weight]]

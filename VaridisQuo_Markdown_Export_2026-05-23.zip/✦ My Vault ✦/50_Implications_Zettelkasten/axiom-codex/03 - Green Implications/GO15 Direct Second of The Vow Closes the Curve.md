---
class: A
tags:
  - oath-loop-resealing
  - second-direct-entailment
---
# GO15 Direct Second of The Vow Closes the Curve

## Assertion
The vow closes the curve and returns the chain to accountability. Therefore its second immediate implication remains true from the assertion itself.

## Upward Abstraction Links
[[O15 The Vow Closes the Curve]]

---
class: A
tags:
  - Actor-Attack Block
---
# G02 Shame blocks enlistment

## Assertion
Shame blocks enlistment because attacking the actor prevents clean response to the act.

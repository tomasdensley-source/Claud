---
class: A
tags:
  - Received Named Carried
  - First Grounding Convergence
---
# G11a Burden Becomes Inheritance - First Ground

## Assertion
Burden becomes inheritance when accountable weight is received, named, and carried forward. This is the first grounded implication converging into the assertion.

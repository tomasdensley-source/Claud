---
class: A
tags:
  - Uncertainty-As-Numbing Dodge
---
# G04 You Cannot Really Know Can Be Anesthetic

## Assertion
You cannot really know can be anesthetic when uncertainty is used to avoid the obligation of partial knowledge.

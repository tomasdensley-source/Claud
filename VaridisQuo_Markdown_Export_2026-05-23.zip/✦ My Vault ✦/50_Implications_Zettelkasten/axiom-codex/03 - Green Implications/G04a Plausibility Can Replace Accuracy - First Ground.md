---
class: A
tags:
  - Clerk Prioritizes Coherence
  - Grounding Convergence Marker
---
# G04a Plausibility Can Replace Accuracy - First Ground

## Assertion
Plausibility can replace accuracy when the inner clerk preserves coherence before truth. This is the first grounded implication converging into the assertion.

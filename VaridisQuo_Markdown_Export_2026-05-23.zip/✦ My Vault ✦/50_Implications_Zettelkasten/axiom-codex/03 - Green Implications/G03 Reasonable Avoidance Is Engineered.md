---
class: A
tags:
  - Sober-Seeming Evasion
---
# G03 Reasonable Avoidance Is Engineered

## Assertion
Reasonable avoidance is engineered when explanations are arranged to make evasion appear sober.

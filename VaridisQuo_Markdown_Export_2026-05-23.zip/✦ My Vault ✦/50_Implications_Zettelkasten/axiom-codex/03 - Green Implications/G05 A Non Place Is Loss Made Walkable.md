---
class: A
tags:
  - Absence Takes Corridor-Form
---
# G05 A Non Place Is Loss Made Walkable

## Assertion
A non-place is loss made walkable when absence takes corridor form.

## Upward Abstraction Links
[[B05b Evaporation Turns Loss Into Geography]]
[[O05 The Anemurge Stands Behind All Local Apparatus]]

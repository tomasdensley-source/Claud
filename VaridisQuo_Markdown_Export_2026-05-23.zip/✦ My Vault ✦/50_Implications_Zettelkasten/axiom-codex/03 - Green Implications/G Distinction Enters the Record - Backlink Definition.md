---
class: A
tags:
  - Constituted-By Returning Pointers
---
# G Distinction Enters the Record - Backlink Definition

## Assertion
Distinction Enters the Record is defined by the implications that point back to it.

## Upward Abstraction Link
[[B01a Distinction Enters the Record]]

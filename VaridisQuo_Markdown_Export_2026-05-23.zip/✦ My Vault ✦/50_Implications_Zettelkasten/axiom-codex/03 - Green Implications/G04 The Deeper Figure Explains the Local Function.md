---
class: A
tags:
  - instrument-needs-larger-system
---
# G04 The Deeper Figure Explains the Local Function

## Assertion
The deeper figure explains the local function because the clerk makes full sense only as the instrument of a larger system.

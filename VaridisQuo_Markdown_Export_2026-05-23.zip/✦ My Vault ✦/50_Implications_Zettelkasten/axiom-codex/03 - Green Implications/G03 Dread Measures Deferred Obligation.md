---
class: A
tags:
  - Dread Tracks Postponed-Response
---
# G03 Dread Measures Deferred Obligation

## Assertion
Dread measures deferred obligation because the feeling grows where response has been postponed.

## Upward Abstraction Links
[[B03d Dread Is Interest on Unpaid Awareness]]
[[O03 The Anesthetic Exists]]

---
class: A
tags:
  - Contradiction-Free Backflow
---
# G Recurrent Convergence Warrants Trust - Return Test

## Assertion
Recurrent Convergence Warrants Trust can imply its children back without contradiction.

## Upward Abstraction Link
[[B10 Recurrent Convergence Warrants Trust]]

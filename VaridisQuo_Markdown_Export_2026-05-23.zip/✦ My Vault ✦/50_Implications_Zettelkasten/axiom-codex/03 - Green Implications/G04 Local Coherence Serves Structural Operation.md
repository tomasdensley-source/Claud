---
class: A
tags:
  - Loop-Aligned Smoothing
---
# G04 Local Coherence Serves Structural Operation

## Assertion
Local coherence serves structural operation when the mind smooths facts in the same direction that the larger loop requires.

---
class: A
tags:
  - Self-Contained Premise Test
---
# G Boundary Demands Completion Choice - Grounding

## Assertion
Boundary Demands Completion Choice is valid only when its children need no premise outside the parent meaning.

## Upward Abstraction Link
[[B14 Boundary Demands Completion Choice]]

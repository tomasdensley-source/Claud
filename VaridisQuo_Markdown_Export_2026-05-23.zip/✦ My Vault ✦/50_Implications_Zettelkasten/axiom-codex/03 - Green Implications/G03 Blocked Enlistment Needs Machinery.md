---
class: A
tags:
  - repeated-cost-muffling
---
# G03 Blocked Enlistment Needs Machinery

## Assertion
Blocked enlistment needs machinery because the cost of seeing must be muffled again and again.

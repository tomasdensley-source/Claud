---
class: A
tags:
  - Vow-Sealed Loop
---
# O15 The Vow Closes the Curve

## Assertion
The vow closes the curve and returns the chain to accountability.

## Upward Abstraction Link
[[O01 Existence is Accountability]]

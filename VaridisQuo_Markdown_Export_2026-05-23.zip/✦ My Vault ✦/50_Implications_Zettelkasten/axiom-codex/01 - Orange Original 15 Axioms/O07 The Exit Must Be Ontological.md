---
class: A
tags:
  - Being-Level Departure
---
# O07 The Exit Must Be Ontological

## Assertion
The exit must be ontological, not logical.

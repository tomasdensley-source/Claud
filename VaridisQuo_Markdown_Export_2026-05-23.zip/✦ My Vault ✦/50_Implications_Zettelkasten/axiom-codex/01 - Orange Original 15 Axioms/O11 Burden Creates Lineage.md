---
class: A
tags:
  - Weight-Born Lineage
---
# O11 Burden Creates Lineage

## Assertion
The burdened become a lineage when they receive and carry accountable weight.

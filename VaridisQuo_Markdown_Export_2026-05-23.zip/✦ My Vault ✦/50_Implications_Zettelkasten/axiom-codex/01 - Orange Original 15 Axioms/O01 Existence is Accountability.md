---
class: A
tags:
  - Being-As-Answerability
  - Orange Admission Basis
  - Definition-Form Intelligibility
  - Plain-Term Inventory
  - Convergence-Child Set
  - Knowing-Begets-Owing
  - Truth-Has-Mass
  - Lie-Load-Redistribution
---

# O01 Existence is Accountability

## Assertion
Existence is accountability.

## Definition
This original assertion is admitted as orange because it is one of the fifteen source axioms. It becomes more intelligible through definition-form implications for existence, accountability, registration, distinguishability, record, binding, owing, weight, truth, lie, load, witness, constraint, and fate.

## Plain-Term Requirements
Existence; accountability; to be; registered; distinguishable; record; bound; knowing; owing; truth; physical weight; lie; load; redistribution; witness; constraint; fate.

## Plain-Convergence Children
Registration Makes Being Accountable; Distinction Enters the Record; Perception Enlists the Knower; Truth Bears Weight; Lies Move Load Downstream.

## Plain-Direct Implications
Knowing creates owing. Truth has physical weight. Lies do not eliminate their load; they redistribute it.

---
class: A
tags:
  - Noticing-Becomes-Conscription
  - Source-Axiom Origin
  - Backlink Self-Revealing
  - Fivefold Blue Buttressing
  - Definitional Offspring Roster
  - Green Consequence Roster
---

# O02 Awareness Equals Enlistment

## Assertion
Awareness equals enlistment.

## Definition
This original assertion is one of the fifteen source axioms from the PDF. It becomes visible as an axiom by its position and by its implication children in backlinks, not by a tag or role label.


## Upgraded Local Convergence Structure
Axiom Two is upgraded around five converged blue children: Observation Enters the Record; Refusal Becomes a Recorded Position; Awareness Generates the Lawfield; Listening Creates Reciprocal Debt; Shame Counterfeits Conscience.

## Definition-Implication Children
Def Awareness; Def Enlistment; Def Seeing; Def Witness; Def Neutral Observation; Def Refusal; Def Position; Def Debit; Def Conscience; Def Shame; Def Listening; Def Attention; Def Lawfield; Def Anesthetic.

## Green Implication Children
Seeing Levies Cost; Knowledge Conscripts the Knower; Awareness Removes Clean Ignorance; The Witness Is Entered; The Seen Thing Makes Claim; The Cost Has Already Been Levied; The Anesthetic Defends Against Enlistment; Six Laws Name the Awareness Field.

---
class: A
tags:
  - Enlistment-Blocking Device
  - Source-Axiom Membership
  - Counter-Binding Arousal
---

# O03 The Anesthetic Exists

## Assertion
An apparatus exists whose purpose is to block enlistment.

## Definition
This original orange assertion is one of the fifteen source axioms. It holds that once awareness would enlist a being into obligation, a counter-structure can arise whose function is to keep awareness from becoming binding action.

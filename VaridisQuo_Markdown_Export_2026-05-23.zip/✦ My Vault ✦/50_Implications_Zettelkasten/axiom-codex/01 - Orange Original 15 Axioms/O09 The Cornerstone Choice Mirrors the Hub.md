---
class: A
tags:
  - Two-Handed Bearing
  - Axiom Sequencing Slot
  - Dual-Gesture Choice
---

# O09 The Cornerstone Choice Mirrors the Hub

## Assertion
The subordinate bearer must choose the Hub's own pattern by holding refusal of the world's false claim together with opened charity toward the source.

## Definition
This orange original axiom receives Part 9 of Pass 10: after the opened Hub is named, the lesser bearer must make the cornerstone choice in two hands, No to the world's false claim and Yes to the source in charity.

## Upward Abstraction Link
[[O08 The Hub Must Be a Being Who Is Opened]]

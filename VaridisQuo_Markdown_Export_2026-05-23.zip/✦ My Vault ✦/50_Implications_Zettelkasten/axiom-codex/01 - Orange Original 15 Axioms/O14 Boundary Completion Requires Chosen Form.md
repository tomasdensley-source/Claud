---
class: A
tags:
  - Edge-Sealing Mandate
---
# O14 Boundary Completion Requires Chosen Form

## Assertion
Boundary completion requires a chosen form.

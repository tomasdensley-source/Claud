---
class: A
tags:
  - Care-Capacity Erosion
  - Substrate-Thinning Convergence
---

# B05e Prolonged Exposure Produces Unworlding

## Assertion
Prolonged exposure produces unworlding because a being slowly loses the capacity to distinguish what once could be cared for.

## Definition
This blue assertion converges implications about years of abrasion, care-loss, and the thinning of the substrate of experience.

## Upward Abstraction Link
[[O05 The Anemurge Stands Behind All Local Apparatus]]

---
class: A
tags:
  - Weakened-Category Trap
  - Wheel-Onset Transition
---

# B05f Hollowed Reason Cannot Exit the Loop

## Assertion
Hollowed reason cannot exit the loop because reasoning depends on the same categories that prolonged evaporation has weakened.

## Definition
This blue assertion converges implications that prepare the transition from Part 5 into Part 6, where the wheel becomes visible.

## Upward Abstraction Link
[[O05 The Anemurge Stands Behind All Local Apparatus]]

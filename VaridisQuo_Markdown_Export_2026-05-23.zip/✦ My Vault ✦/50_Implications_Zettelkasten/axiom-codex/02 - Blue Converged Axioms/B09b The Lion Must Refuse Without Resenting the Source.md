---
class: A
tags:
  - Resentment-Free Refusal
---
# B09b The Lion Must Refuse Without Resenting the Source

## Assertion
The lion becomes complete only when refusal of imposed claims does not harden into resentment toward the father-source.

## Upward Abstraction Link
[[O09 The Cornerstone Choice Mirrors the Hub]]

---
class: A
tags:
  - Conduited Weight-Sanctity
---
# B09f Bearing Must Flow Through the Opened Hub

## Assertion
Bearing becomes sanctified only when the weight flows through the opened Hub instead of being absorbed by the subordinate bearer as personal source.

---
class: A
tags:
  - No-Internal-Rescue
---
# B07 The Needed Exit Must Be Other

## Assertion
The needed exit must be other because a system cannot rescue itself by adding another internal spoke.

## Upward Abstraction Link
[[O07 The Exit Must Be Ontological]]

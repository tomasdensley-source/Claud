---
class: A
tags:
  - Awareness-Sustained Separateness
  - Reality-Maintenance Cost
---

# B05a Attention Maintains Distinction

## Assertion
Attention maintains distinction because what is not held in awareness loses the energy that keeps it separate, nameable, and present.

## Definition
This blue assertion converges implications about maintenance, love, energy, and the cost of keeping a thing real enough to answer.

## Upward Abstraction Link
[[O05 The Anemurge Stands Behind All Local Apparatus]]

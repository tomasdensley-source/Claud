---
class: A
tags:
  - Distinguishability-Enters-Obligation
  - Multi-Path Cleaner-Claim
---

# B01 Registration Makes Being Accountable

## Assertion
Registration makes being accountable because distinguishability enters a thing into obligation.

## Definition
This converged assertion is blue because multiple non-definition implications converge on the cleaner claim that being becomes accountable when distinction enters the Record.

## Upward Abstraction Link
[[O01 Existence is Accountability]]

---
class: A
tags:
  - Attention-Organizing Architecture
  - Built-Perception-Environment
---

# B03a The Anesthetic Has Architectural Form

## Assertion
The Anesthetic has architectural form because blocked enlistment must organize attention through noise, vagueness, fog, speed, and volume.

## Definition
This blue assertion converges implications that the Anesthetic is not one feeling but a built environment for perception.

## Upward Abstraction Links
[[O03 The Anesthetic Exists]]

---
class: A
tags:
  - Compounding Obligation-Cost
  - Avoided-Seeing Accrual
---

# B03d Dread Is Interest on Unpaid Awareness

## Assertion
Dread is interest on unpaid awareness because ignored obligation compounds until the payment feeling exceeds the original fault.

## Definition
This blue assertion converges implications that dread is the accruing cost of avoided seeing.

## Upward Abstraction Links
[[O03 The Anesthetic Exists]]

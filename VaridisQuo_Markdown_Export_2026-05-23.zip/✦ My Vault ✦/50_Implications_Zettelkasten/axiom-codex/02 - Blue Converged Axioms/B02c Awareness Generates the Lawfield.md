---
class: A
tags:
  - Seeing-Activated Structures
---
# B02c Awareness Generates the Lawfield

## Assertion
Awareness generates the lawfield because seeing activates recurring structures of record, evaporation, interpretation, conscience, shame, and listening.

## Upward Abstraction Link
[[O02 Awareness Equals Enlistment]]

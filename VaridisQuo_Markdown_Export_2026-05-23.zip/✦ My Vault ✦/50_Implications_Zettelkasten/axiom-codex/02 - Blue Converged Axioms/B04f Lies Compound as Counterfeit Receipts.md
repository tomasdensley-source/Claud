---
class: A
tags:
  - Deferred-Payment Falsehood
  - Interest-Bearing Falsehood
---

# B04f Lies Compound as Counterfeit Receipts

## Assertion
Lies compound as counterfeit receipts because false coherence delays payment while increasing the later cost.

## Definition
This blue assertion gathers implications about counterfeit accounts, soft edges, hum, and interest-bearing falsehood.

## Upward Abstraction Link
[[O04 Every Mind Has an Internal Clerk]]

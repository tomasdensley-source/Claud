---
class: B
tags:
  - Wound-Centered Apparatus
  - Life Around Uncorrected Fault
---

# B03c The Glaw Organizes Avoidance Around the Fault

## Assertion
The Glaw organizes avoidance around the fault because an untended wound becomes the hidden center of the surrounding structure.

## Definition
This blue assertion converges implications showing that the Glaw is the organized life built around not correcting a fault.

## Upward Abstraction Links
[[O03 The Anesthetic Exists]]

---
class: A
tags:
  - Load-Bearing Truthfulness
---
# B01c Truth Bears Weight

## Assertion
Truth bears weight because truthful relation changes the load-bearing structure of action.

## Upward Abstraction Link
[[O01 Existence is Accountability]]

---
class: A
tags:
  - Vow-Reentering-Record
---
# B15 Closure Returns to First Accountability

## Assertion
Closure returns to first accountability because the final vow re-enters the first record.

## Upward Abstraction Link
[[O15 The Vow Closes the Curve]]

---
class: A
tags:
  - Named-And-Carried Weight
---
# B11 Burden Becomes Inheritance

## Assertion
Burden becomes inheritance when accountable weight is received, named, and carried forward.

## Upward Abstraction Link
[[O11 Burden Creates Lineage]]

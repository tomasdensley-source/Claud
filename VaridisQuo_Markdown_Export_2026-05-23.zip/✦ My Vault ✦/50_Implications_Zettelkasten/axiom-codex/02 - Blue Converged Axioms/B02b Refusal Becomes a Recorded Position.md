---
class: A
tags:
  - Inaction-Cannot-Neutralize
---
# B02b Refusal Becomes a Recorded Position

## Assertion
Refusal becomes a recorded position because seen obligation cannot be made neutral by inaction.

## Upward Abstraction Link
[[O02 Awareness Equals Enlistment]]

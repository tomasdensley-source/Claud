---
class: A
tags:
  - Hub-Without-Becoming-Spoke
---
# B08 Opened Center Holds the Structure

## Assertion
The opened center holds the structure because the hub gathers spokes without becoming another spoke.

## Upward Abstraction Link
[[O08 The Hub Must Be a Being Who Is Opened]]

---
class: A
tags:
  - Unpracticed Incompleteness
---
# B12 Doctrine Must Become Craft

## Assertion
Doctrine must become craft because truth that cannot be practiced remains structurally incomplete.

## Upward Abstraction Link
[[O12 Craft Makes Doctrine Operational]]

---
class: A
tags:
  - Frame-Bound Reason
---
# B06 Closed Logic Produces Wheel

## Assertion
Closed logic produces the wheel because reason inside its own frame cannot supply an outside.

## Upward Abstraction Link
[[O06 Reason Alone Cannot Exit the Loop]]

---
class: A
tags:
  - Narrative Sealing
  - Substitute Membrane
---
# B04c The Boundary Leak Is Patched by Story

## Assertion
The boundary leak is patched by story when narrative is used to seal an opening that should have exposed the self to truth.

## Definition
This blue assertion gathers implications about leakage, repair, and narrative as the substitute membrane of the self.

---
class: A
tags:
  - Sanded-World Smoothness
  - Motive-Invention Gathering
---

# B04a Smooth Narrative Signals the Clerk

## Assertion
Smooth narrative signals the clerk because unresisted coherence is often produced after the world has been sanded down.

## Definition
This blue assertion gathers implications about narrative smoothness, motive invention, and the hiding of rough fact.

## Upward Abstraction Link
[[O04 Every Mind Has an Internal Clerk]]

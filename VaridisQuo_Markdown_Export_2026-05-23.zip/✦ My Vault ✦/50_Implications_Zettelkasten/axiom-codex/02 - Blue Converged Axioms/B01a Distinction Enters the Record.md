---
class: A
tags:
  - Severance Inception
  - Upward Tributary Test
---

# B01a Distinction Enters the Record

## Assertion
Distinction enters the Record because meaningful being begins when something can be separated from undifferentiated absence.

## Definition
This converged assertion is blue because at least three green non-definition implications point upward to it and are elegantly summarized by its assertion.

## Upward Abstraction Link
[[O01 Existence is Accountability]]

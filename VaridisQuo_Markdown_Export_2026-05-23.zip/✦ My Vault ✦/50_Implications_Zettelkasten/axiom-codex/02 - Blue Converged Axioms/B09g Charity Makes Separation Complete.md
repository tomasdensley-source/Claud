---
class: A
tags:
  - Non-Enemy Departure
---
# B09g Charity Makes Separation Complete

## Assertion
Charity makes separation complete because the bearer can leave the source-position without turning the source into the enemy of being.

## Upward Abstraction Link
[[O09 The Cornerstone Choice Mirrors the Hub]]

---
class: A
tags:
  - Opposition-Still-Governed
---
# B09c Detachment Without Charity Inverts the Camel

## Assertion
Detachment without charity inverts the camel because mere opposition remains governed by the burden it rejects.

## Upward Abstraction Link
[[O09 The Cornerstone Choice Mirrors the Hub]]

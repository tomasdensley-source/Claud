---
class: A
tags:
  - Weight-In-Love
---
# B09 Vocation Imitates the Opened Hub

## Assertion
Vocation imitates the opened hub when a subordinate being bears weight in love rather than denial.

## Upward Abstraction Link
[[O09 The Cornerstone Choice Mirrors the Hub]]

---
class: A
tags:
  - Charity-Gated Creation
---
# B09d The Child Requires Completed Lionhood

## Assertion
The child can create in sacred yes only after the lion's No has been completed by charity toward the source.

## Upward Abstraction Link
[[O09 The Cornerstone Choice Mirrors the Hub]]

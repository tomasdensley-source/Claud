---
class: A
tags:
  - Coherence-Before-Truth
  - Smooth-Story Preference
---

# B04 Plausibility Can Replace Accuracy

## Assertion
Plausibility can replace accuracy when the inner clerk preserves coherence before truth.

## Definition
This blue assertion gathers implications in which the mind favors a smooth usable story over a faithful report.

## Upward Abstraction Link
[[O04 Every Mind Has an Internal Clerk]]

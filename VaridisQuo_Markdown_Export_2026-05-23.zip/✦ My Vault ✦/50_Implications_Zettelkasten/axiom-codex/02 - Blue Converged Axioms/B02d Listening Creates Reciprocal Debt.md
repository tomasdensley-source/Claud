---
class: A
tags:
  - Attention-As-Currency
---
# B02d Listening Creates Reciprocal Debt

## Assertion
Listening creates reciprocal debt because attention is the currency by which a being is permitted to remain heard.

## Upward Abstraction Link
[[O02 Awareness Equals Enlistment]]

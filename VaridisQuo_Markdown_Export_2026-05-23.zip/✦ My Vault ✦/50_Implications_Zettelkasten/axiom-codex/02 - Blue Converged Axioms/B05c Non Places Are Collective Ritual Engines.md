---
class: B
tags:
  - Unexamined-Use Engine
  - Rootless Transit-Spaces
---

# B05c Non Places Are Collective Ritual Engines

## Assertion
Non-places are collective ritual engines because they are sustained by repeated use without examined belonging.

## Definition
This blue assertion converges implications about airports, corridors, waiting rooms, and social environments that tolerate use while withholding rooted presence.

## Upward Abstraction Link
[[O05 The Anemurge Stands Behind All Local Apparatus]]

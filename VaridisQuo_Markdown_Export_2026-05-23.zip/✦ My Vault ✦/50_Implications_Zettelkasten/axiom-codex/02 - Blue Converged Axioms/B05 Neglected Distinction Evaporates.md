---
class: A
tags:
  - Unpaid Vanishing
  - Maintenance-Loss Channel
---

# B05 Neglected Distinction Evaporates

## Assertion
Neglected distinction evaporates when attention no longer pays the energy required for a thing to remain meaningfully present.

## Definition
This blue assertion gathers the Part 5 implications in which the Anemurge operates through loss of maintained distinction.

## Upward Abstraction Link
[[O05 The Anemurge Stands Behind All Local Apparatus]]

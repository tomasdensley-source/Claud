---
class: A
tags:
  - Displaced-Truth Travel
---
# B01d Lies Move Load Downstream

## Assertion
Lies move load downstream because denied truth does not disappear but travels into later persons and places.

## Upward Abstraction Link
[[O01 Existence is Accountability]]

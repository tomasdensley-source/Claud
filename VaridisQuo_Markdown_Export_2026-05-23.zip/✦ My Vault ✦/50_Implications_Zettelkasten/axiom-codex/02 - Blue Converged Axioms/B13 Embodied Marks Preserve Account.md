---
class: A
tags:
  - Body-As-Undischarged-Ledger
---
# B13 Embodied Marks Preserve Account

## Assertion
Embodied marks preserve account because the body carries what the mind cannot fully discharge.

## Upward Abstraction Link
[[O13 The Body Is a Ledger]]

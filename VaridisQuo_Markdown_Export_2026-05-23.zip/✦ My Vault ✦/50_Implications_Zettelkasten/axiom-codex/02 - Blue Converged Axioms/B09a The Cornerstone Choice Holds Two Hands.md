---
class: A
tags:
  - Refuse-While-Loving
  - Three-Green Backward-Implication
---

# B09a The Cornerstone Choice Holds Two Hands

## Assertion
The cornerstone choice holds two hands because the bearer must refuse the world's false claim while loving the source from which separation occurs.

## Definition
This blue assertion is admitted because at least three green implications converge into it and it can imply those children back without adding an ungrounded premise.

## Upward Abstraction Links
[[O09 The Cornerstone Choice Mirrors the Hub]]
[[O08 The Hub Must Be a Being Who Is Opened]]

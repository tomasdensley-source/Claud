---
class: A
tags:
  - Cost-Lowering Comfort
  - Accountability-Quieting Phrases
---

# B04b Reassurance Functions as Anesthetic

## Assertion
Reassurance functions as anesthetic when it reduces the felt cost of clear seeing without answering the truth of the matter.

## Definition
This blue assertion gathers implications about familiar inner phrases that quiet accountability rather than clarify reality.

## Upward Abstraction Links
[[O04 Every Mind Has an Internal Clerk]]
[[O03 The Anesthetic Exists]]

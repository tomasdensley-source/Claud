---
class: A
tags:
  - Witnessing Implication
  - Threefold Cleaner Formulation
---

# B02a Observation Enters the Record

## Assertion
Observation enters the Record because awareness makes the witness party to what is witnessed.

## Definition
This blue assertion is admitted because at least three green implications converge into this cleaner formulation.

## Upward Abstraction Link
[[O02 Awareness Equals Enlistment]]

---
class: A
tags:
  - Act-Versus-Actor Accusation
---
# B02e Shame Counterfeits Conscience

## Assertion
Shame counterfeits conscience because both accuse from within, but conscience names the act while shame names the actor.

## Upward Abstraction Link
[[O02 Awareness Equals Enlistment]]

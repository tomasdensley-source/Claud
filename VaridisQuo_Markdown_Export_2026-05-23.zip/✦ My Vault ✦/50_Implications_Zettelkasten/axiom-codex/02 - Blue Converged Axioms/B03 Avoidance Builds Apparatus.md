---
class: A
tags:
  - Repeatable Not-Seeing
  - Refusal-Becomes-Equipment
---

# B03 Avoidance Builds Apparatus

## Assertion
Avoidance builds apparatus because blocked enlistment requires repeatable structures that make not-seeing feel reasonable.

## Definition
This blue assertion converges implications showing that refusal becomes equipment, habit, architecture, and atmosphere.

## Upward Abstraction Links
[[O03 The Anesthetic Exists]]

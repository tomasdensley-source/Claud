---
class: A
tags:
  - Knowing-As-Claim
---
# B01b Perception Enlists the Knower

## Assertion
Perception enlists the knower because what is known becomes a claim on the one who knows.

## Upward Abstraction Link
[[O01 Existence is Accountability]]

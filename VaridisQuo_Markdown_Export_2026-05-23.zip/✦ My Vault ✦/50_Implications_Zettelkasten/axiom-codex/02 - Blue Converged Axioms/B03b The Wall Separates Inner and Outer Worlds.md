---
class: A
tags:
  - Deniable Partition
  - Numbing Sequestration
---

# B03b The Wall Separates Inner and Outer Worlds

## Assertion
The Wall separates inner and outer worlds because plausible deniability turns small refusals into a boundary against presence.

## Definition
This blue assertion converges implications that the Anesthetic partitions what is known inwardly from what is admitted outwardly.

## Upward Abstraction Links
[[O03 The Anesthetic Exists]]

---
class: A
tags:
  - Repetition's Double Edge
  - Capturable Attention-Keeper
---

# B03e Ritual Is the First Target of the Anesthetic

## Assertion
Ritual is the first target of the Anesthetic because repeated attention can either keep meaning alive or become emptied into numbness.

## Definition
This blue assertion converges implications showing that ritual can preserve attention and therefore can also be captured by anesthesia.

## Upward Abstraction Links
[[O03 The Anesthetic Exists]]

---
class: A
tags:
  - Statement Trace
  - Accountability Field
---
# Ex Def Receipt - Account Trace

## Assertion
Receipt is exemplified by the trace a statement leaves in the field of accountability.

## Upward Abstraction Link
[[Def Receipt]]

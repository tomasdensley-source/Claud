---
class: B
tags:
  - Homeless Hallway
---
# Ex Def Non Place - Axiom Five

## Assertion
Non Place is shown when a hotel hallway permits sleep nearby but never receives anyone as home.

## Upward Abstraction Link
[[Def Non Place]]

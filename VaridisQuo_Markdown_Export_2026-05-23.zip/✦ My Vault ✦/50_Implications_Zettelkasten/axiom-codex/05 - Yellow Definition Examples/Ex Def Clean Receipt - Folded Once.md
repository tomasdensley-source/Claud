---
class: A
tags:
  - Truthful Statement
  - Repair-Free Account
---
# Ex Def Clean Receipt - Folded Once

## Assertion
Clean receipt is exemplified by a truthful statement that needs no later repair.

## Upward Abstraction Link
[[Def Clean Receipt]]

---
class: A
tags:
  - Comfortable Explanation
  - Evidence-Answering Alternative
---
# Ex Def Convenience - Easier Story

## Assertion
Convenience is exemplified by choosing the explanation that feels easier to live with over the one that answers the evidence.

## Upward Abstraction Link
[[Def Convenience]]

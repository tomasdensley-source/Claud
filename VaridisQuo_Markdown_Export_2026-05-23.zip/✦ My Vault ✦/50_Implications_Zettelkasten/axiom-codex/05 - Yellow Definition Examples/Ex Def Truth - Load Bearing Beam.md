---
class: A
tags:
  - Load-Bearing Beam
  - Claim-Carrying Capacity
---
# Ex Def Truth - Load Bearing Beam

## Assertion
A load-bearing beam shows truth because it must actually carry what it claims to support.

## Upward Abstraction Link
[[Def Truth]]

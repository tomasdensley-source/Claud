---
class: A
tags:
  - Late Fee
  - Compounding Unpaid Obligation
---
# Ex Def Interest - Late Fee

## Assertion
A late fee is interest when the cost grows because the first obligation was not paid.

## Upward Abstraction Links
[[Def Interest]]

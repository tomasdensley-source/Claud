---
class: A
tags:
  - Lit Candle
  - Form-Joined-To-Feeling
---
# Ex Def Meaning - Lit Candle

## Assertion
A lit candle carries meaning when the form remains joined to the grief or hope it was meant to hold.

## Upward Abstraction Links
[[Def Meaning]]

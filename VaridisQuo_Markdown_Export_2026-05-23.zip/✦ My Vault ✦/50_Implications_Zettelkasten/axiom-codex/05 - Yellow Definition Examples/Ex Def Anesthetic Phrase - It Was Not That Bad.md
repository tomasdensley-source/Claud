---
class: A
tags:
  - Minimizing Phrase
  - Dulled Harm-Seeing
---
# Ex Def Anesthetic Phrase - It Was Not That Bad

## Assertion
Anesthetic phrase is exemplified by it was not that bad when the phrase lowers the cost of seeing harm clearly.

## Upward Abstraction Link
[[Def Anesthetic Phrase]]

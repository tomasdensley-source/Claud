---
class: A
tags:
  - Awkward Detail
  - Anti-False-Completion
---
# Ex Def Rough Edge - Resistant Detail

## Assertion
Rough edge is exemplified by the awkward detail that keeps a story from becoming falsely complete.

## Upward Abstraction Link
[[Def Rough Edge]]

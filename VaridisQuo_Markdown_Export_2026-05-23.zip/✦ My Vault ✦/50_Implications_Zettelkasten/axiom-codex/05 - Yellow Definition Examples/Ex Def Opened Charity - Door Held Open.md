---
class: A
tags:
  - Strained Open Door
  - Refusal To Close
---
# Ex Def Opened Charity - Door Held Open

## Assertion
A door held open under strain is an example of opened charity because love refuses to close where resentment would feel safer.

## Upward Abstraction Link
[[Def Opened Charity]]

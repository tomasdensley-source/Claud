---
class: A
tags:
  - Crooked Footing
  - Inherited Misalignment
---
# Ex Def Cornerstone - Crooked First Stone

## Assertion
A crooked first stone is an example of cornerstone because the whole structure above it inherits the first misalignment.

## Upward Abstraction Link
[[Def Cornerstone]]

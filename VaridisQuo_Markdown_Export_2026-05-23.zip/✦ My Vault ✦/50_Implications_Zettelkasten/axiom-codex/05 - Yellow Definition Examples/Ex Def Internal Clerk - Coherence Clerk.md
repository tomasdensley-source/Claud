---
class: A
tags:
  - Premature Story-Filing
---
# Ex Def Internal Clerk - Coherence Clerk

## Assertion
Internal clerk is exemplified by the mind rapidly filing scattered events into a usable story before checking its truth.

## Upward Abstraction Link
[[Def Internal Clerk]]

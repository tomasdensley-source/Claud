---
class: B
tags:
  - Preserved Answerability
---
# Ex Def Record - Kept Account

## Assertion
A kept account shows record because it preserves what distinction has made answerable.

## Upward Abstraction Link
[[Def Record]]

---
class: B
tags:
  - Relit Memorial
---
# Ex Def Maintenance - Axiom Five

## Assertion
Maintenance is shown when a candle is relit daily so the memorial remains a witness rather than decoration.

## Upward Abstraction Link
[[Def Maintenance]]

---
class: A
tags:
  - Hidden Rot
  - Plausible Surface Failure
---
# Ex Def Lie - Hidden Rot

## Assertion
Hidden rot shows lie because the surface remains plausible while the support fails underneath.

## Upward Abstraction Link
[[Def Lie]]

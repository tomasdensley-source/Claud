---
class: A
tags:
  - Coin-Eating Vendor
  - Forgotten Stocker
  - Yellow Note Role
---

# Ex Def Anemurge - Axiom Five

## Assertion
Anemurge is shown when a vending machine in an endless corridor keeps accepting coins though no one remembers who stocked it.

## Definition
This yellow note gives a concrete example for a purple definition-form implication and points upward to that definition.

## Upward Abstraction Link
[[Def Anemurge]]

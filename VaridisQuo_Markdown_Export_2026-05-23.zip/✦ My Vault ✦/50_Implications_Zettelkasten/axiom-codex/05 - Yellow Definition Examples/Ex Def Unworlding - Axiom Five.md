---
class: A
tags:
  - Meaning Drainage
---
# Ex Def Unworlding - Axiom Five

## Assertion
Unworlding is shown when the garden is still blooming, but the seer can no longer feel why bloom should matter.

## Upward Abstraction Link
[[Def Unworlding]]

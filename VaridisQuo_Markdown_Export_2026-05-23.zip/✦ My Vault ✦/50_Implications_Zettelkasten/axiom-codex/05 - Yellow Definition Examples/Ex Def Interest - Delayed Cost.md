---
class: A
tags:
  - Avoidance-Grown Dread
---
# Ex Def Interest - Delayed Cost

## Assertion
Interest is exemplified by dread increasing after awareness has been avoided.

## Upward Abstraction Link
[[Def Interest]]

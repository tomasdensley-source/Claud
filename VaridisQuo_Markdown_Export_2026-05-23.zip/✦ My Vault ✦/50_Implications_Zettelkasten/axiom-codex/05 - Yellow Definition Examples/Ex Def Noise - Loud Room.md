---
class: A
tags:
  - Signal Drowning
---
# Ex Def Noise - Loud Room

## Assertion
A loud room can become noise when its sound prevents the one true sentence from being heard.

## Upward Abstraction Links
[[Def Noise]]

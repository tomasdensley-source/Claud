---
class: A
tags:
  - Answerable Signed Entry
  - Downstream Upward-Pointing Example
---

# Ex Def Accountability - Answerable Entry

## Assertion
A signed ledger entry shows accountability because what is entered can be answered for.

## Definition
This yellow note is an example for a purple definition-form implication. It remains downstream and points upward to the definition it clarifies.

## Upward Abstraction Link
[[Def Accountability]]

---
class: A
tags:
  - Soft Excuse
  - Unnameable Responsibility
---
# Ex Def Vagueness - Soft Excuse

## Assertion
A soft excuse is vagueness when no edge remains where responsibility can be named.

## Upward Abstraction Links
[[Def Vagueness]]

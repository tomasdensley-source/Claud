---
class: A
tags:
  - Counterfeit Access
---
# Ex Def Wall - Painted Window

## Assertion
A painted window is a Wall when it looks like access but does not permit contact.

## Upward Abstraction Links
[[Def Wall]]

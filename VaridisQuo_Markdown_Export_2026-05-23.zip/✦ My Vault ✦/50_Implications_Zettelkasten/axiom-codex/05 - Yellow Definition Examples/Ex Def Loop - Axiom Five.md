---
class: A
tags:
  - Repeated-Doorway Pseudoprogress
---
# Ex Def Loop - Axiom Five

## Assertion
Loop is shown when the same argument produces the same doorway and calls the doorway progress.

## Upward Abstraction Link
[[Def Loop]]

---
class: A
tags:
  - Downstream Cost
  - Displaced Load
---
# Ex Def Redistribution - Downstream Cost

## Assertion
Downstream cost shows redistribution because unpaid load lands where it was not first incurred.

## Upward Abstraction Link
[[Def Redistribution]]

---
class: A
tags:
  - Fact Escaping Speech
  - Failed Self-Containment
---
# Ex Def Boundary Leak - Truth Through Wall

## Assertion
Boundary leak is exemplified when the avoided fact enters speech despite the self trying to keep it outside.

## Upward Abstraction Link
[[Def Boundary Leak]]

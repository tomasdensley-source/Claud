---
class: A
tags:
  - Closed Door
  - Contact Prevention
---
# Ex Def Block - Closed Door

## Assertion
A closed door is a block when its function is not privacy but the prevention of answerable contact.

## Upward Abstraction Links
[[Def Block]]

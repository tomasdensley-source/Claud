---
class: A
tags:
  - Holding-Together
  - Underlying Floor
---
# Ex Def Substrate - Axiom Five

## Assertion
Substrate is shown when the world holds together because names, cares, and differences still have a floor beneath them.

## Upward Abstraction Link
[[Def Substrate]]

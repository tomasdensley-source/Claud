---
class: A
tags:
  - Upward Surrender
  - Completion Not Defeat
---
# Ex Def Entrustment - Into Thy Hands

## Assertion
Into thy hands is an example of entrustment because the weight is directed upward as completion rather than defeat.

## Upward Abstraction Link
[[Def Entrustment]]

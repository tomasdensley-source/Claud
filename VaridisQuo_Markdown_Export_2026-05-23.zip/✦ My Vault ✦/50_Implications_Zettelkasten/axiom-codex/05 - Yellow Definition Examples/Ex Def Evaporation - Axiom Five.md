---
class: B
tags:
  - Unrecognized Photograph
---
# Ex Def Evaporation - Axiom Five

## Assertion
Evaporation is shown when a photograph loses its face because no one has looked at it with recognition for years.

## Upward Abstraction Link
[[Def Evaporation]]

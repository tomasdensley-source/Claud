---
class: A
tags:
  - Witnessed Act
  - Irreversible Sight
---
# Ex Def Knowing - Witnessed Act

## Assertion
A witnessed act shows knowing because the witness cannot honestly return to not-having-seen.

## Upward Abstraction Link
[[Def Knowing]]

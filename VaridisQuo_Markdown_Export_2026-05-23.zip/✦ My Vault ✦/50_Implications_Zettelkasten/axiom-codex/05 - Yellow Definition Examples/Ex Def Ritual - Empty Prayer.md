---
class: A
tags:
  - Empty Prayer
  - Words After Absence
---
# Ex Def Ritual - Empty Prayer

## Assertion
An empty prayer is ritual captured by anesthesia when the words continue after attention has left.

## Upward Abstraction Links
[[Def Ritual]]

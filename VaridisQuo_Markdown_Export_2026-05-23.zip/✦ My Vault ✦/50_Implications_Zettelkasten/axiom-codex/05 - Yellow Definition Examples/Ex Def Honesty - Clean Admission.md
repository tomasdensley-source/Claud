---
class: A
tags:
  - Preemptive Confession
---
# Ex Def Honesty - Clean Admission

## Assertion
Honesty is exemplified by saying the costly thing before the cost compounds.

## Upward Abstraction Link
[[Def Honesty]]

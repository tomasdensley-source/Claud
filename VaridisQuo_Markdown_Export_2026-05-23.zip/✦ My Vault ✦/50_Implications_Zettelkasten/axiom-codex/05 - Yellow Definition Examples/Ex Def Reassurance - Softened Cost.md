---
class: A
tags:
  - Urgency-Lowering Words
  - Unanswered Truth
---
# Ex Def Reassurance - Softened Cost

## Assertion
Reassurance is exemplified by words that make the truth feel less urgent before the truth has been answered.

## Upward Abstraction Link
[[Def Reassurance]]

---
class: A
tags:
  - Purpose-Outliving System
  - Departed Purpose
---
# Ex Def Anemurge - Empty Operation

## Assertion
Anemurge is exemplified by a system that keeps rerunning procedures after their living purpose is gone.

## Upward Abstraction Link
[[Def Anemurge]]

---
class: A
tags:
  - Naming Grants Being
  - Distinction Defeats Absence
---
# Ex Def Existence - Named Thing

## Assertion
A named thing shows existence because distinction lets it stand where undifferentiated absence could not.

## Upward Abstraction Link
[[Def Existence]]

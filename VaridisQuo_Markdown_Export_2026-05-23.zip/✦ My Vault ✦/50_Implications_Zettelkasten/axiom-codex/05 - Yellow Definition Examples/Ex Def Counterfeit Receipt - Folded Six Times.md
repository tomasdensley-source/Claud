---
class: A
tags:
  - False Account
  - Constant Upkeep
---
# Ex Def Counterfeit Receipt - Folded Six Times

## Assertion
Counterfeit receipt is exemplified by a false account that requires constant management to keep working.

## Upward Abstraction Link
[[Def Counterfeit Receipt]]

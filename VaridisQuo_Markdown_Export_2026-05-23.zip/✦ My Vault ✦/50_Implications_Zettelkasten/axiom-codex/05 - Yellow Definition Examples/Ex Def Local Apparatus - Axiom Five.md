---
class: A
tags:
  - Grief-Naming Ban
  - Politeness-Keeping Machine
---
# Ex Def Local Apparatus - Axiom Five

## Assertion
Local Apparatus is shown when a family rule against naming grief becomes a small machine that keeps every dinner polite and unreal.

## Upward Abstraction Link
[[Def Local Apparatus]]

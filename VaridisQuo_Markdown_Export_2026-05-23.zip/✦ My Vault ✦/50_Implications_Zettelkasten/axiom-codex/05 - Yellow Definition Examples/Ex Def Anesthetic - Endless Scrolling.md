---
class: B
tags:
  - Action-Blocking Scroll
---

# Ex Def Anesthetic - Endless Scrolling

## Assertion
Endless scrolling becomes anesthetic when it keeps awareness too numb to become action.

## Definition
This yellow note is a concrete example of the purple definition it links to.

## Upward Abstraction Links
[[Def Anesthetic]]

---
class: A
tags:
  - Smooth Story
  - Confession-Dodging Explanation
---
# Ex Def Clerk - Smooth Story

## Assertion
A smooth story is the clerk at work when it explains away the rough edge that would have required confession.

## Upward Abstraction Links
[[Def Clerk]]

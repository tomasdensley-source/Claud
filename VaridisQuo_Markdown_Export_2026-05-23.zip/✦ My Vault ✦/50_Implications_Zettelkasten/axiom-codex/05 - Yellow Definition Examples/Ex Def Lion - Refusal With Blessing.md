---
class: A
tags:
  - Resentment-Barred No
---
# Ex Def Lion - Refusal With Blessing

## Assertion
Refusal with blessing is an example of lion because the No is real while charity prevents resentment from ruling the exit.

## Upward Abstraction Link
[[Def Lion]]

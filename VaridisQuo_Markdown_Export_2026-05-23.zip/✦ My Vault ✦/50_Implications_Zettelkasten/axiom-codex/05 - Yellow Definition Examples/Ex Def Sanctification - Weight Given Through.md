---
class: A
tags:
  - Passed-Through Burden
  - Hub Transit
---
# Ex Def Sanctification - Weight Given Through

## Assertion
Weight given through is an example of sanctification because burden moves through the opened Hub instead of ending in the creature.

## Upward Abstraction Link
[[Def Sanctification]]

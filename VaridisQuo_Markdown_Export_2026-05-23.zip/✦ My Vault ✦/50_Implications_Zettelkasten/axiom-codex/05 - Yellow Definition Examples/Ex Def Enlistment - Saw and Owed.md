---
class: A
tags:
  - Seeing-Born Debt
---
# Ex Def Enlistment - Saw and Owed

## Assertion
A witness sees harm done and becomes enlisted because the seeing itself creates an owed response.

## Upward Abstraction Links
[[Def Enlistment]]

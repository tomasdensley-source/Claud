---
class: B
tags:
  - Unbinding Blur
---
# Ex Def Fog - Blurred Ledger

## Assertion
A blurred ledger is fog when the entries remain present but cannot be read well enough to bind anyone.

## Upward Abstraction Links
[[Def Fog]]

---
class: A
tags:
  - Fitting Story-Parts
  - Unproven Faithfulness
---
# Ex Def Coherence - Fitting Pieces

## Assertion
Coherence is exemplified by story-parts fitting together even before the account has proven faithful.

## Upward Abstraction Link
[[Def Coherence]]

---
class: A
tags:
  - Unrepaired Hinge
  - Defect-Centered Rearrangement
---
# Ex Def Glaw - Loose Hinge

## Assertion
A loose hinge becomes a Glaw when the house rearranges itself around never repairing it.

## Upward Abstraction Links
[[Def Glaw]]

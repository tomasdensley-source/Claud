---
class: B
tags:
  - Avoidance Family-Map
---
# Ex Def Geography - Axiom Five

## Assertion
Geography is shown when the path around a locked conversation becomes a map the whole family walks.

## Upward Abstraction Link
[[Def Geography]]

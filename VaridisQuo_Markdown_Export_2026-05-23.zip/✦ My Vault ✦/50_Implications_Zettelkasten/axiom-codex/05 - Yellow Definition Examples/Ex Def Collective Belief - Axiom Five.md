---
class: A
tags:
  - Sterile Queue
  - Obedience-Sustained Form
---
# Ex Def Collective Belief - Axiom Five

## Assertion
Collective Belief is shown when everyone queues in the same sterile corridor, and the corridor survives by being obeyed.

## Upward Abstraction Link
[[Def Collective Belief]]

---
class: A
tags:
  - Complete-Sounding Excuse
  - Untouched Evidence
---
# Ex Def Plausibility - Believable Excuse

## Assertion
Plausibility is exemplified by an excuse that sounds complete but leaves the hardest evidence untouched.

## Upward Abstraction Link
[[Def Plausibility]]

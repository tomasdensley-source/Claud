---
class: A
tags:
  - Event Sequencing
  - Beginning-Middle-Consequence
---
# Ex Def Narrative - Ordered Account

## Assertion
Narrative is exemplified by arranging scattered events into beginning, middle, and consequence.

## Upward Abstraction Link
[[Def Narrative]]

---
class: A
tags:
  - Uncertainty-Admitting Report
  - Purple-Form Instance
---

# Ex Def Accuracy - Rough Report

## Assertion
Accuracy is exemplified by a report that admits uncertainty rather than sanding the event into a cleaner shape.

## Definition
This yellow note is a concrete example of a purple definition-form implication.

## Upward Abstraction Link
[[Def Accuracy]]

---
class: A
tags:
  - Bounded Recognizability
---
# Ex Def Distinguishable - Line Around Shape

## Assertion
A line around a shape shows distinguishability because the shape can be recognized apart from its field.

## Upward Abstraction Link
[[Def Distinguishable]]

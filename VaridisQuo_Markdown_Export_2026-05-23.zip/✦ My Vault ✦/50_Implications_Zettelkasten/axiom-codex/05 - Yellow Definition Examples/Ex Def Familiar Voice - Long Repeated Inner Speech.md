---
class: B
tags:
  - Believed-By-Repetition Phrase
---
# Ex Def Familiar Voice - Long Repeated Inner Speech

## Assertion
Familiar voice is exemplified by the self believing an inner phrase because it has heard it for years.

## Upward Abstraction Link
[[Def Familiar Voice]]

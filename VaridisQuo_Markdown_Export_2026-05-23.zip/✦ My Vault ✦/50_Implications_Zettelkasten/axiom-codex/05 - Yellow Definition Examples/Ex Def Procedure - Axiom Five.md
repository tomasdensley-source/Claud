---
class: A
tags:
  - Repeating Agenda
  - Forgotten Decision
---
# Ex Def Procedure - Axiom Five

## Assertion
Procedure is shown when the meeting repeats its agenda after everyone has forgotten the decision it was built to serve.

## Upward Abstraction Link
[[Def Procedure]]

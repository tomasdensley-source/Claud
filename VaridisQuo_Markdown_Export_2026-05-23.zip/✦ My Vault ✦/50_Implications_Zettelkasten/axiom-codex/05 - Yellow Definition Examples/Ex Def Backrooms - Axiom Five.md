---
class: B
tags:
  - Uncertainty-Lawed Corridor
---
# Ex Def Backrooms - Axiom Five

## Assertion
Backrooms is shown when a corridor repeats until the visitor realizes the building is maintaining uncertainty as its only law.

## Upward Abstraction Link
[[Def Backrooms]]

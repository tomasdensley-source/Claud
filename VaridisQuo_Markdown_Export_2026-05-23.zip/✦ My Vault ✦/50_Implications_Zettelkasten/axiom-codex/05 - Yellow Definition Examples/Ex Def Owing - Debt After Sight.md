---
class: A
tags:
  - Debt After Sight
  - Perception Becomes Obligation
---
# Ex Def Owing - Debt After Sight

## Assertion
Debt after sight shows owing because perception has become obligation.

## Upward Abstraction Link
[[Def Owing]]

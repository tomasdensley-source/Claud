---
class: A
tags:
  - Floor Hum
  - Vibrating Unpaid Awareness
---
# Ex Def Dread - Floor Hum

## Assertion
A floor hum is dread when the room seems calm but unpaid awareness vibrates underneath it.

## Upward Abstraction Links
[[Def Dread]]

---
class: A
tags:
  - Avoided Conversation
  - Reach-Blocking Routines
---
# Ex Def Apparatus - Repeated Refusal Machine

## Assertion
A person avoids one difficult conversation, then builds routines, explanations, and schedules that make the conversation impossible to reach.

## Upward Abstraction Links
[[Def Apparatus]]

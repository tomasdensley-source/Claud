---
class: A
tags:
  - Sustained Name
  - Careful Utterance
---
# Ex Def Attention - Axiom Five

## Assertion
Attention is shown when a name stays alive because someone still says it carefully.

## Upward Abstraction Link
[[Def Attention]]

---
class: B
tags:
  - Contactless Polish
---
# Ex Def Smoothness - Sanded Account

## Assertion
Smoothness is exemplified by an account so polished that no contact point with reality remains visible.

## Upward Abstraction Link
[[Def Smoothness]]

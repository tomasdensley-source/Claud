---
class: A
tags:
  - Floor Line
  - Answerable Halving
---
# Ex Def Distinction - Axiom Five

## Assertion
Distinction is shown when a line on the floor turns a room into two answerable territories.

## Upward Abstraction Link
[[Def Distinction]]

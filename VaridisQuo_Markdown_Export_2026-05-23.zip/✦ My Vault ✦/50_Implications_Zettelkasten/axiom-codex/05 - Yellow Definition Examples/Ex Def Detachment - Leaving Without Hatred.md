---
class: A
tags:
  - Enmity-Free Departure
---
# Ex Def Detachment - Leaving Without Hatred

## Assertion
Leaving without hatred is an example of detachment because separation occurs without making the source into final enemy.

## Upward Abstraction Link
[[Def Detachment]]

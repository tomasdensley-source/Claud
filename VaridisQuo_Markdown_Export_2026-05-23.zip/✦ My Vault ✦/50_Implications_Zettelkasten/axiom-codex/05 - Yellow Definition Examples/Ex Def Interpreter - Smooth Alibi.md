---
class: B
tags:
  - Fact-Erasing Explanation
---
# Ex Def Interpreter - Smooth Alibi

## Assertion
Interpreter is exemplified when a person explains a harmful act so smoothly that the missing fact disappears from view.

## Upward Abstraction Link
[[Def Interpreter]]

---
class: B
tags:
  - Undeniable Entered Name
---
# Ex Def Registered - Entered Name

## Assertion
An entered name shows registration because it can no longer pretend it was never received.

## Upward Abstraction Link
[[Def Registered]]

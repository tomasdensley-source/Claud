---
class: A
tags:
  - Perfect Lie
  - Internal-Not-External Fit
---
# Ex Def Coherence - Perfect Lie

## Assertion
A perfect lie can have coherence because all its parts fit one another while failing to fit the event.

## Upward Abstraction Links
[[Def Coherence]]

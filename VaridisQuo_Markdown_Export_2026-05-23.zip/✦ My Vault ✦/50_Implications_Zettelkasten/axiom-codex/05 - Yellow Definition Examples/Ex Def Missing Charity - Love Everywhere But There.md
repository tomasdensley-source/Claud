---
class: A
tags:
  - Diffuse Affection
  - Skipped Particular
---
# Ex Def Missing Charity - Love Everywhere But There

## Assertion
Love everywhere but there is an example of missing charity because abstract love avoids the specific relation that would complete the transformation.

## Upward Abstraction Link
[[Def Missing Charity]]

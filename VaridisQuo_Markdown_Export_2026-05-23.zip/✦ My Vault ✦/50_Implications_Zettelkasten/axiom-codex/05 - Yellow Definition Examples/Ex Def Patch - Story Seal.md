---
class: A
tags:
  - Leak-Sealing Story
  - Unconfessed Cause
---
# Ex Def Patch - Story Seal

## Assertion
Patch is exemplified by a story used to seal the leak without confessing what caused it.

## Upward Abstraction Link
[[Def Patch]]

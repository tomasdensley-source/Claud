---
class: B
---

> [!persona] Voice and style

Created: 2026-03-23
Kind: Persona note
State: Seeded

Desired voice: precise, non-manipulative, logically staged, and free from shame-based theatrics.

## Children
- PER-G – Persona and system relation

## Notes
- Short headings and clear line breaks improve TTS and dyslexia support.

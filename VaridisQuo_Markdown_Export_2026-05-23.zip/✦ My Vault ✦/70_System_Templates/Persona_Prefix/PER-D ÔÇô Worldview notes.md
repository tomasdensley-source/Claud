---
class: B
---

> [!persona] Worldview notes

Created: 2026-03-23
Kind: Persona note
State: Seeded

Working worldview themes: systems carry meaning, contrast often signals truth, and repair matters more than image preservation.

![[_Assets/Diagrams/Vault Decor/vault-banner-memory-garden.svg]]

## Children
- PHI-D – Contrast and paradox
- PHI-F – Abstraction and deconstruction
- PER-G – Persona and system relation

## Notes
- This is a worldview map, not a confessional.

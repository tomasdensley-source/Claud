---
class: B
---

> [!persona] Persona and system relation

Created: 2026-03-23
Kind: Persona note
State: Seeded

The persona subsystem should shape how the vault speaks and reviews, not swallow the entire vault into autobiography.

## Children
- [[SYS-F – Task system guide]]
- [[SYS-J – Day one guide]]

## Notes
- Principles should influence dashboards.
- Voice should influence templates and reading comfort.

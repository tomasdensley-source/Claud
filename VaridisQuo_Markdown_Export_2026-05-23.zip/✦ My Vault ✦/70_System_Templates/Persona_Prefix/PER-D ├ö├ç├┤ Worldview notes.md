---
class: B
---
> [!persona] Worldview notes

Created: 2026-03-23
Kind: Persona note
State: Seeded

## Notes
- This is a worldview map, not a confessional.

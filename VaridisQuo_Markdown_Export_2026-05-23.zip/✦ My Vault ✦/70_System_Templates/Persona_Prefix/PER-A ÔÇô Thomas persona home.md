---
class: B
---

> [!persona] Persona home

Created: 2026-03-23
Kind: Persona hub
State: Active

This subsystem keeps the Thomas interview and identity protocol structured, revisitable, and distinct from ordinary dailies.

![[_Assets/Diagrams/Vault Decor/vault-seal-care-gate.svg]]

## Children
- PER-B – Principles ledger
- PER-C – Voice and style
- PER-D – Worldview notes
- PER-E – Postponed questions
- PER-F – Interview session 001
- PER-G – Persona and system relation

## Notes
- Preserve postponed questions exactly.
- Treat sessions as transcript-like blocks.

---
class: B
---
> [!persona] Interview session

Created: 2026-03-23
Kind: Persona interview note
State: Seeded

## Children
- PER-E – Postponed questions
- PER-G – Persona and system relation

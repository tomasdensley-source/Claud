---
class: B
---

> [!persona] Principles ledger

Created: 2026-03-23
Kind: Persona note
State: Seeded

Never base any decision on shame.
Prefer evidence-linked summaries over flattering narratives.
Preserve continuity when interruptions break complex thought.

## Children
- PER-G – Persona and system relation
- PHI-G – Balance and repair

## Notes
- A principle note should stay short enough to read aloud in one pass.

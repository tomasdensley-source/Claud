---
class: B
---

> [!truth] Landing page skeleton

Created: 2026-03-23
Kind: Longform draft
State: Seeded

Seeded business-writing scaffold: problem, proof, offer, process, next step.

## Blocks
- Clear problem statement
- What changes after the work
- Why this approach is credible
- How the engagement runs
- What the next step is

## Notes
- This draft stays modular so proposal and landing-page variants can share a base structure.

---
class: B
---

> [!project] Legacy migration queue

Created: 2026-03-25
Kind: Project
State: Active

This queue controls the staged promotion of useful material from `C:\Users\nicko\Desktop\TV-Legacy\00` into the live vault.

## First Wave Completed
- `07_Thomas_Persona\Batches` -> `07_Persona\Imported\Batches` (`2` markdown files)
- `07_Thomas_Persona\General` -> `07_Persona\Imported\General` (`4` markdown files)
- `05_AI_Tools_and_Guides\APIs_Code` -> `06_Reference\AI\APIs_Code` (`3` markdown files)
- `05_AI_Tools_and_Guides\ChatGPT` -> `06_Reference\AI\ChatGPT` (`5` markdown files)
- `05_AI_Tools_and_Guides\General` -> `06_Reference\AI\General` (`6` markdown files)
- `05_AI_Tools_and_Guides\Prompting` -> `06_Reference\AI\Prompting` (`1` markdown file)
- `14_Reading_Quotes_Philosophy\Philosophy_Essays` -> `05_Sources\Extracted\Legacy Quotes\Philosophy_Essays` (`2` markdown files)
- `14_Reading_Quotes_Philosophy\Quotes` -> `05_Sources\Extracted\Legacy Quotes\Quotes` (`6` markdown files)
- `15_Writing_Literature\Bastion` -> `03_Notes\Drafts\Legacy Writing\Bastion` (`5` markdown files)
- `15_Writing_Literature\Drafts_Notes` -> `03_Notes\Drafts\Legacy Writing\Drafts_Notes` (`15` markdown files)

## Guardrails
- Import markdown only in active migration waves.
- Keep PDFs in cold storage unless they have a clear live-vault use case.
- Keep the live vault single-rooted and mobile-fast.
- Preserve category structure inside each target folder so imported material stays reviewable.

## Exclusions
- Any folder or path containing `Recovered_Root`
- Any folder or path containing `Loose_Root`
- Any folder or path containing `Imported_Branch_`
- `00_Inbox_Unsorted`
- `20 PDFs`
- `98_Misc`
- `99_Scans*`
- `09_Legal*`
- `16_Personal_NSFW`
- `17_Personal_Sensitive_Drugs`
- Any folder ending in `(1)`

## Next Pass
- Review imported persona notes and collapse duplicates into canonical identity notes.
- Review imported AI reference notes and convert any evergreen material into cleaner permanent references.
- Split imported quote and philosophy files into source notes versus synthesis notes.
- Trim legacy writing drafts down to active pieces, then archive the rest inside live-vault cold storage if needed.

## Snapshot
- Backup before this pass: `C:\Users\nicko\Desktop\Thomas-Vault-Backups\Thomas-Vault-20260325-125805`

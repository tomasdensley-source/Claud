---
class: B
---

> [!project] Business offer lab

Created: 2026-03-23
Kind: Project
State: Active

A place for campaigns, offer framing, route logic, and proposal work without muddying the philosophy notes.

## Children
- CMP-A – Outreach campaign note
- CMP-B – Proposal note example
- CMP-C – Territory route note
- ARA-B – Business operations

## Sharp House working files
- [[sharp_house_master_file_thesis_startup_question_mode-3|Sharp House master file]]
- [[sharp-house-prospect-list-v4-inline-map|Sharp House prospect inline map]]
- [[SHS Cold Call Pitch + Questions|SHS cold call pitch and questions]]

## Notes
- Operations notes should stay factual and measurable.
- Use proposal drafts as children, not as project substitutes.

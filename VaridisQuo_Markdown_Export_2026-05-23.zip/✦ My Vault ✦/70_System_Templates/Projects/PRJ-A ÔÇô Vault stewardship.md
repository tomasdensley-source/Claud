---
class: B
---

> [!project] Vault stewardship

Created: 2026-03-23
Kind: Project
State: Active

This project holds the maintenance, audit, and refinement work that keeps the vault coherent over time.

## Children
- DEC-A – Vault design decisions
- [[SYS-A – Vault constitution]]
- [[SYS-I – CSS system guide]]
- [[ACT-F – Recovery and re-triage]]

## Outputs
- Keep audits green.
- Keep templates legible.
- Keep graph structure alive.

---
class: B
---

> [!project] Writing and research pipeline

Created: 2026-03-23
Kind: Project
State: Active

This project converts source extraction into durable notes and long-form drafts.

## Children
- WRI-A – Writing pipeline
- LNG-A – Manifesto draft scaffold
- SOU-C – Example truth index
- [[SYS-N – Evidence interpretation speculation]]

## Notes
- Index first. Shape later.
- Use examples after the truth statement is stable.

---
class: B
---
> [!project] Legacy migration queue

Created: 2026-03-25
Kind: Project
State: Active

This queue controls the staged promotion of useful material from `C:\Users\nicko\Desktop\◉\03 - Legacy Archive\01 - LEGACY VAULT - ARCHIVE ONLY` into the live vault.

## Next Pass
- Review imported persona notes and collapse duplicates into canonical identity notes.
- Review imported AI reference notes and convert any evergreen material into cleaner permanent references.
- Split imported quote and philosophy files into source notes versus synthesis notes.
- Trim legacy writing drafts down to active pieces, then archive the rest inside live-vault cold storage if needed.
- Run the parallel Varidis intake described in PRJ-E – Varidis Quo intake batch 001 before widening the next migration wave.

## Snapshot
- Backup before this pass: `C:\Users\nicko\Desktop\◉\04 - Backups\Thomas-Vault-20260325-125805`

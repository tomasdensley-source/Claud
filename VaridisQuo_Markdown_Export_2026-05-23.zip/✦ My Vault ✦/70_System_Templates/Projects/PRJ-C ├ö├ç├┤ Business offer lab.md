---
class: B
---
> [!project] Business offer lab

Created: 2026-03-23
Kind: Project
State: Active

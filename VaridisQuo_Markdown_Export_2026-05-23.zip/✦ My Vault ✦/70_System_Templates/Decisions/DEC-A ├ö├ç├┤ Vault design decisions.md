---
class: B
---

> [!project] Decision ledger

Created: 2026-03-23
Kind: Decision ledger
State: Seeded

A running ledger of structural decisions is useful when the vault grows and older choices need to be reconsidered.

## Decisions
- 2026-03-23: Parent links are implicit backlinks only.
- 2026-03-23: Sibling tags describe commonality, not loose topics.
- 2026-03-23: Daily review uses re-triage language instead of failure language.

## Children
- [[SYS-D – Link direction guide]]
- [[SYS-E – Sibling tag guide]]
- [[SYS-F – Task system guide]]

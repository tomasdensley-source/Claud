---
class: B
---

> [!example] Repair after rupture

Created: 2026-03-23
Kind: Example note
State: Seeded
Tags:  

Seeded demo example: after a missed commitment, the useful sequence is notice, name the consequence, choose a repair, and schedule the next check.

## Notes
- This example shows why guilt can remain specific while shame collapses the whole review frame.

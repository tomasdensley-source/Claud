---
class: B
---

> [!example] Child implies parent

Created: 2026-03-23
Kind: Example note
State: Seeded
Tags:  

Seeded demo example: a note about one concrete repair case implies the broader idea of repair logic without needing a forward parent declaration.

## Notes
- Backlinks recover the broader structure automatically.
- This is the operating logic behind the whole vault.

---
class: B
---

> [!example] Voice capture to triage

Created: 2026-03-23
Kind: Example note
State: Seeded
Tags:  

Seeded demo example: a spoken fragment enters inbox immediately, then later becomes either a concept note, an action note, or a source note.

## Notes
- The system protects continuity by separating capture from classification.

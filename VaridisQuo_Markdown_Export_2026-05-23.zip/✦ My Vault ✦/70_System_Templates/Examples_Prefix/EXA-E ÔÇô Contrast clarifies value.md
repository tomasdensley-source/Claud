---
class: B
---

> [!example] Contrast clarifies value

Created: 2026-03-23
Kind: Example note
State: Seeded
Tags:  

Seeded demo example: compare a shame-based review phrase with a repair-based review phrase and the system value becomes obvious.

## Notes
- Contrast is often the fastest path to a durable principle.

---
class: B
---

> [!example] Abstracting a pattern

Created: 2026-03-23
Kind: Example note
State: Seeded
Tags:  

Seeded demo example: after several repair cases, abstract the shared sequence into a reusable protocol.

## Notes
- Abstraction is useful when the repeated structure is now stable enough to travel.

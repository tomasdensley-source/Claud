---
class: B
---

> [!example] Deconstructing a claim

Created: 2026-03-23
Kind: Example note
State: Seeded
Tags:  

Seeded demo example: split a sentence into terms, relations, scope, evidence, and unstated assumptions before judging it.

## Notes
- Deconstruction exposes moving parts before abstraction recombines them into a portable pattern.

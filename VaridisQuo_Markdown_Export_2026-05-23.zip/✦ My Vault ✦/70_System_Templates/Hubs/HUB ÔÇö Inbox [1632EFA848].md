﻿---
class: B
type: inbox
created: 2026-01-24
---
# HUB â€” Inbox
**Rule:** capture fast. Organize later.
## Captures
- 2026-01-24 â€”

﻿---
class: B
---
### **USE THIS NOTE WHEN YOUâ€™RE  STUCK**âš¡
â€¢ Shows what ideas currently matter
â€¢ Update it during weekly review (or when something nags you)  
â€¢ If unsure what to work on â†’ start here
---
## ðŸ”¥ Most Edited Notes This Week
(Notes that are pulling attention â€” often signals of convergence)
---
## â“ Open Questions
(Tag these with `#unanswered` so theyâ€™re searchable)
---
## ðŸ§ª Axioms Iâ€™m Testing
(Principles Iâ€™m actively applying, questioning, or refining)
---
## ðŸ”— Notes to Connect
(Things that *feel* related but arenâ€™t linked yet)

---

## ðŸŒ± Fleeting Notes to Promote
(Seeds ready to distill, expand, or archive)

---

## ðŸ§­ Weekly Reflection
(One or two sentences is enough)

- What pattern am I starting to see?

- Where is clarity increasing?

- Where am I over-extracting or under-distilling?

---

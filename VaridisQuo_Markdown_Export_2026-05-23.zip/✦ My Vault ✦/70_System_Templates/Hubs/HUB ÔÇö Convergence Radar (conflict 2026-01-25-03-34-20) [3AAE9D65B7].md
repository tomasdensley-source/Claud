---
class: B
---
[[HUB - Home]]

---
#growth 

---
[[FQ - Education Loves the Beautiful (Plato)]]
## ❓ Open Questions
(Tag these with `#unanswered` so they’re searchable)

- [x] 
---

---

## 🔗 Notes to Connect
(Things that *feel* related but aren’t linked yet)

---

## 🌱 Fleeting Notes to Promote
(Seeds ready to distill, expand, or archive)

---

## 🧭 Weekly Reflection
(One or two sentences is enough)

- What pattern am I starting to see?

- Where is clarity increasing?

- Where am I over-extracting or under-distilling?

---

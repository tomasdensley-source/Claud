---
class: B
---


[[HUB - Home]]



### **USE THIS NOTE WHEN YOU’RE  STUCK**⚡
• Shows what ideas currently matter
• Update it during weekly review (or when something nags you)  
• If unsure what to work on → start here

---


## 🔥 Most Edited Notes This Week
(Notes that are pulling attention — often signals of convergence)


---

## ❓ Open Questions
(Tag these with `#unanswered` so they’re searchable)


---

## 🧪 Axioms I’m Testing
(Principles I’m actively applying, questioning, or refining)

---

## 🔗 Notes to Connect
(Things that *feel* related but aren’t linked yet)


---

## 🌱 Fleeting Notes to Promote
(Seeds ready to distill, expand, or archive)


---

## 🧭 Weekly Reflection
(One or two sentences is enough)

- What pattern am I starting to see?

- Where is clarity increasing?

- Where am I over-extracting or under-distilling?

---
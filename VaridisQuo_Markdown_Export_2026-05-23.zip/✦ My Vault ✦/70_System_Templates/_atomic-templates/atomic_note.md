---
class: B
---

> [!atom-{type}] {Type capitalized}
> **type:** {axiom | definition | principle | theorem | conjecture | example | convention}
> **child:** Z{parent-id} — {short label}     *(or: implicit — see Assumption 1)*
> **downstream_applications:** Z{child-id} — {short label}       *(or: none yet)*

# Z{id} -- {title}

## Assertion

{One declarative claim. Not numbered. Should be statable in one sentence; one paragraph at most. The note's central truth-claim. The whole note exists to ground this assertion.}

## Assumptions

{At least one. Typical 2–5. Default 3 when nothing else dictates the count. Author however many the assertion actually depends on; do not pad to a target. Number them. Define each in one or two sentences.}

1. **{Short name of assumption.}** {Definition: what this assumption claims, why it is needed, what the assertion would lose if this assumption did not hold.}

2. **{Short name.}** {Definition.}

3. **{Short name.}** {Definition.}

## Body

{Supporting prose: how the assertion arises from the assumptions, what counts as evidence for it, what its operational consequences are, how it relates to neighboring notes. The body is the bulk of the note — it must be substantially longer than the assertion. The body may not introduce a second assertion; if a second claim arises, it becomes its own note with its own parent link to this one.}

---

*Source: {citation — Monolith section, source note, or external reference}*

---
class: B
---

> [!rating] ★★★★☆ / 5 — Confirmed by Thomas: ☐
> **Signals:** {length, first-person density, doctrine language, provenance}
> **Rationale:** {one-sentence justification for the star count}

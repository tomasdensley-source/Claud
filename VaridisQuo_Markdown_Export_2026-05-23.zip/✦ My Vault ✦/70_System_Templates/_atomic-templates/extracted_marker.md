---
class: B
---

> [!extracted] Atomized to Zettelkasten — Z{id} on v{version}
> {short label of what was extracted}

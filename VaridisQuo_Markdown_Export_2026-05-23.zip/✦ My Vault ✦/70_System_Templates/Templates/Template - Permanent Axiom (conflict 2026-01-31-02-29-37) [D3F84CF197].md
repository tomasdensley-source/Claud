---
class: B
---


[[Start - Permanent]]




Template — Permanent Axiom
<!-- Template — Permanent Axiom -->
---
type: permanent
subtype: axiom
status: seed
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Axiom —
## Summary / Thesis (one line)
## Explanation
## Evidence & Examples
## Contrast / Counterpoint
## Connections
-  — (why this link exists)
-  — (why this link exists)
## Further Questions
-

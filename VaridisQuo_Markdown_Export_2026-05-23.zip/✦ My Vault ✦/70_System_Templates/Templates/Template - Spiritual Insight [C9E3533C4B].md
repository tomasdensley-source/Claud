---
class: B
---
Template — Spiritual Insight

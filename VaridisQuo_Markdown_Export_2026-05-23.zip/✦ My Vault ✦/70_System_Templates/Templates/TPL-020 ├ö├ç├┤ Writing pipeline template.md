---
class: B
---

> [!template] Writing pipeline template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for draft planning that inherits from indexed research.

## Front
> [!truth] Writing pipeline

Created: YYYY-MM-DD
Kind: Writing pipeline note
State: Active

## Pipeline
1. Collect sources
2. Extract claims
3. Index truths
4. Attach examples
5. Draft in longform

## Children
- <ID – truth index>
- <ID – longform draft>

---
class: B
---

> [!template] Weekly review template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for weekly re-triage and state correction.

## Front
> [!daily] Weekly review

Created: YYYY-MM-DD
Kind: Weekly review
State: Active

## Review
- What moved
- What stalled
- What should be archived
- What needs a different state

## Carry forward
- What deserves a live place next week
- What should move to waiting, scheduled, or someday

## Reset
- What needs review first
- What is the smallest next step

## Children
- <ID – weekly execution map>
- <ID – waiting dashboard>

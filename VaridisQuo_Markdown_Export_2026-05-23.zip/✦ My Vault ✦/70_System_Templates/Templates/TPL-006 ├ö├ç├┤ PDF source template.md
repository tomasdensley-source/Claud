---
class: B
---

> [!template] PDF source template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for a quick PDF-specific intake note when mobile capture is fast.

## Front
> [!source] PDF source

Created: YYYY-MM-DD
Kind: PDF source note
State: Draft
Attachment: OriginalFilename.pdf
Source state: new

## Next moves
- Create or link companion note.
- Record active reading goal.
- Mark whether the file should stay active or later go cold.

## Mobile note
- If the PDF is large, keep the note active first and move the file cold later.

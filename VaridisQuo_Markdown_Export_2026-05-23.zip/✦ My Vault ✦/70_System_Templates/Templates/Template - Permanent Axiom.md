---
class: B
---
Template â€” Permanent Axiom
<!-- Template â€” Permanent Axiom -->
---
type: permanent
subtype: axiom
status: seed
created: 2026-03-28
---
# Axiom â€”
## Summary / Thesis (one line)
## Explanation
## Evidence & Examples
## Contrast / Counterpoint
## Connections
-  â€” (why this link exists)
-  â€” (why this link exists)
## Further Questions
-

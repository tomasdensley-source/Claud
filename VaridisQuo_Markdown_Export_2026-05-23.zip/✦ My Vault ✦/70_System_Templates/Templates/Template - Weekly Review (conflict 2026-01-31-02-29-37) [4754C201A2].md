---
class: B
---


[[Templates]]

Template — Weekly Review
<!-- Template — Weekly Review -->
---
type: weekly_review
week: <% tp.date.now("YYYY-[W]WW") %>
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Weekly Review — <% tp.date.now("YYYY-[W]WW") %>
## Highlights (top 3)
## Patterns I notice
## Axioms strengthened this week
-  — how it got stronger
## Open questions
- #unanswered
## Gardening (merge / prune / link)
- [ ] Merge duplicates
- [ ] Add 10 links
- [ ] Promote 1 Fleeting note to Permanent
## Next week focus

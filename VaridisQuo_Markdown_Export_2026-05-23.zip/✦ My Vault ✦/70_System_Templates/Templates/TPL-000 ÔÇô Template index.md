---
class: B
---

> [!template] Template index

Created: 2026-03-23
Kind: Template index
State: Active

Every major note type has a ready-to-duplicate template here. The templates are usable even without Templater.

## Children
- TPL-001 – Atomic concept template
- TPL-002 – Example note template
- TPL-003 – Contrast tension template
- TPL-004 – Hub MOC template
- TPL-005 – Source companion template
- TPL-006 – PDF source template
- TPL-007 – Truth statement index template
- TPL-008 – Longform draft template
- TPL-009 – Project note template
- TPL-010 – Area responsibility template
- TPL-011 – Daily note template
- TPL-012 – Weekly review template
- TPL-013 – Persona interview template
- TPL-014 – Reference entry template
- TPL-015 – Public-domain reference template
- TPL-016 – Decision ledger template
- TPL-017 – Reading extraction template
- TPL-018 – Graph triage template
- TPL-019 – Campaign operations template
- TPL-020 – Writing pipeline template
- TPL-021 – Manifesto template
- TPL-022 – Truth extraction template
- TPL-023 – Example attachment template

## Notes
- Templates keep syntax light.
- Duplicate, rename with an ID, then fill in the body metadata.

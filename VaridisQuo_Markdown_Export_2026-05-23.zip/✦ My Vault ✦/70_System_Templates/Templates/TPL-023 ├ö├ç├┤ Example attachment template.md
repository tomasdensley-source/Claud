---
class: B
---

> [!template] Example attachment template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use after indexing when a permanent note needs concrete grounding.

## Front
> [!example] Example attachment

Created: YYYY-MM-DD
Kind: Example attachment note
State: Draft
Tags: <shared-commonality>

## Body
- State the example clearly.
- Say what claim it sharpens.
- Keep the example narrow enough to remain child-sized.

## Children
- <ID – narrower example or evidence note>

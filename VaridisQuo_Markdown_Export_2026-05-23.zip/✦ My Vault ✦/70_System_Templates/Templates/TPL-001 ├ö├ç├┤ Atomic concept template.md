---
class: B
---

> [!template] Atomic concept template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for durable claims, concepts, and structural insights.

## Front
> [!concept] Atomic concept

Created: YYYY-MM-DD
Kind: Atomic concept
State: Draft
Tags: <shared-commonality>

## Body
- State the concept in 2 to 5 sentences.
- Keep the language precise and compact.

## Children
- <ID – narrower child note>

## Examples
- <ID – example note>

## Sources
- <ID – source or truth index>

## Notes
- No parent section. Use backlinks.

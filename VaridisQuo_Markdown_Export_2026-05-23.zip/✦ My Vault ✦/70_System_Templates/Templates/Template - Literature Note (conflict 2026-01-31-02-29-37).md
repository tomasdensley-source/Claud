﻿---
class: B
---

> [!nav]
> Parent: [[10 Notes/Home|Home]]
> Siblings: [[10 Notes/Template - Daily|Template - Daily]] · [[10 Notes/Template - Literature Note|Template - Literature Note]]
> Children: none

Template â€” Literature Note
Protocol Zeta+
Page 13
<!-- Template â€” Literature Note -->
---
type: literature
source_title:
author:
published:
link:
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Lit â€” {{source_title}}
## Summary
## Notable Excerpts (with page/timestamp)
## Personal Reflections
## Connections
-  â€” why this connects
-  â€” why this connects

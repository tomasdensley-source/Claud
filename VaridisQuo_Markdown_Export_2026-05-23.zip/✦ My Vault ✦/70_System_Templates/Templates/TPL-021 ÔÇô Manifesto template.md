---
class: B
---

> [!template] Manifesto template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for a forceful longform note that needs claims, counterpressure, and evidence-linked sequencing.

## Front
> [!truth] Manifesto draft

Created: YYYY-MM-DD
Kind: Manifesto draft
State: Draft

## Sections
- Pressure statement
- Core claims
- Evidence chain
- Counterpressure
- Repair or design implication

## Children
- <ID – truth index>
- <ID – example attachment note>

---
class: B
---

> [!template] Reading extraction template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use when pulling claims from a source.

## Front
> [!truth] Reading extraction

Created: YYYY-MM-DD
Kind: Reading / extraction note
State: Draft
Source state: extracting

## Legend
- Evidence = what the source actually gives.
- Interpretation = your best reading.
- Speculation = useful but not yet grounded.

## Evidence
-

## Interpretation
-

## Speculation
-

## Children
- <ID – promoted permanent note>
- <ID – truth index note>

## Notes
- Index first. Edit later.

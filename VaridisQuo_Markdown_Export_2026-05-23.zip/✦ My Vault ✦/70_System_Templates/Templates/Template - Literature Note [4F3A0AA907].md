---
class: B
---
Template — Literature Note

---
class: B
---
Template â€” Daily Journal
<!-- Template â€” Daily Journal -->
---
type: daily
created: 2026-03-28
---
# Daily â€” 2026-03-28
## Morning Intention
- Today I am grateful for:
- Today I will focus on:
## Prompt (random or chosen)
-
## Capture (fast, messy allowed)
-
## Evening Reflection
- What did I learn today (factually or spiritually)?
- What challenged me? What surprised me?
## One Link I Made Today
-  â€” (why this link exists)
## Daily Linking Checklist
- [ ] Create 1 new link between two older notes.
- [ ] Add 1 link-reason annotation.
- [ ] Promote 1 Fleeting note (distill / expand / archive).

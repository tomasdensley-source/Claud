---
class: B
---

> [!template] Daily note template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for daily execution with low-shame review language.

## Front
> [!daily] Daily note

Created: YYYY-MM-DD
Kind: Daily note
State: Active

## Do now
- [ ]

## Follow up
- [ ]
Waiting since:
Next ping:

## Think later
- [ ]

## Deep work candidate
- [ ]

## Needs review
- [ ]
Blocked by:

## Carry forward
- [ ]

## Done
- [x]

## Children
- <ID – project or source note touched today>

## Notes
- Move stale work into a better state. Do not write failure language.
- Prefer child links in the body. Let parent notes appear as backlinks.

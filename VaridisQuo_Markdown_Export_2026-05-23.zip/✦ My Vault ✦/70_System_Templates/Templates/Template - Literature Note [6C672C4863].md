---
class: B
---
[[Templates Index]]

Template — Literature Note

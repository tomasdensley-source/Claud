---
class: B
---

> [!template] Project note template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for active finite work.

## Front
> [!project] Project

Created: YYYY-MM-DD
Kind: Project
State: Active

## Outcome
- Desired result
- Constraints
- Current next step

## Children
- <ID – dashboard or decision note>
- <ID – child draft or campaign note>

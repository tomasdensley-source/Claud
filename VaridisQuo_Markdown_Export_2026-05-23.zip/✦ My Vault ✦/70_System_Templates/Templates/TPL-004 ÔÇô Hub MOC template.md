---
class: B
---

> [!template] Hub MOC template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for map notes and graph routes.

## Front
> [!map] Hub / MOC

Created: YYYY-MM-DD
Kind: Hub / MOC
State: Active

## Children
- <ID – first child>
- <ID – second child>

## Notes
- Maps should stay broad and route downward only.

---
class: B
---

> [!template] Contrast tension template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for paradoxes, tensions, oppositions, and structural contrasts.

## Front
> [!contrast] Contrast / tension

Created: YYYY-MM-DD
Kind: Contrast / tension
State: Draft
Tags: <shared-commonality>

## Body
- Name each side directly.
- Say what pressure or truth the contrast exposes.

## Children
- <ID – example or narrower contrast>

## Notes
- Contrast notes are useful when a flat summary loses something important.

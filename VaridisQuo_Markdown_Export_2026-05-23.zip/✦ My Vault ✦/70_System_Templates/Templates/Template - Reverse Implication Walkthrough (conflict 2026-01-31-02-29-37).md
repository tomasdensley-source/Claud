﻿---
class: B
---

> [!nav]
> Parent: [[10 Notes/Home|Home]]
> Siblings: [[10 Notes/Template - Permanent Axiom|Template - Permanent Axiom]] · [[10 Notes/Template - Reverse Implication Walkthrough|Template - Reverse Implication Walkthrough]]
> Children: none

Template â€” Reverse Implication Walkthrough
<!-- Template â€” Reverse Implication Walkthrough -->
---
type: method
method: reverse_implication
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Reverse Implication â€” Walkthrough
## Theorem / Observation (T)
(Quote, event, pattern, or problem statement)
## What would have to be true?
(List candidate axioms)
## Minimal Axiom Candidate (A*)
(One sentence; remove extra adjectives)
## Whole Herb Check
(What context would this axiom wrongly delete?)
## Extract Check
(What detail is noise? What is structural necessity?)
## Links created (with reasons)
-  â€”
-  â€”
-  â€”
## Next Test
(One small action or question to validate/refine A*)

Protocol Zeta+
Page 15


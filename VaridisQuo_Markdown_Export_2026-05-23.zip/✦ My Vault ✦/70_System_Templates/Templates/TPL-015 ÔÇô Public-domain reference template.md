---
class: B
---

> [!template] Public-domain reference template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for likely-public-domain works with quote-safety caution.

## Front
> [!reference] Public-domain reference

Created: YYYY-MM-DD
Kind: Public-domain reference entry note
State: Draft

## Body
- Work-level confidence
- Edition-level caution
- Best quote-safe route

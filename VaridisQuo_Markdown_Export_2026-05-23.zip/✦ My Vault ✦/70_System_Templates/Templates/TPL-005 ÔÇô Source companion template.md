---
class: B
---

> [!template] Source companion template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use when a PDF or document gets its graph-visible companion.

## Front
> [!source] Source companion

Created: YYYY-MM-DD
Kind: Source companion note
State: Active
Attachment: OriginalFilename.ext
Source state: new

## Why this source
- Why it matters
- What you want from it
- Any quote-safety caution

## Reading mode
- Quick intake or deep extraction
- Keep or move cold later

## Children
- <ID – extraction note>
- <ID – truth index note>

## Notes
- Keep the original source filename unchanged.
- Use `new`, `extracting`, `indexed`, `promoted`, or `cold` as the source state.

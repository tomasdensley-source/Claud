---
class: B
---



[[Start - Daily]]

Template — Daily Journal
<!-- Template — Daily Journal -->
---
type: daily
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Daily — <% tp.date.now("YYYY-MM-DD") %>
## Morning Intention
- Today I am grateful for:
- Today I will focus on:
## Prompt (random or chosen)
-
## Capture (fast, messy allowed)
-
## Evening Reflection
- What did I learn today (factually or spiritually)?
- What challenged me? What surprised me?
## One Link I Made Today
-  — (why this link exists)
## Daily Linking Checklist
- [ ] Create 1 new link between two older notes.
- [ ] Add 1 link-reason annotation.
- [ ] Promote 1 Fleeting note (distill / expand / archive).

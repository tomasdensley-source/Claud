---
class: B
---


[[Templates]]


Template — Spiritual Insight

Protocol Zeta+
Page 14
<!-- Template — Spiritual Insight -->
---
type: spiritual_insight
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Insight —
## Context
(When/where/how it arose)
## Insight
(Describe the realization in detail)
## Meaning
(What it means to you right now)
## Parallels or Validation
-  — parallel from research/philosophy
-  — parallel from lived experience
## Integration
(How you will apply/test it)

﻿---
class: B
---

> [!nav]
> Parent: [[10 Notes/Home|Home]]
> Siblings: [[10 Notes/Template - Literature Note|Template - Literature Note]] · [[10 Notes/Template - Permanent Axiom|Template - Permanent Axiom]]
> Children: none

Template â€” Permanent Axiom
<!-- Template â€” Permanent Axiom -->
---
type: permanent
subtype: axiom
status: seed
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Axiom â€”
## Summary / Thesis (one line)
## Explanation
## Evidence & Examples
## Contrast / Counterpoint
## Connections
-  â€” (why this link exists)
-  â€” (why this link exists)
## Further Questions
-

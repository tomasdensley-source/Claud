﻿---
class: B
---

> [!nav]
> Parent: [[10 Notes/Home|Home]]
> Siblings: [[10 Notes/Template - Weekly Review|Template - Weekly Review]] · [[10 Notes/Templates Index|Templates Index]]
> Children: none

Pipeline Template ðŸ“‹
Lead Template ðŸ“‹

---
class: B
---

> [!template] Persona interview template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for transcript-like interview blocks.

## Front
> [!persona] Persona interview

Created: YYYY-MM-DD
Kind: Persona interview note
State: Active

## Question blocks
1. Question exactly as asked
2. Response block
3. Follow-up block
4. If postponed, move exact wording to postponed ledger

## Children
- <ID – postponed questions>
- <ID – persona relation note>

---
class: B
---

> [!template] Graph triage template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for cluster-level triage or graph maintenance sessions.

## Front
> [!map] Graph triage

Created: YYYY-MM-DD
Kind: Graph triage note
State: Active

## Checks
- Cluster with no clear parent map
- Lonely note that should have backlinks
- Sibling tag that is too generic

## Children
- <ID – graph route map>
- <ID – note to fix>

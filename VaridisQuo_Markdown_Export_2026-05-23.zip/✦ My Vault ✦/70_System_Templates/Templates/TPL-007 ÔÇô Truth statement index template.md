---
class: B
---

> [!template] Truth statement index template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use after extraction and before drafting.

## Front
> [!truth] Truth statement index

Created: YYYY-MM-DD
Kind: Truth statement index note
State: Draft

## Indexed truths
- <ID – permanent note>
- <ID – example note>

## Notes
- Index first. Draft later.

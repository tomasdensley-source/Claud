﻿---
class: B
---
Pipeline Template ðŸ“‹
Lead Template ðŸ“‹

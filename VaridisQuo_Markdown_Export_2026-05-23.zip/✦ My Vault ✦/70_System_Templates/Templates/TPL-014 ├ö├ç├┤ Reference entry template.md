---
class: B
---

> [!template] Reference entry template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for author or work entries in the master reference list.

## Front
> [!reference] Reference entry

Created: YYYY-MM-DD
Kind: Reference entry note
State: Draft

## Body
- Why it matters
- What domain it helps with
- Edition or translation caution if relevant

## Children
- <ID – public-domain subset note if applicable>

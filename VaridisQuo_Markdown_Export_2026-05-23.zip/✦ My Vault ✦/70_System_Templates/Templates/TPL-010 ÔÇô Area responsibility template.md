---
class: B
---

> [!template] Area responsibility template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for recurring responsibilities that do not end after one deliverable.

## Front
> [!project] Area / responsibility

Created: YYYY-MM-DD
Kind: Area / responsibility
State: Active

## Children
- <ID – dashboard>
- <ID – operating note>

## Notes
- Areas recur. They do not need fake closure.

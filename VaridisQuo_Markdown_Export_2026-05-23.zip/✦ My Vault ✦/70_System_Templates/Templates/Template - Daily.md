---
class: B
---

# Daily — {{date}}

## Top 3
- 
- 
- 

## Schedule / commitments
- 

## Tasks touched today
- (link tasks here)

## Notes
- 

## End-of-day “close loops”
- Move anything unfinished into TaskNotes tasks.
- Link anything meaningful to a Project / Area / Person.


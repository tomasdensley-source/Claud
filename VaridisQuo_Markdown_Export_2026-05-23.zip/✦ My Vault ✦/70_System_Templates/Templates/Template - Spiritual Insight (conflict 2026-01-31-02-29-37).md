﻿---
class: B
---

> [!nav]
> Parent: [[10 Notes/Home|Home]]
> Siblings: [[10 Notes/Template - Reverse Implication Walkthrough|Template - Reverse Implication Walkthrough]] · [[10 Notes/Template - Spiritual Insight|Template - Spiritual Insight]]
> Children: none

Template â€” Spiritual Insight
Protocol Zeta+
Page 14
<!-- Template â€” Spiritual Insight -->
---
type: spiritual_insight
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Insight â€”
## Context
(When/where/how it arose)
## Insight
(Describe the realization in detail)
## Meaning
(What it means to you right now)
## Parallels or Validation
-  â€” parallel from research/philosophy
-  â€” parallel from lived experience
## Integration
(How you will apply/test it)

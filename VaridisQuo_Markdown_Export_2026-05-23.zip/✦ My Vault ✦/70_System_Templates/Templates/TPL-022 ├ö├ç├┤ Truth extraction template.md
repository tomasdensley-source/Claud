---
class: B
---

> [!template] Truth extraction template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use when converting extraction material into compact truth statements.

## Front
> [!truth] Truth extraction

Created: YYYY-MM-DD
Kind: Truth extraction note
State: Draft

## Truth statements
- Statement
- Evidence support
- Interpretive caution
- Promotion decision

## Children
- <ID – promoted permanent note>
- <ID – example attachment note>

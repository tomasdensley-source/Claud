---
class: B
---
Template â€” Reverse Implication Walkthrough
<!-- Template â€” Reverse Implication Walkthrough -->
---
type: method
method: reverse_implication
created: 2026-03-28
---
# Reverse Implication â€” Walkthrough
## Theorem / Observation (T)
(Quote, event, pattern, or problem statement)
## What would have to be true?
(List candidate axioms)
## Minimal Axiom Candidate (A*)
(One sentence; remove extra adjectives)
## Whole Herb Check
(What context would this axiom wrongly delete?)
## Extract Check
(What detail is noise? What is structural necessity?)
## Links created (with reasons)
-  â€”
-  â€”
-  â€”
## Next Test
(One small action or question to validate/refine A*)

Protocol Zeta+
Page 15

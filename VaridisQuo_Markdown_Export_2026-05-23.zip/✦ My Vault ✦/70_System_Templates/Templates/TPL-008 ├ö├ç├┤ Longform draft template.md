---
class: B
---

> [!template] Longform draft template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for essays, manifestos, and coherent long-form work.

## Front
> [!truth] Longform draft

Created: YYYY-MM-DD
Kind: Longform draft
State: Draft

## Sections
- Opening pressure
- Claim chain
- Examples
- Counterpressure
- Resolution or next question

## Children
- <ID – supporting truth index>
- <ID – example note>

﻿---
class: B
---

> [!nav]
> Parent: [[10 Notes/Home|Home]]
> Siblings: [[10 Notes/Template - Spiritual Insight|Template - Spiritual Insight]] · [[10 Notes/Template - Weekly Review|Template - Weekly Review]]
> Children: none

Template â€” Weekly Review
<!-- Template â€” Weekly Review -->
---
type: weekly_review
week: <% tp.date.now("YYYY-[W]WW") %>
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Weekly Review â€” <% tp.date.now("YYYY-[W]WW") %>
## Highlights (top 3)
## Patterns I notice
## Axioms strengthened this week
-  â€” how it got stronger
## Open questions
- #unanswered
## Gardening (merge / prune / link)
- [ ] Merge duplicates
- [ ] Add 10 links
- [ ] Promote 1 Fleeting note to Permanent
## Next week focus

﻿---
class: B
---
# Daily â€” {{date}}
## Top 3
- 
- 
- 
## Schedule / commitments
- 
## Tasks touched today
- (link tasks here)
## Notes
- 
## End-of-day â€œclose loopsâ€
- Move anything unfinished into TaskNotes tasks.
- Link anything meaningful to a Project / Area / Person.

---
class: B
---


[[Start - Literature]]


Template — Literature Note

Protocol Zeta+
Page 13
<!-- Template — Literature Note -->
---
type: literature
source_title:
author:
published:
link:
created: <% tp.date.now("YYYY-MM-DD") %>
---
# Lit — {{source_title}}
## Summary
## Notable Excerpts (with page/timestamp)
## Personal Reflections
## Connections
-  — why this connects
-  — why this connects

---
class: B
---

> [!template] Example note template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for concrete cases that sharpen a broader note.

## Front
> [!example] Example note

Created: YYYY-MM-DD
Kind: Example note
State: Draft
Tags: <shared-commonality>

## Body
- Describe the case clearly.
- Keep the example narrow enough to imply a broader parent via backlink.

## Notes
- Examples do not need parent sections.

---
class: B
---

> [!template] Decision ledger template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use when a project or system choice needs a durable record.

## Front
> [!project] Decision ledger

Created: YYYY-MM-DD
Kind: Decision ledger note
State: Active

## Decisions
- YYYY-MM-DD: Decision and rationale

## Children
- <ID – downstream guide or project child>

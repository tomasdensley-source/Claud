---
class: B
---

> [!template] Campaign operations template

Created: YYYY-MM-DD
Kind: Template
State: Template

Use for outreach, proposals, routes, and measurable business activity.

## Front
> [!project] Campaign / operations

Created: YYYY-MM-DD
Kind: Campaign / operations note
State: Active

## Fields
- Goal
- Offer angle
- Proof angle
- Next follow-up
- Measured outputs

## Children
- <ID – proposal draft>
- <ID – route note>

---
class: B
---

> [!contrast] Paradox reveals pressure

Created: 2026-03-23
Kind: Contrast / tension
State: Seeded
Tags:  

When two claims each remain partially true under stress, the paradox can show where a deeper structure is trying to emerge.

![[_Assets/Diagrams/Vault Decor/vault-banner-cold-fire.svg]]

_Stay with the pressure long enough to name what each side is protecting before trying to resolve it._

## Children
- EXA-E – Contrast clarifies value

## Notes
- Paradox is a place to map pressure, not a license to stay vague.

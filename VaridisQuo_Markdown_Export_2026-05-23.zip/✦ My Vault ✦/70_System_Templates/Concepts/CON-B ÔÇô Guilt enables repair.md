---
class: B
---

> [!contrast] Guilt enables repair

Created: 2026-03-23
Kind: Contrast / tension
State: Seeded
Tags:  

Guilt can be functional when it keeps the damaged action specific enough for repair, apology, restitution, or adjustment.

## Children
- EXA-A – Repair after rupture

## Notes
- Healthy guilt is about conduct and consequence, not self-annihilation.

---
class: B
---

> [!contrast] Structure carries meaning

Created: 2026-03-23
Kind: Contrast / tension
State: Seeded
Tags:  

The way notes point to children, receive backlinks, and share sibling tags already says something about how meaning is organized.

## Children
- EXA-D – Child implies parent
- EXA-E – Contrast clarifies value

## Notes
- Organization is part of the argument.
- File placement, tag logic, and links are not neutral.

---
class: B
---
> [!contrast] Paradox reveals pressure

Created: 2026-03-23
Kind: Contrast / tension
State: Seeded
Tags:  

## Children
- EXA-E – Contrast clarifies value

## Notes
- Paradox is a place to map pressure, not a license to stay vague.

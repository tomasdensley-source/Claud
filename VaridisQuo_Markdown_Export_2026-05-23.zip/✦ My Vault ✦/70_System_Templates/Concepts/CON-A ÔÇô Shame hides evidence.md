---
class: B
---

> [!contrast] Shame hides evidence

Created: 2026-03-23
Kind: Contrast / tension
State: Seeded
Tags:  

Shame often turns review into self-erasure. Once that happens, evidence collection gets replaced by avoidance.

## Children
- EXA-A – Repair after rupture

## Notes
- This is why the task system must route missed work into re-triage rather than condemnation.

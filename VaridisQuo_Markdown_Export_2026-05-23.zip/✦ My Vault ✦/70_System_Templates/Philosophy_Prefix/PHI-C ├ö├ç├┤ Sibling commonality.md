---
class: B
---

> [!concept] Sibling commonality

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

Sibling tags matter when they name what a lateral family actually shares, not merely what topic bucket it falls into.

## Children
- CON-D – Structure carries meaning
- EXA-E – Contrast clarifies value

## Examples
- EXA-E – Contrast clarifies value

## Notes
- A good sibling tag answers: what do these notes have in common?
- Topic is often too blunt; commonality is usually sharper.

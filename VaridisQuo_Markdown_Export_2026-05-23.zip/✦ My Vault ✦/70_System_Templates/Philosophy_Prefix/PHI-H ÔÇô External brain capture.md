---
class: B
---

> [!concept] External brain capture

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

An external brain is useful when capture is faster than forgetting and later triage is cleaner than live improvisation.

## Children
- EXA-F – Voice capture to triage
- INB-C – Dictation slip example

![[_Assets/Diagrams/Vault Decor/vault-divider-continuity-thread.svg]]

_Examples matter here because continuity is easier to trust when the capture loop stays concrete._

## Examples
- EXA-F – Voice capture to triage

## Notes
- Capture reduces interruption loss.
- The system must remain low-syntax so the capture cost stays low.

---
class: B
---

> [!concept] Abstraction and deconstruction

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

Deconstruction splits a claim into parts so it can be inspected.
Abstraction lifts the recurrent pattern back out so it can travel.

## Children
- EXA-B – Deconstructing a claim
- EXA-C – Abstracting a pattern

## Examples
- EXA-B – Deconstructing a claim
- EXA-C – Abstracting a pattern

## Notes
- The user's note system benefits from both motions.
- Deconstruction gives evidence. Abstraction gives portability.

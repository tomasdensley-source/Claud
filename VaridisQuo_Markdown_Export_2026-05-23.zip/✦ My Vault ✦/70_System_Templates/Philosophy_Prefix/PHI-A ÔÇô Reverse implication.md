---
class: B
---

> [!concept] Reverse implication

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

A useful note link should usually point from the broader claim to the narrower child that gives it force, evidence, or a tighter instance.
This keeps parent notes broad, child notes sharp, and backlinks meaningful.

## Children
- PHI-B – Backlinks as parents
- EXA-D – Child implies parent
- SOU-C – Example truth index

## Examples
- EXA-D – Child implies parent

## Sources
- SOU-C – Example truth index

## Notes
- Reverse implication is structural, not mystical.
- It helps the graph show consequence and containment.

---
class: B
---

> [!concept] Balance and repair

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

Balance is not passivity. It is a repair logic that keeps systems from drifting into collapse or denial.

## Children
- CON-B – Guilt enables repair
- EXA-A – Repair after rupture

## Examples
- EXA-A – Repair after rupture

## Notes
- Repair requires seeing the break clearly.
- Systems built on shame interrupt repair.

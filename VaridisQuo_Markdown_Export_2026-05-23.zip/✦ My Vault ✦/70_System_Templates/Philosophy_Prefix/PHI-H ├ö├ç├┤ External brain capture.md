---
class: B
---
> [!concept] External brain capture

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

## Children
- EXA-F – Voice capture to triage
- INB-C – Dictation slip example

## Examples
- EXA-F – Voice capture to triage

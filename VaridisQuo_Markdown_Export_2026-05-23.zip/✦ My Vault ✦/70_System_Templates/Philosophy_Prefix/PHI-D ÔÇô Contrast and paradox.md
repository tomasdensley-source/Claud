---
class: B
---

> [!concept] Contrast and paradox

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

Contrast and paradox are often signs that a structure is carrying more truth than a flat summary can hold.
They should trigger closer inspection, not premature simplification.

## Children
- CON-C – Paradox reveals pressure
- EXA-E – Contrast clarifies value

![[_Assets/Diagrams/Vault Decor/vault-divider-contrast-wave.svg]]

## Examples
- EXA-E – Contrast clarifies value

## Sources
- SOU-B – Example extraction note

## Notes
- Not every contradiction is deep, but every durable paradox deserves structural attention.

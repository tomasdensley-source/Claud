---
class: B
---

> [!concept] Guilt and shame

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

Guilt can support ethical repair because it keeps the action visible.
Shame tends to collapse the self into hiding, avoidance, and evidence refusal.

## Children
- CON-A – Shame hides evidence
- CON-B – Guilt enables repair
- EXA-A – Repair after rupture

## Examples
- EXA-A – Repair after rupture

## Sources
- SOU-B – Example extraction note

## Notes
- The vault task system should never be built on shame.
- Review language must stay on the repair side of the line.

---
class: B
---

> [!concept] Backlinks as parent signal

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

If a broader note points to this note as a child, that broader note already appears as a backlink. A separate parent section adds noise.

## Children
- EXA-D – Child implies parent

## Examples
- EXA-D – Child implies parent

## Notes
- Backlinks carry upward structure without crowding the note body.
- This keeps each note pointed toward what it can still unfold.

---
class: B
---
> [!concept] Contrast and paradox

Created: 2026-03-23
Kind: Atomic concept
State: Seeded
Tags:  

## Children
- CON-C – Paradox reveals pressure
- EXA-E – Contrast clarifies value

## Examples
- EXA-E – Contrast clarifies value

## Sources
- SOU-B – Example extraction note

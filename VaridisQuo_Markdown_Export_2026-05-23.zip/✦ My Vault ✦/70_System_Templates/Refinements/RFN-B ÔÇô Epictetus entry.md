---
class: B
---

> [!reference] Reference entry

Created: 2026-03-23
Kind: Reference entry note
State: Seeded

Why it matters: disciplined attention, response versus event, and a compact ethics of agency.

## Children
- PDR-B – Discourses public-domain note

## Notes
- Translation choices strongly affect tone.

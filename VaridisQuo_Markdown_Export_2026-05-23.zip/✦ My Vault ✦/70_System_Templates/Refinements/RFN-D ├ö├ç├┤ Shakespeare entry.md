---
class: B
---

> [!reference] Reference entry

Created: 2026-03-23
Kind: Reference entry note
State: Seeded

Why it matters: contrast, motive, conflict, voice, and dramatic form as knowledge engines.

## Children
- PDR-D – Hamlet public-domain note

## Notes
- Public-domain status is strong for the work itself; edition framing still matters.

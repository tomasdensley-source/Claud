---
class: B
---

> [!reference] Reference entry

Created: 2026-03-23
Kind: Reference entry note
State: Seeded

Why it matters: lived psychology, attention, habit, pragmatism, and the relation between experience and method.

## Children
- PDR-E – Pragmatism public-domain note

## Notes
- Edition caution still applies, especially with annotated modern texts.

---
class: B
---

> [!reference] Reference entry

Created: 2026-03-23
Kind: Reference entry note
State: Seeded

Why it matters: self-audit without theatricality, disciplined reflection, and repair-oriented introspection.

## Children
- PDR-C – Meditations public-domain note

## Notes
- Useful for contrast with shame-based self-attack.

---
class: B
---

> [!system] Container and AI context map

Created: 2026-03-25
Kind: System note
State: Active

The actual vault should live inside a clearly labeled container root.
That container also holds the external AI context docs, legacy archive, backups, and plugin-source workspace so the desktop does not sprawl.

## Children
- [[SYS-G – Plugin strategy]]
- [[SYS-K – Mobile use guide]]
- [[SYS-P – Live vault and legacy archive]]

## Notes
- The actual Obsidian vault should be the folder explicitly labeled `OPEN THIS IN OBSIDIAN`.
- `AI_READ_FIRST` belongs outside the vault so agents can read operating context without polluting graph or search.
- Plugin sources belong outside the vault but inside the same container.
- Legacy content and backups belong in the same container, not mixed into the live vault root.

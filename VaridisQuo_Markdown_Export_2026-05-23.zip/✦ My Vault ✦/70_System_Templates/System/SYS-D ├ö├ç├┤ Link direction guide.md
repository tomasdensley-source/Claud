---
class: B
---

> [!system] Link direction guide

Created: 2026-03-23
Kind: System note
State: Active

All explicit body links should point toward narrower children.
Do not create a normal `Parents` section. Let backlinks show the broader note.

## Children
- PHI-A – Reverse implication
- PHI-B – Backlinks as parents
- EXA-D – Child implies parent
- SOU-C – Example truth index

## Illegal patterns to avoid
- `## Parents` sections
- Forward links that point upward to broader hubs
- Mixing sibling and child links without meaning

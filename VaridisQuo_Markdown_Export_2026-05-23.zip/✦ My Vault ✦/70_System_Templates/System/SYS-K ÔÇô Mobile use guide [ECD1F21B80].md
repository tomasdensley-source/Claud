---
class: B
---

> [!system] Mobile use guide

Created: 2026-03-23
Kind: System note
State: Active

Mobile use should bias toward capture, triage, reading, and short review loops.
Large syntax blocks and dense tables are avoided for that reason.

## Children
- INB-A – Capture dock
- DLY-A – Daily system home
- [[ACT-A – Today dashboard]]
- SRC-A – PDF intake protocol
- [[SYS-O – Advanced Graph View guide]]

## Notes
- Use the Today tab first and Home second.
- Keep note titles short.
- Use one screenful sections.
- Prefer bullet stacks over complex tables.
- The mobile snippet should stay enabled.
- Open Advanced Graph View from the left ribbon when you need graph navigation.
- Start with the `Mobile Focus` preset on Samsung Android.
- Adjust center force, repel force, link strength, and link distance only after you decide whether the graph feels cramped or too scattered.
- Keep heavyweight PDFs cold once companion notes and extraction state are stable.

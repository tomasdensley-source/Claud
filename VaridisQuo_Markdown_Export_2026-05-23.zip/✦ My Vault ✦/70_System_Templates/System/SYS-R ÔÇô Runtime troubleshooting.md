---
class: B
---

> [!system] Runtime troubleshooting

Created: 2026-03-25
Kind: System note
State: Active

Use this note when the mobile app or a shipped plugin behaves incorrectly after a vault update.

## Children
- [[SYS-K – Mobile use guide]]
- [[SYS-O – Advanced Graph View guide]]
- [[SYS-P – Live vault and legacy archive]]
- [[SYS-S – Runtime self-check]]
- [[SYS-T – Recovery quick actions]]

## Fast checks
- Confirm you opened `C:\Users\nicko\Desktop\◉\FOR USER\⟁`, not an older duplicate.
- Force-close Obsidian fully after plugin changes, then reopen the live vault.
- Open the left drawer once and confirm the file tree scrolls.
- Open Advanced Graph View and confirm dynamic mode either shows nodes or an explicit warning message.
- Treat Advanced Graph View as the intended graph surface. Built-in graph is only a manual fallback.
- If you want the shortest path, run `Reset mobile runtime state and open troubleshooting` from the command palette.

## If Advanced Graph looks blank
- Press `Fit view`.
- Press `Show all groups`.
- Clear graph filters.
- Re-enable any hidden top-level folders from the file tree eye toggles.
- Fully close and reopen Obsidian once so the mobile webview picks up the current plugin bundle.
- Switch to `classic` temporarily if the dynamic renderer warns or fails.
- If you manually open Obsidian's built-in graph, do not expect it to inherit Advanced Graph hidden-folder state.

## If the file tree feels wrong
- Exit bulk-select mode with `Cancel` or by tapping outside the explorer.
- Check that long titles wrap fully instead of clipping.
- Confirm the left drawer scrolls before assuming a plugin crashed.
- Use `Reset mobile runtime state` if gestures or hidden-group state feel corrupted.
- Remember that this reset only clears VMS/Advanced Graph runtime state, not built-in graph state.
- Use `Open recovery quick actions note` if you want the command list without hunting through docs.

## One-touch recovery
- `Reset shared mobile text scale`
- `Show all top-level graph groups`
- `Show only the active note's top-level graph group`
- `Reset mobile runtime state`
- `Reset mobile runtime state and open troubleshooting`
- `Open recovery quick actions note`
- `Open runtime troubleshooting note`

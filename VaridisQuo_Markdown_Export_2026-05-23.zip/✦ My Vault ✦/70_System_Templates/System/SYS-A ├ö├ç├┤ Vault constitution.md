---
class: B
---
> [!system] Vault constitution

Created: 2026-03-23
Kind: System note
State: Active

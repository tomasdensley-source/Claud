---
class: B
---

> [!system] Source lifecycle

Created: 2026-03-23
Kind: System note
State: Active

A source should travel through intake, companioning, extraction, truth indexing, promotion, and eventually cold storage if the file itself is no longer active.

## Children
- SRC-A – PDF intake protocol
- SRC-B – Extraction workflow
- SRC-C – Truth statement pipeline
- SRC-D – Promotion to permanent notes
- COLD-A – Cold storage protocol

## Notes
- Move files later than notes.
- Source context should stay visible in the graph even when PDFs move.
- Useful states: `new`, `extracting`, `indexed`, `promoted`, `cold`.

---
class: B
---
> [!system] Runtime self-check

Created: 2026-03-26
Kind: System note
State: Active

Use this note after plugin edits or after moving the vault between devices.

## Check order
1. Confirm the opened vault path is `C:\Users\nicko\Desktop\◉\01 - LIVE VAULT - OPEN THIS`.
2. Confirm the left drawer opens and scrolls.
3. Confirm long file names wrap instead of clipping.
4. Confirm Advanced Graph opens.
5. Confirm `classic` mode shows a graph immediately.
6. Confirm `dynamic` mode shows either live nodes or a clear status message.
7. Confirm the eye toggle hides or shows a top-level folder group.
8. Confirm holding the eye toggle solos that group.
9. Confirm triple tap changes read/edit mode.
10. Confirm two-finger pinch changes text size only inside markdown notes.

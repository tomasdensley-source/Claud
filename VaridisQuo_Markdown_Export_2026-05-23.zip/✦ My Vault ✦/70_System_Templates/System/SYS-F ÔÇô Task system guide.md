---
class: B
---

> [!system] Task system guide

Created: 2026-03-23
Kind: System note
State: Active

The task system distinguishes accountability from shame.
Missing a day creates a re-triage need, not a moral failure state.

## Children
- DLY-A – Daily system home
- [[ACT-A – Today dashboard]]
- [[ACT-C – Waiting dashboard]]
- [[ACT-F – Recovery and re-triage]]
- 2026-W13 – Weekly review
- [[ACT-D – Deep work dashboard]]

## States
- Today
- Next
- Waiting
- Blocked
- Scheduled
- Someday
- Done
- Archive

## Daily blocks
- `Do now` = the smallest set that deserves current attention.
- `Follow up` = anything waiting on another person, reply, or check-in.
- `Think later` = valid but not current thinking work.
- `Carry forward` = work worth preserving after review.

## Useful fields
- `Waiting since` = when the item first became follow-up work.
- `Next ping` = when it deserves the next check.
- `Blocked by` = the actual dependency, not a vague mood label.
- `Deep work candidate` = work that deserves protected focus.
- `Needs review` = stale work that requires re-triage before action.

## Notes
- Overdue language is replaced by review language.
- Weekly review reassigns state rather than escalating shame.
- Prefer task wording that begins with a visible action.
- Never base a planning decision on shame.

---
class: B
---

> [!system] Graph legend

Created: 2026-03-23
Kind: System note
State: Active

Use these groups to keep graph triage-friendly and calm.
The same palette is used in the file tree and Advanced Graph View.

## Groups
- **Inbox / triage**: `path:"00_Inbox"` in `#ffae73`
- **Daily**: `path:"01_Daily"` in `#f5d76a`
- **Action**: `path:"02_Action"` in `#f0c36a`
- **Permanent notes**: `path:"03_Notes"` in `#978bff`
- **Maps / hubs**: `path:"04_Maps"` in `#45ddd8`
- **Sources / PDFs**: `path:"05_Sources"` in `#67bcff`
- **References**: `path:"06_Reference"` in `#7ad88f`
- **Persona / protocol**: `path:"07_Persona"` in `#eb7fbc`
- **System docs**: `path:"08_System"` in `#bccbe1`
- **Archive**: `path:"90_Archive"` in `#818da1`
- **Templates**: `path:"99_Templates"` in `#d7c09b`
- **Assets**: `path:"_Assets"` in `#93a7d9`
- **Attachments**: `isAttachment:true` in `#66e8ff`
- **Unresolved**: `isUnresolved:true` in `#ff7a6c`

## Children
- [[SYS-M – Graph triage guide]]
- MAP-B – Graph routes

## First-pass defaults
- `Default` now opens with node labels on, edge labels off, attachments off, unresolved off, and image mode off.
- `Mobile Focus` is the best first preset on Samsung Android when you want lower noise and faster scanability.
- Start from a map note or field route before widening into the full vault.

## Notes
- The palette is mirrored across Advanced Graph, Thomas tokens, and the file tree accents.
- Built-in graph is a manual fallback and is not kept in sync with Advanced Graph hidden-folder state.
- Advanced Graph View reuses the same folder color families and adds rule-based node and edge styling.

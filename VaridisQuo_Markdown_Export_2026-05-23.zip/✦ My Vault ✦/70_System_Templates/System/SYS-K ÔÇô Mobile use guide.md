---
class: B
---
> [!system] Mobile use guide

Created: 2026-03-23
Kind: System note
State: Active

## Children
- INB-A – Capture dock
- DLY-A – Daily system home
- [[ACT-A – Today dashboard]]
- SRC-A – PDF intake protocol
- [[SYS-R – Runtime troubleshooting]]
- [[SYS-O – Advanced Graph View guide]]
- [[SYS-T – Recovery quick actions]]

## Notes
- Use the Today tab first and Home second.
- Keep note titles short.
- Use one screenful sections.
- Prefer bullet stacks over complex tables.
- The mobile snippet should stay enabled.
- Triple tap toggles reading and editing mode on Samsung Android. Double tap should be ignored.
- Pinch in and out on a Markdown note with two fingers to resize mobile text. Reading and editing now share one text scale.
- Use the eye toggle beside a top-level folder in the file tree when you want that whole branch hidden from Advanced Graph View.
- Hold the eye toggle when you want to solo that branch in Advanced Graph View.
- Folder, subfolder, and note icons in the file tree are meant for faster thumb-scanning, not decoration.
- Open Advanced Graph View from the left ribbon or the mobile graph tab when you need graph navigation.
- Start with the `Mobile Focus` preset on Samsung Android.
- Adjust center force, repel force, link strength, and link distance only after you decide whether the graph feels cramped or too scattered.
- Keep heavyweight PDFs cold once companion notes and extraction state are stable.
- Use `Reset shared mobile text scale` if text sizing drifts too far from normal.
- Use `Reset mobile runtime state and open troubleshooting` when gestures, folder visibility, or the file tree feel corrupted.
- Keep [[SYS-T – Recovery quick actions]] pinned if you expect to test plugins on mobile repeatedly.

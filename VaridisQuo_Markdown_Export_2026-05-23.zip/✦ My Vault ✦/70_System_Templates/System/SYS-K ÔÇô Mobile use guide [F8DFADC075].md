---
class: B
---
> [!system] Mobile use guide

Created: 2026-03-23
Kind: System note
State: Active

## Notes
- Use the Today tab first and Home second.
- Keep note titles short.
- Use one screenful sections.
- Prefer bullet stacks over complex tables.
- The mobile snippet should stay enabled.
- Triple tap toggles reading and editing mode on Samsung Android. Double tap should be ignored.
- Use the eye toggle beside a top-level folder in the file tree when you want that whole branch hidden from Advanced Graph View.
- Folder, subfolder, and note icons in the file tree are meant for faster thumb-scanning, not decoration.
- Open Advanced Graph View from the left ribbon when you need graph navigation.
- Start with the `Mobile Focus` preset on Samsung Android.
- Adjust center force, repel force, link strength, and link distance only after you decide whether the graph feels cramped or too scattered.
- Keep heavyweight PDFs cold once companion notes and extraction state are stable.

---
class: B
---

> [!system] Advanced Graph View guide

Created: 2026-03-24
Kind: System note
State: Active

Advanced Graph View is the shipped custom graph pane. It keeps a stock-like graph feel, but adds presets, richer filtering, neighborhood depth, link-type styling, and native-style force controls.

## Children
- [[SYS-C – Graph legend]]
- [[SYS-G – Plugin strategy]]
- [[SYS-M – Graph triage guide]]
- [[ACT-A – Today dashboard]]
- MAP-B – Graph routes

## Use it when
- You want more control than the built-in graph gives you.
- You need filter-by-path or relationship-type triage.
- You want to tune center force, repel force, link strength, and link distance directly.
- You are on mobile and want a preset that opens cleanly without heavy graph noise.

## Start pattern
1. Open Advanced Graph View.
2. Start with `Mobile Focus` on Android or `Default` on larger screens.
3. Search or filter by path, tag, or relationship type.
4. Tune center force, repel force, link strength, and link distance only if the graph feels too dense or too scattered.
5. Expand neighborhood depth only as far as needed.
6. Open the selected node and continue downward through child links.

## Notes
- `Mobile Focus` is the best first preset on Samsung Android.
- Dynamic mode is the default and should visibly reheat when you drag nodes, change force sliders, or press `Restart physics`.
- Use the eye toggle beside a top-level folder in the file tree to hide that branch from Advanced Graph View without moving files.
- The force controls affect the dynamic renderer and the `cose` layout path.
- The built-in graph remains useful for a fast whole-vault scan.
- Advanced Graph View is the better choice when triage needs precision or force tuning.

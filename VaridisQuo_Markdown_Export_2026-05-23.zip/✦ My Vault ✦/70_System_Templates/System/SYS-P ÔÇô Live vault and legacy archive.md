---
class: B
---
> [!system] Live vault and support files

Created: 2026-03-25
Kind: System note
State: Active

`FOR USER\⟁` is the only live Obsidian vault in this container.
Legacy folders, backup folders, AI context, plugin sources, and `Varidis Quo` live in `FOR AI` so they do not act like alternate vaults.

## Rules
- Do not create a second `.obsidian` folder anywhere beside `FOR USER\⟁`.
- Treat de-vaulted legacy and backup folders as file history only, not as daily-driver vaults.
- Pull keepers into the live vault only after assigning a clear meaning-home.
- Keep heavy admin clutter, duplicate imports, and stale trees out of the live root so mobile use stays fast.

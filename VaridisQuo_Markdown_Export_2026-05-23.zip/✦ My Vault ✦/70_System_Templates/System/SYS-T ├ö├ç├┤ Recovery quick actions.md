---
class: B
---
> [!system] Recovery quick actions

Created: 2026-03-26
Kind: System note
State: Active

## Command palette actions
- `Reset shared mobile text scale`
  Restores the single shared Markdown text scale to the mobile baseline.
- `Show all top-level graph groups`
  Clears hidden-folder graph filters for both Advanced Graph and the built-in graph bridge.
- `Show only the active note's top-level graph group`
  Solos the branch of the note you currently have open.
- `Reset mobile runtime state`
  Clears heading folds, recent-checkbox styling memory, graph hidden-group state, and the shared text scale.
- `Reset mobile runtime state and open troubleshooting`
  Runs the full runtime reset, then opens [[SYS-R – Runtime troubleshooting]].
- `Open runtime troubleshooting note`
  Opens [[SYS-R – Runtime troubleshooting]] directly.
- `Open recovery quick actions note`
  Opens this note directly.

## Notes
- These are recovery actions, not daily workflow commands.
- If a reset does not help, switch to [[SYS-R – Runtime troubleshooting]] and follow the longer sequence.

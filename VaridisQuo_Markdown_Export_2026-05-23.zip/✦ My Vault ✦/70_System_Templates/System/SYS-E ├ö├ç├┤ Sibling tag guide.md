---
class: B
---
> [!system] Sibling tag guide

Created: 2026-03-23
Kind: System note
State: Active

## Children
- PHI-C – Sibling commonality
- CON-D – Structure carries meaning
- EXA-E – Contrast clarifies value

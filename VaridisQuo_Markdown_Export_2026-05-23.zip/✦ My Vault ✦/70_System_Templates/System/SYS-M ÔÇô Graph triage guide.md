---
class: B
---

> [!system] Graph triage guide

Created: 2026-03-23
Kind: System note
State: Active

Start with color clusters and the broad maps, not with random node clicking.
Orange means triage pressure. Indigo means durable thought. Blue means source work.

## Children
- MAP-B – Graph routes
- INB-B – Triage board
- [[ACT-A – Today dashboard]]

## Triage pattern
1. Find the cluster that matches the question.
2. Open the broadest visible parent note in that cluster.
3. Travel downward through children until the problem becomes specific.

## Open first
- Use the built-in graph for a quick whole-vault scan.
- Use [[SYS-O – Advanced Graph View guide]] when you need presets, link-type emphasis, or deeper filtering.

---
class: B
---

> [!system] Evidence / interpretation / speculation

Created: 2026-03-23
Kind: System note
State: Active

Research notes should distinguish what the source gives, what you infer, and what you are tentatively testing.

## Children
- SOU-B – Example extraction note
- SOU-C – Example truth index
- WRI-A – Writing pipeline

## Labels
- Evidence = text or observable claim.
- Interpretation = your best reading of what it means.
- Speculation = a useful but not-yet-grounded extension.

![[_Assets/Diagrams/Vault Decor/vault-divider-proof-pause.svg]]

## Notes
- Label during extraction, not after drafting.
- Index first, edit later.

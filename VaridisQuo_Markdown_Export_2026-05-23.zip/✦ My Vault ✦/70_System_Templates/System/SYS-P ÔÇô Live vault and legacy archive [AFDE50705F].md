---
class: B
---
> [!system] Live vault and legacy archive

Created: 2026-03-25
Kind: System note
State: Active

`Thomas Vault` is the only live Obsidian vault in this working copy.
The preserved legacy content vault should stay closed unless you are migrating material on purpose.

## Children
- [[SYS-L – Archive and cold storage]]
- [[SYS-O – Advanced Graph View guide]]
- [[SYS-Q – Container and AI context map]]

---
class: B
---
> [!system] Advanced Graph View guide

Created: 2026-03-24
Kind: System note
State: Active

## Notes
- `Mobile Focus` is the best first preset on Samsung Android.
- The force controls affect the `cose` layout only.
- The built-in graph remains useful for a fast whole-vault scan.
- Advanced Graph View is the better choice when triage needs precision or force tuning.

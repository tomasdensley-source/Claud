---
class: B
---
> [!system] Container and AI context map

Created: 2026-03-25
Kind: System note
State: Active

The actual vault lives in `FOR USER\⟁` so the desktop stays legible and the live runtime stays isolated.
The same container also holds `FOR AI`, which contains the external AI context docs, de-vaulted legacy files, de-vaulted backups, plugin-source workspace, and intake corpus.

## Notes
- The actual Obsidian vault is `C:\Users\nicko\Desktop\◉\FOR USER\⟁`.
- AI context belongs in `FOR AI` so agents can read operating context without polluting graph or search.
- Plugin sources belong in `FOR AI`, outside the vault.
- Legacy files and backups belong in `FOR AI`, not mixed into the live vault root.

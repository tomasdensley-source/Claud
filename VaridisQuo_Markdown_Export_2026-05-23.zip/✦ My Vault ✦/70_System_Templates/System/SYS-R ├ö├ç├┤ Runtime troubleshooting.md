---
class: B
---
> [!system] Runtime troubleshooting

Created: 2026-03-25
Kind: System note
State: Active

## Fast checks
- Confirm you opened `C:\Users\nicko\Desktop\◉\01 - LIVE VAULT - OPEN THIS`, not an older duplicate.
- Force-close Obsidian fully after plugin changes, then reopen the live vault.
- Open the left drawer once and confirm the file tree scrolls.
- Open Advanced Graph View and confirm dynamic mode either shows nodes or an explicit warning message.
- If you want the shortest path, run `Reset mobile runtime state and open troubleshooting` from the command palette.

## If Advanced Graph looks blank
- Press `Fit view`.
- Press `Show all groups`.
- Clear graph filters.
- Re-enable any hidden top-level folders from the file tree eye toggles.
- Fully close and reopen Obsidian once so the mobile webview picks up the current plugin bundle.
- Switch to `classic` temporarily if the dynamic renderer warns or fails.

## If the file tree feels wrong
- Exit bulk-select mode with `Cancel` or by tapping outside the explorer.
- Check that long titles wrap fully instead of clipping.
- Confirm the left drawer scrolls before assuming a plugin crashed.
- Use `Reset mobile runtime state` if gestures or hidden-group state feel corrupted.
- Use `Open recovery quick actions note` if you want the command list without hunting through docs.

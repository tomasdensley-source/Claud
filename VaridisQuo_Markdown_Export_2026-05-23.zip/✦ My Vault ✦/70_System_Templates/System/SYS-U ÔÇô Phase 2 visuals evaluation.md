---
class: B
---

> [!system] Phase 2 visuals evaluation

Created: 2026-03-26
Kind: System note
State: Active

This note records the current decision on optional visual installs that were reviewed after the mobile-stability pass.

## Active baseline
- Keep `moonstone` plus the current Thomas snippets as the live visual baseline.
- Do not swap the active theme while mobile graph, file-tree, and gesture behavior are still being tuned on Samsung Android.

## AnuPpuccin
- Official source: `https://github.com/AnubisNekhet/AnuPpuccin`
- Current manifest reviewed on 2026-03-26: version `1.5.0`, minimum Obsidian version `1.6.0`.
- Repository notice reviewed on 2026-03-26: the theme is currently on hiatus.
- It makes heavy use of Style Settings and exposes a broad visual surface area.

## Decision on AnuPpuccin
- Deferred for now.
- Reason:
  The theme would replace the vault-wide visual baseline at the same time that mobile runtime stability is still being verified.
- Secondary reason:
  The current vault already depends on a custom snippet stack, graph styling, and mobile-specific CSS that would all need a second compatibility pass after a theme swap.

## Graph Banner
- Official source: `https://github.com/ras0q/obsidian-graph-banner`
- Current manifest reviewed on 2026-03-26: version `2.3.3`, minimum Obsidian version `1.7.2`, `isDesktopOnly = false`.
- Current README reviewed on 2026-03-26: the plugin renders a local graph in the note header and supports appearance tuning through Style Settings.

## Decision on Graph Banner
- Deferred for now.
- Reason:
  The live vault already ships a custom advanced graph, a native-graph bridge, and folder-visibility controls. Adding another graph renderer in note headers would increase mobile rendering pressure before the main graph stack has been fully validated on-device.

## Activation gate
- Only revisit these installs after:
  - the left drawer scroll is stable,
  - dynamic graph remains usable on the phone for extended sessions,
  - no repeat crashes appear after at least one normal day of mobile use.

## Next review
- Revisit after the next Samsung validation pass.
- If the vault stays stable, test Graph Banner before any full theme swap.

---
class: B
---

> [!system] Live vault and legacy archive

Created: 2026-03-25
Kind: System note
State: Active

`Thomas Vault` is the only live Obsidian vault in this root.
The preserved legacy content vault was moved out of the live root and should stay closed unless you are migrating material on purpose.

## Children
- [[SYS-L – Archive and cold storage]]
- [[SYS-O – Advanced Graph View guide]]

## Rules
- Do not create a second `.obsidian` folder inside the live vault.
- Treat the legacy archive as source material, not as a daily driver.
- Pull keepers into the live vault only after assigning a clear meaning-home.
- Keep heavy admin clutter, duplicate imports, and stale trees out of the live root so mobile use stays fast.

---
class: B
---
> [!system] Day one guide

Created: 2026-03-23
Kind: System note
State: Active

## Quick checks
- If the graph colors look wrong, compare against [[SYS-C – Graph legend]].
- If the custom graph view is missing, check [[SYS-O – Advanced Graph View guide]].
- If the workspace looks unrelated, reload the vault and reopen Home.
- If you see a second vault inside the live root, stop and compare against [[SYS-P – Live vault and legacy archive]].

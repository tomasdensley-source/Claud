---
class: B
---
> [!system] Plugin strategy

Created: 2026-03-23
Kind: System note
State: Active

## Optional later
- Dataview
- Templater
- Tasks
- QuickAdd

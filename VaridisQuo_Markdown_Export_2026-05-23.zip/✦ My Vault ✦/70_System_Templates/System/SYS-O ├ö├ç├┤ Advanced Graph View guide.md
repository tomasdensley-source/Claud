---
class: B
---
> [!system] Advanced Graph View guide

Created: 2026-03-24
Kind: System note
State: Active

Advanced Graph View is the shipped custom graph pane. It keeps a stock-like graph feel, but adds presets, richer filtering, neighborhood depth, link-type styling, folder visibility controls, and native-style force controls.

## Notes
- `Mobile Focus` is the best first preset on Samsung Android.
- Dynamic mode is the default and should visibly reheat when you drag nodes, change force sliders, or press `Restart physics`.
- Dynamic mode on mobile should use the custom force renderer. If it cannot start cleanly, the pane should warn or fall back instead of silently blanking.
- Use the eye toggle beside a top-level folder in the file tree to hide that branch from Advanced Graph View without moving files.
- Hold that eye toggle to solo the branch.
- Use `Show all groups` in the graph controls or inspector when the view looks unexpectedly sparse.
- The force controls affect the dynamic renderer and the `cose` layout path.
- The built-in graph remains useful for a fast whole-vault scan.
- Advanced Graph View is the better choice when triage needs precision or force tuning.

---
class: B
---

> [!system] Graph legend

Created: 2026-03-23
Kind: System note
State: Active

Use these groups to keep graph view triage-friendly and calm.
The same palette is used in the file tree, the built-in graph groups, and Advanced Graph View.

## Groups
- **Inbox / triage**: `path:"00_Inbox"` in `#ff9b42`
- **Daily / action**: `path:"01_Daily" OR path:"02_Action"` in `#f2c14e`
- **Maps / hubs**: `path:"04_Maps"` in `#3ccfcf`
- **Permanent notes**: `path:"03_Notes"` in `#8a7dff`
- **Sources / PDFs**: `path:"05_Sources"` in `#53a8ff`
- **References**: `path:"06_Reference"` in `#69c17d`
- **Persona / protocol**: `path:"07_Persona"` in `#d96faf`
- **System docs**: `path:"08_System"` in `#a3b3c7`
- **Archive**: `path:"90_Archive"` in `#6a7282`
- **Templates**: `path:"99_Templates"` in `#cbb48f`

## Children
- [[SYS-M – Graph triage guide]]
- MAP-B – Graph routes

## Notes
- The palette is mirrored in the file tree CSS.
- The built-in graph ships with these groups as the active default.
- Advanced Graph View reuses the same folder color families and adds rule-based node and edge styling.

---
class: B
---

> [!system] Plugin strategy

Created: 2026-03-23
Kind: System note
State: Active

The vault works without community plugins.
If plugins are available, the shipped set stays intentionally conservative and mobile-safe: Advanced Graph View, Style Settings, Calendar, and PDF++.
Anything beyond that should be added only if it clearly reduces friction, especially on Android.

## Children
- [[SYS-I – CSS system guide]]
- [[SYS-F – Task system guide]]
- [[SYS-M – Graph triage guide]]
- [[SYS-O – Advanced Graph View guide]]

## Fallbacks
- Dashboards are plain Markdown first.
- Templates are readable without automation.
- Graph groups are documented even if presets need manual entry.

## Shipped by default
- Advanced Graph View = custom stock-like graph pane with richer filters, presets, and native-style center force, repel force, link strength, and link distance controls.
- Style Settings = snippet controls for the Thomas CSS system.
- Calendar = daily and weekly note visibility.
- PDF++ = cleaner PDF reading and quoting workflow.

## Optional later
- Dataview
- Templater
- Tasks
- QuickAdd

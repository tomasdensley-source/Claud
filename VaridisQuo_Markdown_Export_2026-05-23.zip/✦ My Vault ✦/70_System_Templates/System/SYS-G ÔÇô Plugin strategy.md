---
class: B
---
> [!system] Plugin strategy

Created: 2026-03-23
Kind: System note
State: Active

The vault works without community plugins.
If plugins are available, the shipped set stays intentionally conservative and mobile-safe: Advanced Graph View, Vault Mobile Signals, File Tree Bulk Actions, Style Settings, Calendar, and PDF++.
Anything beyond that should be added only if it clearly reduces friction, especially on Android.

![[_Assets/Diagrams/Vault Decor/vault-seal-graph-stewardship.svg|180]]

_Treat this page as the custody record for what enters the runtime, what stays optional, and why._

## Anchor guides
- [[SYS-I – CSS system guide]]
- [[SYS-F – Task system guide]]
- [[SYS-M – Graph triage guide]]
- [[SYS-O – Advanced Graph View guide]]

## Shipped by default
- Advanced Graph View = custom stock-like graph pane with richer filters, presets, and native-style center force, repel force, link strength, and link distance controls.
- Vault Mobile Signals = mobile-first explorer and note-surface layer for top-folder graph toggles, themed file-tree icons, triple-tap mode switching, and note-type styling hooks.
- File Tree Bulk Actions = long-press multi-select deletion for mobile cleanup.
- Style Settings = snippet controls for the Thomas CSS system.
- Calendar = daily and weekly note visibility.
- PDF++ = cleaner PDF reading and quoting workflow.

## Optional later
- Dataview
- Templater
- Tasks
- QuickAdd

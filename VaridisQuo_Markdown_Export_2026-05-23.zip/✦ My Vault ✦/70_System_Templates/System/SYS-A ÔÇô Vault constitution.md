---
class: B
---

> [!system] Vault constitution

Created: 2026-03-23
Kind: System note
State: Active

The vault is built on reverse-implication child links, backlinks as parent signals, sibling-commonality tags, and a low-shame execution loop.
If a future change weakens one of those, the change should be challenged before it spreads.

![[_Assets/Diagrams/Vault Decor/vault-seal-first-principles.svg]]

## Children
- [[SYS-B – ID grammar]]
- [[SYS-C – Graph legend]]
- [[SYS-D – Link direction guide]]
- [[SYS-E – Sibling tag guide]]
- [[SYS-F – Task system guide]]
- [[SYS-G – Plugin strategy]]
- [[SYS-H – Source lifecycle]]
- [[SYS-I – CSS system guide]]
- [[SYS-J – Day one guide]]
- [[SYS-K – Mobile use guide]]
- [[SYS-L – Archive and cold storage]]
- [[SYS-M – Graph triage guide]]
- [[SYS-N – Evidence interpretation speculation]]

## Notes
- The constitution protects coherence.
- It is the broadest parent note in the operational system.

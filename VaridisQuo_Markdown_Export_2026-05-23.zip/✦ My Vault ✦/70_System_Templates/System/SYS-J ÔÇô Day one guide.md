---
class: B
---

> [!system] Day one guide

Created: 2026-03-23
Kind: System note
State: Active

Day one should feel obvious: open the home map, then the today dashboard, then the inbox if something new arrives.
The vault is seeded so both built-in graph view and Advanced Graph View are meaningful immediately.

## Children
- HOME-000 – Start here
- MAP-A – Vault home
- [[ACT-A – Today dashboard]]
- INB-A – Capture dock
- TPL-000 – Template index
- [[SYS-C – Graph legend]]
- [[SYS-O – Advanced Graph View guide]]

## Day one order
1. Confirm the current theme stack is readable on your phone.
2. Enable the Thomas snippet suite from [[SYS-I – CSS system guide]].
3. Confirm Community Plugins are enabled if you want the shipped graph, calendar, Style Settings, and PDF tools.
4. Open Advanced Graph View once and try the `Mobile Focus` preset.
5. Read the vault constitution once.
6. Use the Today dashboard and one daily note.
7. Capture one thought in inbox and promote it.

## Quick checks
- If the graph colors look wrong, compare against [[SYS-C – Graph legend]].
- If the custom graph view is missing, check [[SYS-O – Advanced Graph View guide]].
- If the workspace looks unrelated, reload the vault and reopen Home.
- If you see a second vault inside the project container, stop and compare against [[SYS-P – Live vault and legacy archive]].

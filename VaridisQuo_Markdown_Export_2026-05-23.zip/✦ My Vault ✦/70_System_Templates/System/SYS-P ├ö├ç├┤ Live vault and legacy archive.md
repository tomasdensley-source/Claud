---
class: B
---
> [!system] Live vault and legacy archive

Created: 2026-03-25
Kind: System note
State: Active

`01 - LIVE VAULT - OPEN THIS` is the only live Obsidian vault in this container.
`03 - Legacy Archive\01 - LEGACY VAULT - ARCHIVE ONLY` stays closed unless material is being migrated on purpose.

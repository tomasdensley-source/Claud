---
class: B
---
> [!system] Container and AI context map

Created: 2026-03-25
Kind: System note
State: Active

The actual vault lives inside a clearly labeled container root so the desktop stays legible.
That container also holds the external AI context docs, legacy archive, backups, plugin-source workspace, and intake corpus.

## Notes
- The actual Obsidian vault is `C:\Users\nicko\Desktop\◉\01 - LIVE VAULT - OPEN THIS`.
- `AI_READ_FIRST` belongs outside the vault so agents can read operating context without polluting graph or search.
- Plugin sources belong outside the vault but inside the same container.
- Legacy content and backups belong in the same container, not mixed into the live vault root.

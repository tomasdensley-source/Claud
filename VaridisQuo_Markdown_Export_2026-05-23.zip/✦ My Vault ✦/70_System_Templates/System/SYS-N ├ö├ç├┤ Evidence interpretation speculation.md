---
class: B
---
> [!system] Evidence / interpretation / speculation

Created: 2026-03-23
Kind: System note
State: Active

## Notes
- Label during extraction, not after drafting.
- Index first, edit later.

---
class: B
---

# SYS-V - Decorative Asset Library

This note tracks reusable decorative SVG assets for the live vault.

Use them when a note needs atmosphere, symbolic emphasis, or a stronger visual anchor without adding heavy image files.

## Core Set

- `vault-banner-constellation.svg`
  - best for map notes, system notes, dashboards, and mythic or high-level overview pages
- `vault-divider-aurora.svg`
  - best for section breaks in AI, systems, and philosophy notes
- `vault-divider-ledger.svg`
  - best for formal business notes, operating files, and structured reference pages
- `vault-seal-persona.svg`
  - best for persona notes, identity notes, and reflective or symbolic pages

## New Banners

- `vault-banner-threshold-dawn.svg`
  - use for entry notes, home maps, manifesto openings, or any page that should feel like a deliberate crossing into the vault
- `vault-banner-knowledge-river.svg`
  - use for research hubs, source maps, graph routes, and long-form notes where ideas are flowing, branching, or converging
- `vault-banner-memory-garden.svg`
  - use for daily reflections, worldview notes, recovery pages, or growth-oriented notes that should feel alive but calm

## New Dividers

- `vault-divider-proof-pause.svg`
  - use between evidence and interpretation sections, quote blocks, AI analysis sections, or any place where the note needs a contemplative stop
- `vault-divider-repair-arc.svg`
  - use in recovery dashboards, re-triage notes, repair-themed writing, or sections about correction and rebuilding
- `vault-divider-contrast-wave.svg`
  - use in philosophy notes, contrast/paradox notes, and places where tension between two ideas is part of the meaning
- `vault-divider-return-ball.svg`
  - use in interview notes, conversation analysis, AI dialogue pages, and notes about response, reciprocity, or attunement

## New Seals And Panels

- `vault-seal-first-principles.svg`
  - use in constitution notes, operating principles, axioms, and system pages where the vault should feel grounded and formal
- `vault-seal-care-gate.svg`
  - use in persona notes, ethics pages, care-oriented reflections, or notes about discernment, presence, and response
- `vault-panel-edification-window.svg`
  - use as a large cover image for manifesto pages, canvas backdrops, philosophy hubs, or any note that needs a full ceremonial framing device

## Additional Banners

- `vault-banner-cathedral-axioms.svg`
  - use for metaphysical writing, philosophy hubs, system overviews, and notes that should feel architectural, formal, and high-level
- `vault-banner-cold-fire.svg`
  - use for paradox notes, tension-heavy writing, mythic drafts, and pages that hold warm and cold ideas at the same time
- `vault-banner-lantern-index.svg`
  - use for source shelves, reference indexes, reading maps, and guide notes that are meant to orient or illuminate

## Additional Dividers

- `vault-divider-evidence-ladder.svg`
  - use for extraction notes, truth indexes, argument-building sections, and anywhere a note moves step by step from evidence toward conclusion
- `vault-divider-sibling-weave.svg`
  - use for sibling-tag notes, relation-heavy pages, taxonomy notes, and any place where lateral commonality matters
- `vault-divider-continuity-thread.svg`
  - use for inbox-to-note flows, interruption recovery, dictation capture, and notes about preserving thought across breaks
- `vault-divider-archive-ember.svg`
  - use for archive notes, cold-storage notes, retrospectives, and pages where something is dormant but still alive

## Additional Seals And Panels

- `vault-seal-graph-stewardship.svg`
  - use in graph guides, plugin strategy, maintenance notes, and any page about caring for vault structure over time
- `vault-seal-witness-ring.svg`
  - use in evidence notes, interpretation/speculation notes, and pages where seeing clearly or holding attention is central
- `vault-panel-codex-gate.svg`
  - use as a major framing image for long-form codex pages, writing hubs, or ceremonial overview notes that need a stronger symbolic presence

## Asset Set

- `![[_Assets/Diagrams/Vault Decor/vault-banner-constellation.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-aurora.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-ledger.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-seal-persona.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-banner-threshold-dawn.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-banner-knowledge-river.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-banner-memory-garden.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-proof-pause.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-repair-arc.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-contrast-wave.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-return-ball.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-seal-first-principles.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-seal-care-gate.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-panel-edification-window.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-banner-cathedral-axioms.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-banner-cold-fire.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-banner-lantern-index.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-evidence-ladder.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-sibling-weave.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-continuity-thread.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-divider-archive-ember.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-seal-graph-stewardship.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-seal-witness-ring.svg]]`
- `![[_Assets/Diagrams/Vault Decor/vault-panel-codex-gate.svg]]`

## Example Embeds

```md
![[_Assets/Diagrams/Vault Decor/vault-banner-threshold-dawn.svg]]
```

```md
![[_Assets/Diagrams/Vault Decor/vault-divider-proof-pause.svg]]
```

```md
![[_Assets/Diagrams/Vault Decor/vault-seal-first-principles.svg|180]]
```

```md
![[_Assets/Diagrams/Vault Decor/vault-panel-edification-window.svg]]
```

## Placement Rule

Prefer one major asset near the top of a note, or one divider between major sections.

For most notes, use one banner or panel, not both.

Too many decorative embeds in one note will make the vault feel theatrical instead of deliberate.

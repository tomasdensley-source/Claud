---
class: B
---
> [!system] Archive and cold storage

Created: 2026-03-23
Kind: System note
State: Active

## Rules
- Archive closed loops, not unresolved ideas.
- Move heavy files later than companion notes.
- Keep original filenames when relocating source files.
- Keep preserved legacy vaults outside the live vault root.

---
class: B
---

> [!system] Recovery quick actions

Created: 2026-03-26
Kind: System note
State: Active

Use this note when the vault works, but a mobile behavior needs a quick reset instead of a deep investigation.

## Children
- [[SYS-K – Mobile use guide]]
- [[SYS-R – Runtime troubleshooting]]
- [[SYS-S – Runtime self-check]]

## Command palette actions
- `Reset shared mobile text scale`
  Restores the single shared Markdown text scale to the mobile baseline.
- `Show all top-level graph groups`
  Clears hidden-folder graph filters for Advanced Graph View and the file-tree eye toggles.
- `Show only the active note's top-level graph group`
  Solos the branch of the note you currently have open.
- `Reset mobile runtime state`
  Clears heading folds, recent-checkbox styling memory, Advanced Graph hidden-group state, and the shared Markdown text scale.
- `Reset mobile runtime state and open troubleshooting`
  Runs the full runtime reset, then opens [[SYS-R – Runtime troubleshooting]].
- `Open runtime troubleshooting note`
  Opens [[SYS-R – Runtime troubleshooting]] directly.
- `Open recovery quick actions note`
  Opens this note directly.

## Fast sequences
- Text sizing feels wrong:
  Run `Reset shared mobile text scale`.
- Graph looks empty after hiding too many folders:
  Run `Show all top-level graph groups`.
- File tree, gestures, and graph toggles all feel slightly corrupted:
  Run `Reset mobile runtime state and open troubleshooting`.
- You just changed plugin files and mobile still feels stale:
  Force-close Obsidian fully, reopen the live vault, then run the reset command above once.

## Notes
- These are recovery actions, not daily workflow commands.
- Built-in graph is not part of these recovery actions and is not kept in sync with Advanced Graph hidden-folder state.
- If a reset does not help, switch to [[SYS-R – Runtime troubleshooting]] and follow the longer sequence.

---
class: B
---

> [!system] Advanced Graph View guide

Created: 2026-03-24
Kind: System note
State: Active

Advanced Graph View is the shipped custom graph pane and the intended graph front door for the live vault. It keeps a stock-like graph feel, but adds presets, richer filtering, neighborhood depth, link-type styling, folder visibility controls, and native-style force controls.

## Children
- [[SYS-C – Graph legend]]
- [[SYS-G – Plugin strategy]]
- [[SYS-M – Graph triage guide]]
- [[SYS-R – Runtime troubleshooting]]
- [[ACT-A – Today dashboard]]
- MAP-B – Graph routes

## Use it when
- You want the vault's primary graph experience.
- You need filter-by-path or relationship-type triage.
- You want to tune center force, repel force, link strength, and link distance directly.
- You are on mobile and want a preset that opens cleanly without heavy graph noise.

## Start pattern
1. Open Advanced Graph View.
2. Start with `Mobile Focus` on Android or `Default` on larger screens.
3. Search or filter by path, tag, or relationship type.
4. Tune center force, repel force, link strength, and link distance only if the graph feels too dense or too scattered.
5. Expand neighborhood depth only as far as needed.
6. Use `Show all groups` if the graph feels unexpectedly empty.
7. Open the selected node and continue downward through child links.

## Notes
- `Mobile Focus` is the best first preset on Samsung Android.
- `Default` now ships calmer too: node labels on, edge labels off, attachments off, unresolved off, and image mode off.
- Dynamic mode is the default and should visibly reheat when you drag nodes, change force sliders, or press `Restart physics`.
- Dynamic mode on mobile should use the custom force renderer. If it cannot start cleanly, the pane should warn or fall back instead of silently blanking.
- Use the eye toggle beside a top-level folder in the file tree to hide that branch from Advanced Graph View without moving files.
- Hold that eye toggle to solo the branch.
- Use `Show all groups` in the graph controls or inspector when the view looks unexpectedly sparse.
- The force controls affect the dynamic renderer and the `cose` layout path.
- Hidden-folder state belongs to Advanced Graph View and the file-tree eye toggles. Built-in graph is not kept in sync.
- Obsidian's built-in graph is retained only as a manual fallback, not as the normal workflow surface.

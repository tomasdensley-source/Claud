---
class: B
---

> [!system] ID grammar

Created: 2026-03-23
Kind: System note
State: Active

Filename pattern: `ID – short descriptor`.
Use uppercase sibling expansion first: `A` through `Z`, then lowercase `a` through `z`, then dotted overflow like `A.` or `a.` if needed.

## Children
- TPL-000 – Template index
- EXA-D – Child implies parent

## Rules
- Keep descriptors short and scannable.
- Use `-` for deconstruction notation when needed.
- Use `_` for abstraction layering when disambiguation helps.

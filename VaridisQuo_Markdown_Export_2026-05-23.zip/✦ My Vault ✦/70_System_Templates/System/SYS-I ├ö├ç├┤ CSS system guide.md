---
class: B
---

> [!system] CSS system guide

Created: 2026-03-23
Kind: System note
State: Active

The CSS suite colors the file tree, graph-adjacent panes, note surfaces, dashboards, PDFs, and mobile spacing.
It is light-mode friendly, remains readable under the current theme stack, and is built to stay legible on Android.

## Children
- [[SYS-C – Graph legend]]
- [[SYS-G – Plugin strategy]]
- [[SYS-K – Mobile use guide]]

## Snippet families
- `00-thomas-tokens`
- `10-thomas-workspace`
- `20-thomas-file-tree`
- `30-thomas-note-surfaces`
- `40-thomas-dashboards`
- `50-thomas-mobile`

## Style Settings controls
- Heading vibrance
- Native graph line darkness
- Native graph line thickness
- Panel blur
- Relations text size
- PDF embed max height

## Notes
- The Thomas suite is the canonical baseline for the vault.
- Extra personal snippets can stay enabled if they do not fight the Thomas suite.
- The mobile snippet should remain enabled for Samsung Android use.

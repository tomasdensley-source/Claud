---
class: B
---

> [!system] Archive and cold storage

Created: 2026-03-23
Kind: System note
State: Active

Archive should mute stale material without erasing it from the graph. Cold storage should reduce device friction without severing context.

## Children
- ARC-A – Archive guide
- COLD-A – Cold storage protocol
- [[SYS-P – Live vault and legacy archive]]

![[_Assets/Diagrams/Vault Decor/vault-divider-archive-ember.svg]]

_The aim is lower friction and lower noise, not disappearance._

## Rules
- Archive closed loops, not unresolved ideas.
- Move heavy files later than companion notes.
- Keep original filenames when relocating source files.
- Keep preserved legacy and backup material outside the live vault root.

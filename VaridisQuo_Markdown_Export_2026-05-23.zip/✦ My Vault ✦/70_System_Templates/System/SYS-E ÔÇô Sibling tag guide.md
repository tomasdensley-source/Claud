---
class: B
---

> [!system] Sibling tag guide

Created: 2026-03-23
Kind: System note
State: Active

Sibling tags answer the question: what do these notes have in common such that they belong in the same lateral family?
They are not generic topic buckets.

![[_Assets/Diagrams/Vault Decor/vault-divider-sibling-weave.svg]]

_Name the shared commonality first, then choose the namespace that best describes the relation._

## Anchor notes
- PHI-C – Sibling commonality
- CON-D – Structure carries meaning
- EXA-E – Contrast clarifies value

## Namespaces
- `#sib/and/<shared-commonality>`
- `#sib/or/<shared-commonality>`
- `#sib/example/<shared-commonality>`
- `#sib/contrast/<shared-commonality>`
- `#sib/this-that/<shared-commonality>`

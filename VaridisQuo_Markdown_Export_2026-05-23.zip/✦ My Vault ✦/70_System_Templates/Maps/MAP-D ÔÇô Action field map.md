---
class: B
---

> [!map] Action field

Created: 2026-03-23
Kind: Hub / MOC
State: Active

This field routes dashboards, projects, recurring operations, and business work.

## Children
- [[ACT-A – Today dashboard]]
- [[ACT-B – Projects dashboard]]
- [[ACT-C – Waiting dashboard]]
- [[ACT-D – Deep work dashboard]]
- [[ACT-E – Reading dashboard]]
- [[ACT-F – Recovery and re-triage]]
- [[ACT-G – Weekly execution map]]
- PRJ-A – Vault stewardship
- PRJ-B – Writing and research pipeline
- PRJ-C – Business offer lab
- ARA-A – Personal operations
- ARA-B – Business operations

## Campaign lane
- CMP-A – Outreach campaign note
- CMP-B – Proposal note example
- CMP-C – Territory route note

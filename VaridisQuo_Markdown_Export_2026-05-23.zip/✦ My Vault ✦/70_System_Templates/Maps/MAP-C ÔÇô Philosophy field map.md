---
class: B
---

> [!map] Philosophy field

Created: 2026-03-23
Kind: Hub / MOC
State: Active

This field concentrates the user's structural philosophy: implication, paradox, contrast, repair, and meaning-bearing form.

![[_Assets/Diagrams/Vault Decor/vault-banner-cathedral-axioms.svg]]

_Use this map when a philosophy thread needs to move from first principles into linked notes and then outward into writing._

## Core notes
- PHI-A – Reverse implication
- PHI-B – Backlinks as parents
- PHI-C – Sibling commonality
- PHI-D – Contrast and paradox
- PHI-E – Guilt and shame
- PHI-F – Abstraction and deconstruction
- PHI-G – Balance and repair
- PHI-H – External brain capture

## Draft surfaces
- WRI-A – Writing pipeline
- LNG-A – Manifesto draft scaffold

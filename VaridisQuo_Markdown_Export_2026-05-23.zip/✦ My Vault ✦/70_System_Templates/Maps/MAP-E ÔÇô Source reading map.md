---
class: B
---

> [!map] Source reading field

Created: 2026-03-23
Kind: Hub / MOC
State: Active

This field keeps PDF intake, extraction, truth indexing, and promotion into permanent notes coherent.

## Children
- SRC-A – PDF intake protocol
- SRC-B – Extraction workflow
- SRC-C – Truth statement pipeline
- SRC-D – Promotion to permanent notes
- PDF-A – PDF drop zone
- SOU-A – Example source companion
- SOU-B – Example extraction note
- SOU-C – Example truth index
- COLD-A – Cold storage protocol

## Notes
- Keep original filenames for imported PDFs.
- Companion notes carry the graph meaning.

---
class: B
---
> [!map] Philosophy field

Created: 2026-03-23
Kind: Hub / MOC
State: Active

## Children
- PHI-A – Reverse implication
- PHI-B – Backlinks as parents
- PHI-C – Sibling commonality
- PHI-D – Contrast and paradox
- PHI-E – Guilt and shame
- PHI-F – Abstraction and deconstruction
- PHI-G – Balance and repair
- PHI-H – External brain capture

## Draft surfaces
- WRI-A – Writing pipeline
- LNG-A – Manifesto draft scaffold

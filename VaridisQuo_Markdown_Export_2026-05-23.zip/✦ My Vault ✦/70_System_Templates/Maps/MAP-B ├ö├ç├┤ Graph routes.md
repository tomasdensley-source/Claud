---
class: B
---
> [!map] Graph routes

Created: 2026-03-23
Kind: Hub / MOC
State: Active

## Children
- MAP-C – Philosophy field map
- MAP-D – Action field map
- MAP-E – Source reading map
- MAP-F – Reference field map
- MAP-G – Persona field map
- [[SYS-C – Graph legend]]
- [[SYS-M – Graph triage guide]]
- [[SYS-O – Advanced Graph View guide]]

## Routes
- Orange nodes mean capture pressure.
- Teal nodes mean map notes.
- Indigo nodes mean permanent thinking notes.
- Blue nodes mean sources and extraction.

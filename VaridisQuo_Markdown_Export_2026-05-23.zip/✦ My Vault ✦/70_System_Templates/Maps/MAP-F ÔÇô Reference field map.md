---
class: B
---

> [!map] Reference field

Created: 2026-03-23
Kind: Hub / MOC
State: Active

This field handles references, public-domain caution, author/work entries, and quote-safety heuristics.

## Children
- [[REF-A – Master reference list]]
- [[REF-B – Public domain only]]
- [[REF-C – Reference intake guide]]
- [[REF-D – Quote safety heuristic]]
- RFN-A – Plato entry
- RFN-B – Epictetus entry
- RFN-C – Marcus Aurelius entry
- RFN-D – Shakespeare entry
- RFN-E – William James entry

## Public-domain children
- PDR-A – Republic public-domain note
- PDR-B – Discourses public-domain note
- PDR-C – Meditations public-domain note
- PDR-D – Hamlet public-domain note
- PDR-E – Pragmatism public-domain note

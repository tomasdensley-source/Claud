---
class: B
---

> [!map] Graph routes

Created: 2026-03-23
Kind: Hub / MOC
State: Active

Use graph view as a triage surface: broad maps first, then clusters, then the child note that resolves your current question.

![[_Assets/Diagrams/Vault Decor/vault-banner-knowledge-river.svg]]

_If the graph feels noisy, start from a field map instead of the whole vault cloud._

## Primary routes
- MAP-C – Philosophy field map
- MAP-D – Action field map
- MAP-E – Source reading map
- MAP-F – Reference field map
- MAP-G – Persona field map
- [[SYS-C – Graph legend]]
- [[SYS-M – Graph triage guide]]
- [[SYS-O – Advanced Graph View guide]]

## Reading cues
- Orange nodes mean capture pressure.
- Teal nodes mean map notes.
- Indigo nodes mean permanent thinking notes.
- Blue nodes mean sources and extraction.

## Navigation pattern
- Start with `Mobile Focus` on phone or `Default` on larger screens.
- Keep node labels on for the first pass and add edge labels only when relationship type matters.
- Hide unrelated top-level groups before increasing neighborhood depth.

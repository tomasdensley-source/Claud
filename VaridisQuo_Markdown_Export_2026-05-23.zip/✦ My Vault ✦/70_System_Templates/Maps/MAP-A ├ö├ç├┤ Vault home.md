---
class: B
---

> [!map] Vault home map

Created: 2026-03-23
Kind: Hub / MOC
State: Active

This is the primary map note for the whole vault. It routes graph use, not just folder use.

## Children
- MAP-B – Graph routes
- MAP-C – Philosophy field map
- MAP-D – Action field map
- MAP-E – Source reading map
- MAP-F – Reference field map
- MAP-G – Persona field map
- [[SYS-A – Vault constitution]]
- [[SYS-P – Live vault and legacy archive]]

## Notes
- Maps point downward into narrower children.
- Use backlinks to travel upward.
- Keep the live vault lean enough that mobile graph navigation stays breathable.

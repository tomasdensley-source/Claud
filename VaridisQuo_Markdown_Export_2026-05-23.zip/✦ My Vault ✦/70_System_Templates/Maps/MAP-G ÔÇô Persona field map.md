---
class: B
---

> [!map] Persona field

Created: 2026-03-23
Kind: Hub / MOC
State: Active

This field keeps identity, principles, voice, worldview, and interview continuity structured without turning into a diary swamp.

## Children
- PER-A – Thomas persona home
- PER-B – Principles ledger
- PER-C – Voice and style
- PER-D – Worldview notes
- PER-E – Postponed questions
- PER-F – Interview session 001
- PER-G – Persona and system relation

## Notes
- Questions can stay open without being rewritten.
- Protocol beats vague self-reflection.

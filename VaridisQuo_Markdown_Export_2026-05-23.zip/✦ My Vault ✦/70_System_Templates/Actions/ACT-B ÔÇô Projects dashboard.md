---
class: B
---

> [!dashboard] Projects and areas

Created: 2026-03-23
Kind: Dashboard
State: Active

Use this note when you need the current work surface without opening the whole vault graph.

## Children
- PRJ-A – Vault stewardship
- PRJ-B – Writing and research pipeline
- PRJ-C – Business offer lab
- ARA-A – Personal operations
- ARA-B – Business operations

## Notes
- Projects are finite. Areas recur.
- Close loops by archiving, not by hiding.

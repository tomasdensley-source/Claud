---
class: B
---

> [!dashboard] Waiting and follow-up

Created: 2026-03-23
Kind: Dashboard
State: Active

Waiting items need visibility without anxious repetition.

## Current waiting
- Confirm citation safety before heavy quotation.
  Waiting since: 2026-03-23
  Next ping: after one more reference pass
- Review whether an offer draft should become a landing page or proposal first.
  Waiting since: 2026-03-23
  Next ping: next weekly review
- Hold cold storage moves until Android retrieval friction is tested.
  Waiting since: 2026-03-23
  Next ping: after one mobile retrieval test

## Children
- CMP-A – Outreach campaign note
- PRJ-C – Business offer lab
- SOU-A – Example source companion
- [[ACT-F – Recovery and re-triage]]

## Notes
- Waiting is a valid state.
- Follow-up cadence belongs here, not inside every project note.

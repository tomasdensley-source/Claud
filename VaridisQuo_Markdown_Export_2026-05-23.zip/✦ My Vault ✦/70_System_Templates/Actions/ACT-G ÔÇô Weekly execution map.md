---
class: B
---

> [!dashboard] Weekly execution map

Created: 2026-03-23
Kind: Dashboard
State: Active

Use this note to decide what deserves energy in the next seven days before you open every project.

## Children
- PRJ-A – Vault stewardship
- PRJ-B – Writing and research pipeline
- PRJ-C – Business offer lab
- [[ACT-C – Waiting dashboard]]

## Measures
- Count finished loops, not just touched notes.
- Separate real blockers from unchosen work.

---
class: B
---

> [!dashboard] Recovery and re-triage

Created: 2026-03-23
Kind: Dashboard
State: Active
Tags:  

This note exists to keep the system accountable without shame.
When the vault drifts, return here and restore state instead of moralizing the drift.

## Children
- INB-B – Triage board
- [[ACT-A – Today dashboard]]
- [[ACT-C – Waiting dashboard]]
- [[SYS-F – Task system guide]]

![[_Assets/Diagrams/Vault Decor/vault-divider-repair-arc.svg]]

## Recovery loop
1. Empty obvious fragments from inbox.
2. Move stale tasks into better states.
3. Archive closed loops.
4. Restart with the smallest next step.
5. Carry only what still deserves a live place in today.

## Notes
- Never base a planning decision on shame.
- Use evidence, state, and next-step logic instead.

---
class: B
---

> [!dashboard] Deep work lane

Created: 2026-03-23
Kind: Dashboard
State: Active

Reserve this dashboard for work that needs uninterrupted structure: philosophical synthesis, source extraction, and serious writing.
Use it to narrow the graph before you begin.

## Children
- PRJ-B – Writing and research pipeline
- PHI-D – Contrast and paradox
- LNG-A – Manifesto draft scaffold
- WRI-A – Writing pipeline

## Rules
- One theme per block.
- No inbox triage during the block.
- Promote one child note before changing context.
- Mark one deep work candidate in the daily note before you begin.

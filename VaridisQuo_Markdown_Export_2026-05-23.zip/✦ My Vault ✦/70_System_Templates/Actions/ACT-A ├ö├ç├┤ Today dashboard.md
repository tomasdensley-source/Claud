---
class: B
---
> [!dashboard] Today dashboard

Created: 2026-03-23
Kind: Dashboard
State: Active
Tags:  

## Do now
- [x] Advance one permanent note from a truth index.
- [x] Keep inbox empty enough to be breathable.
- [ ] Touch one project note and one source note.

## Carry forward
- [x] Any task that misses today gets reassigned before tomorrow starts.

---
class: B
---

> [!dashboard] Reading and extraction

Created: 2026-03-23
Kind: Dashboard
State: Active

This dashboard routes PDFs, source companions, extraction notes, and truth indexes into one controlled flow.

## Children
- MAP-E – Source reading map
- SOU-A – Example source companion
- SOU-C – Example truth index
- SRC-D – Promotion to permanent notes
- [[REF-A – Master reference list]]

## Flow
1. Drop the file in `05_Sources/PDFs/` with its original filename.
2. Create a companion note.
3. Extract claims before polishing prose.
4. Promote durable ideas into `03_Notes/`.

---
class: B
---

> [!dashboard] Today dashboard

Created: 2026-03-23
Kind: Dashboard
State: Active
Tags:  

This dashboard is the daily front door for action.
It keeps status language neutral: today, next, waiting, blocked, scheduled, someday, done, archive.

## Do now
- [ ] Advance one permanent note from a truth index.
- [ ] Keep inbox empty enough to be breathable.
- [ ] Touch one project note and one source note.

## Follow up
- [ ] Translation choice for public-domain quotation.
  Waiting since: 2026-03-23
  Next ping: 2026-03-25

## Think later
- [ ] Expand persona questions only after review.
- [ ] Add one reference entry from active reading.

## Deep work candidate
- [ ] Promote one extracted claim into a permanent note before switching context.

## Needs review
- [ ] Large PDF imports until storage path is decided.
  Blocked by: cold-storage decision and Android retrieval test

## Carry forward
- [ ] Any task that misses today gets reassigned before tomorrow starts.

## Children
- PRJ-A – Vault stewardship
- PRJ-B – Writing and research pipeline
- PRJ-C – Business offer lab
- [[ACT-D – Deep work dashboard]]
- [[ACT-E – Reading dashboard]]

## Notes
- If a task misses today, re-triage it.
- The dashboard exists to reduce fog, not add guilt.

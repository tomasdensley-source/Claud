---
class: B
---

> [!system] Canonical live vault

Created: 2026-03-26
Kind: System note
State: Active

This folder is the canonical live vault.

## Rules
- Open this folder in Obsidian: `C:\Users\nicko\Desktop\◉\01 - LIVE VAULT - OPEN THIS`
- Do not open `C:\Users\nicko\Desktop\Thomas-Vault` for day-to-day use.
- Read HOME-000 – Start here first after opening the vault.
- Read [[SYS-R – Runtime troubleshooting]] if a mobile plugin or graph view behaves strangely.

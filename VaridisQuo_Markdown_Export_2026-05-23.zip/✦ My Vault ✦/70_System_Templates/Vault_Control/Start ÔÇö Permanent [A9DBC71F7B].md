---
class: B
---

# Start — Permanent

This is the entry note for **Permanent/**.

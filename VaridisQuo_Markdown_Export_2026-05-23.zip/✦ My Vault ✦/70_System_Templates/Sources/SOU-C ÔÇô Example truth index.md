---
class: B
---

> [!truth] Truth statement index

Created: 2026-03-23
Kind: Truth statement index note
State: Seeded

This index turns source material into durable claims before long-form drafting.
Each indexed child should be tight enough to survive later editing.

![[_Assets/Diagrams/Vault Decor/vault-divider-evidence-ladder.svg]]

_Only promote claims here once they are compact, auditable, and worth reusing outside the original source session._

## Indexed truths
- PHI-A – Reverse implication
- PHI-E – Guilt and shame
- EXA-D – Child implies parent
- EXA-E – Contrast clarifies value

## Downstream notes
- WRI-A – Writing pipeline
- LNG-A – Manifesto draft scaffold

## Notes
- Index first. Attach examples second. Draft third.

---
class: B
---

> [!source] Extraction workflow

Created: 2026-03-23
Kind: Protocol
State: Active

Extraction notes should stay close to the source but separate evidence from commentary.

## Children
- SOU-B – Example extraction note
- SOU-C – Example truth index
- [[SYS-N – Evidence interpretation speculation]]

## Protocol
1. Lift claims into short statements.
2. Label evidence, interpretation, and speculation.
3. Mark source state as `extracting` or `indexed`.
4. Promote only durable material into permanent notes.

## Notes
- Index first, edit later.
- Attach examples after the indexed claim is stable.

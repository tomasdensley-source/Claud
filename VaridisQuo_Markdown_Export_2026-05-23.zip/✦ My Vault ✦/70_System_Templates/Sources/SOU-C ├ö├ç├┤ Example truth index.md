---
class: B
---
> [!truth] Truth statement index

Created: 2026-03-23
Kind: Truth statement index note
State: Seeded

## Children
- WRI-A – Writing pipeline
- LNG-A – Manifesto draft scaffold

## Notes
- Index first. Attach examples second. Draft third.

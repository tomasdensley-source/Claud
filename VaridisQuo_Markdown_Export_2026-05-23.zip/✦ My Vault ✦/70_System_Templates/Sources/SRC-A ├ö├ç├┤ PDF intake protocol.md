---
class: B
---

> [!source] PDF intake protocol

Created: 2026-03-23
Kind: Protocol
State: Active

This protocol preserves original PDF filenames while still making the source visible in the graph.

## Children
- PDF-A – PDF drop zone
- SOU-A – Example source companion
- COLD-A – Cold storage protocol

## Protocol
1. Put the file in `05_Sources/PDFs/` unchanged.
2. Create a companion note using the template.
3. Mark the source state as `new` or `extracting`.
4. Capture summary, claims, and extraction targets there.
5. Decide whether the file stays active on device or later goes cold.
6. Only then begin promotion into `03_Notes/`.

## Notes
- Use quick intake first. Do deep extraction later.
- Keep the original filename even if the companion note gets a cleaner title.

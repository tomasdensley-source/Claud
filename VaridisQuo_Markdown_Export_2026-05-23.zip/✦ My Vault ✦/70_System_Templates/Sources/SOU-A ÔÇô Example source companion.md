---
class: B
---

> [!source] Source companion

Created: 2026-03-23
Kind: Source companion note
State: Seeded

Seeded demo companion for an eventual PDF. No PDF is bundled here; the note shows the handling pattern.
Attachment: preserve original filename when the real file is added.

## Source frame
- Why this source matters
- What claims to extract
- What to avoid over-quoting until rights are checked

## Children
- SOU-B – Example extraction note
- SOU-C – Example truth index

## Notes
- Use this note as the graph-visible handle for the source.
- Promote ideas only after extraction is stable.

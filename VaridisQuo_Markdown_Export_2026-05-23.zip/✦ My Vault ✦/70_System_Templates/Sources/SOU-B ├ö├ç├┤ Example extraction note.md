---
class: B
---
> [!truth] Extraction note

Created: 2026-03-23
Kind: Reading / extraction note
State: Seeded

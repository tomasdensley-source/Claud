---
class: B
---

> [!truth] Extraction note

Created: 2026-03-23
Kind: Reading / extraction note
State: Seeded

Evidence: shame often narrows perception and increases hiding behavior.
Interpretation: any task system that intensifies hiding will distort self-audit.
Speculation: design language may change whether a vault increases or decreases honesty.

![[_Assets/Diagrams/Vault Decor/vault-seal-witness-ring.svg|180]]

_Keep this note raw enough to preserve signal, but clean enough that later interpretation stays honest._

## Children
- PHI-E – Guilt and shame
- PHI-D – Contrast and paradox
- [[SYS-N – Evidence interpretation speculation]]

## Notes
- Keep evidence, interpretation, and speculation distinct.
- Do not polish this into prose too early.

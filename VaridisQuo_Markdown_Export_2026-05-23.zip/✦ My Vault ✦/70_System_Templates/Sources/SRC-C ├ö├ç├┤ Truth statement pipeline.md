---
class: B
---

> [!source] Truth statement pipeline

Created: 2026-03-23
Kind: Protocol
State: Active

Truth indexing is the hinge between reading and writing. It prevents the draft from becoming a second capture layer.

## Children
- SOU-C – Example truth index
- SRC-D – Promotion to permanent notes
- PHI-A – Reverse implication
- WRI-A – Writing pipeline

## Notes
- A truth statement is compact, auditable, and later expandable.
- Move from `indexed` to `promoted` only when the claim survives beyond one reading pass.

---
class: B
---

> [!source] Promotion to permanent notes

Created: 2026-03-23
Kind: Protocol
State: Active

Promotion should happen after extraction and indexing, not during first-pass reading.

## Children
- SOU-C – Example truth index
- PHI-A – Reverse implication
- PHI-E – Guilt and shame
- WRI-A – Writing pipeline

## Promotion checks
1. Confirm the statement is durable beyond one source.
2. Create the permanent note with a clear child-facing title.
3. Attach examples after the indexed claim is stable.
4. Only then feed the note into longform drafting.

## Notes
- Promotion is a compression step, not a copy-paste dump.
- Keep the permanent note narrower than the map that will receive its backlink.
- Change the source state to `promoted` when the new permanent note is stable.

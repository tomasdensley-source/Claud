---
class: B
---

# READ ME - Comprehensive Atomic Reverse Implication Vault

## Assertion
This vault converts the PDF into a reverse-implication Obsidian graph where each note has one thesis and points upward toward abstraction.

## Definition
This map defines the vault rules, count summary, and graph gradient used to navigate the atomic notes.

This vault is generated from *The Ledger Speaks - Fifteen-Part Chiasmic Socratic Chain*.

## Enforced rules

- Axioms appear once only, in `01 - Axioms`.
- Every axiom has at least three implication children discoverable through backlinks.
- Every note has one assertion.
- Every note has a definition section.
- Authored wikilinks point upward toward abstraction only.
- Implication children are not linked downward from parent notes.
- Every extracted truth-statement from the PDF is answered for as an atomic note or as one canonical axiom note.

## Counts

- Canonical axioms: 91
- Atomic child notes: 1109
- Total Markdown notes, including maps and doctrine: 1200

## Graph gradient

Blue means more axiomatic. Green means more implication-dominant.

- `#gradient/1`: most axiomatic
- `#gradient/2`: axiom-heavy definition layer
- `#gradient/3`: bridge layer
- `#gradient/4`: reverse implication layer
- `#gradient/5`: implication layer
- `#gradient/6`: most concrete example layer

---
class: B
---

> [!archive] Retired taxonomy test

Created: 2026-03-23
Kind: Archive note
State: Archived

Seeded archive example: a note preserved to show that closed experiments can remain visible without polluting active dashboards.

## Notes
- Archived notes should stay quiet but legible.

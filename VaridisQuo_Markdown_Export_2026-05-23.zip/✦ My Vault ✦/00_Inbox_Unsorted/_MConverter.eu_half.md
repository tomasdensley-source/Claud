---
class: B
---
****

**Ask Your Female Partner **

## **To Be Dominant in Bed **

****

****

**\[play safe, sane and consensual\] **

****

***February 2023 – Ver. 1.1***** **

****

****

****

Submissives, why just dream about serving a dominant female when you may be already in a relationship with one? Many women just don't realise that they can be dominant because they have been held down by a male dominant society. Every woman has a hidden female power that if released will cause her to be a bold, confident, dominant woman. 

Therefore, if you are a submissive who is in a serious relationship with a woman, you need to search no further for your Dominatrix. She is right in front of you. The challenge for you is to draw out her dominant nature with your submissive nature. The women that have unleashed their dominant female power have men and women begging to serve them. If you don't believe me, check out how many professional Domina ads there are currently are on the Internet. 

In order for you to draw out your partner's dominant nature, you must seduce your partner with your submission. Don't show your partner material about D&S, B&D and S&M., and expect her to be enthusiastic about it. She will probably think that these activities are strange and might even think that you are strange. However, if you seduce her dominant nature and draw it out of her, once it starts to come to the forefront, then you can introduce her to some D&S, B&B and S&M activities. So, how do you seduce your partner's dominant nature with your submissive nature? 

You begin by treating her like a Queen. You begin by serving her as if she was already the dominant woman of your dreams. Be humble and submissive around her. Don't argue with her, don't yell at her, and don't give her any back talk. Your purpose in your relationship is to serve her. What she says goes, so be quick to agree with her. 

Page 2 

Another thing that you can do to seduce your partner's dominant nature is to offer to give her foot and body massages. When she gets home from a hard day's work, don't sit and watch television and ignore her. A submissive exists to tend to the dominant's needs. Go and keel next to her, take off her shoes, and rub her tired feet. As she relaxes in pleasure, work your massage up her legs and massage, and lightly scratch her legs. Do this on a consistent basis. While you are doing this, tell her that you love and adore her. Tell her that you exist to serve her. 

Eventually, you might take more liberty as you rub her feet. You might start to kiss and lick her feet. I wouldn't do this the first time, but if she responds positively to the massages, then keep adding to them. You might work your kissing and licking from her feet, up her legs, and then to her crotch. 

That's right, get in the habit of orally servicing your partner. Kiss her body all over and make love to her with your mouth and tongue. Do not ever penetrate her with a dildo or your penis, unless she requests it. Do not focus on your needs, but instead focus on her needs. Please her sexually as your Queen. Don't you dare ever take the liberties, without her permission. 

The goal is to get both you and her in the habit of viewing sex as being for the Dominant's pleasure. It will be for your pleasure only if she says so. Which brings up another way that you can seduce her dominant nature, whenever she gives you permission to enter her or whenever she is giving you pleasure, always ask her permission before you climax. 

She will again probably be amazed that you are even asking, but eventually she will come to really like the idea that she controls your orgasms. 

Page 3 

All of these "little" things will seduce her dominant nature and it will cause her to grow more dominant. Whenever she asks you why you're treating her so well, tell her it's because you love her and because you've come to realise that you're submissive and want to be submissive towards her. 

Tell her that she's your Queen and that you exist to serve her. 

Now be careful here and don't over do it. Tell her your feelings about how you want to serve her, then leave it at that. She might ask you what has made you to feel this way, and if she does, it presents you with a real opportunity. 

Tell her that you have had submissive feelings towards her for sometime, but that you were afraid to express them before. Then tell her that you have been reading a lot on the Internet about Female Domination and that it has touched a chord within you. Again, let her know your feelings but don't over do it. Do not bring up B&D, D&S, S&M at this time. 

When do you bring up D&S, B&D, S&M? When she starts to respond positively to your submission and she starts to ask you more about Female Domination. Then you can begin to introduce her to this lifestyle. You could buy her an introductory book. She will begin to understand that you desire to serve her. 

From this point on, slowly introduce her to D&S, B&D, S&M. Buy her some fetish clothes, and maybe a leather paddle or a whip. Again, only move at her pace. If you sense that she is starting to become negative, then back off the D&S activities and refocus on just serving her. Not every woman will react the same and not every woman will grow at the same pace. However, I believe that if you are persistent and consistent, then your partner will eventually overcome her inhibitions and she'll allow Page 4 

her dominant nature to freely flow out of her. Then she will totally seize the reigns of your relationship and she'll fulfil her potential as a dominant woman. 

****

****

Page 5 

**5 Ways to Make Her Dominate You in The Bedroom **

****

**1. Make the Fantasy Clear to yourself **

With any sexual fantasy, the first thing you want to do is figure out what exactly you want to play out. 

“Domination” has a wide variety of meanings, not all of which may actually appeal to you. Take the time to think through a few scenarios and get clear on what turns you on. Do you want her to simply be more assertive and in control? Do you want to be tied up? Do you want her to use paddles, floggers, or ball gags? Do you want to role play a rape scene? You don't need to feel ashamed if that's the case, but there are safe ways to enact a rape fantasy, and you need to do some research beforehand. 

Of course, you can't know everything in advance, but it's important to be honest with yourself here about what, specifically, you'd like to see happen. 

If the two of you have never incorporated domination into your sex life before, start by dipping your toes in the shallow end. You don’t want to overwhelm yourselves by attempting a huge, over-the-top production your first time out the gate. Think using a pair of restraints on your wrists, or even just having her pull your hair during sex. You can work your way up to more complex acts from there. 

## **2. Bring It Up Again **

Once you figure out what you’re looking for and where you’d like to start, it’s time to bring it up with her again. Don't wait around for her to initiate. It’s *your* fantasy, so it’s your responsibility to get the ball rolling. Be casual but clear in your intentions. Try something like, "Hey you know that domination thing I’ve mentioned before? I’d really like to actually try that." 

Page 6 

Don't be afraid to be specific either. You can say something along the lines of, "I was thinking about it some more, and what sounds hot is if you could be really bossy to me in bed. Maybe call me dirty names and demand that I service you. How does that sound?" 

It’s quite possible that the only reason she hasn’t yet followed through on your hints is that she simply forgot, so give her a specific timeline, such as, "Could we give it a go tonight?" or, "How about this weekend?" 

## **3. Acknowledge the pressure **

If she’s particularly shy or timid, you can assuage some of her fears by saying something like, "I know we've never done anything like this before, but I'm really interested in experimenting with you." 

Perhaps you even have a few hesitations of your own that you could share with her. Talk about the specific acts that are on or off the table, and see if you can find compromises. Say, for example, she’s not too keen on the idea of choking you, but she’s willing to play along with a little spanking. 

I can't predict your girlfriend's reaction to your request, but I can offer a few guesses: Sometimes people can feel a lot of pressure around acting out their partner's fantasies. It might feel to her like it’s entirely on her shoulders to deliver you a night of crazy passion that lives up to all of your wildest dreams. Keep in mind that this is *your * fantasy, and make it clear to her that you’re sharing the responsibility in making it come to life. You can take some of the more visible or active steps, like purchasing the restraints or paddles, or you could keep expectations low by reminding the both of you that it’s also your first time experimenting with domination. 

Page 7 

**4. Reinforce That This Isn't About Being Bored** Another fear that I frequently see come up is the worry that having a specific fantasy means you’re not attracted to your partner. Your girlfriend may be wondering if you’re more aroused by the fantasy of being dominated than the reality of who she is as a person. So if she's a naturally sensitive, considerate girl, she might feel self-conscious knowing that you get turned on by the idea of some masochistic brute pushing you around. You can alleviate these fears by telling her this fantasy is only one aspect of what turns you on, and reassure her that you don't just want any random girl to dominate you; you want *her* to do the job. 

It’s also important to be a giving and generous partner in return. Ask your girlfriend if she has any fantasies or special requests you can help her act out. Make an effort to enthusiastically follow through on any of her desires, as long as they feel comfortable to you. Seeing that reciprocity on your end will likely inspire her to channel her dominant alter-ego more frequently. 

**5. Pick a Safe Word, No Matter How Safe You're Playing It** Always agree on a safe word before experimenting with role playing, especially when power play is involved. A safe word is something you wouldn't ever say during a sexual interaction, like “lemon” or 

“elephant”. If the safe word is ever uttered during sex, it means, STOP. RIGHT NOW. Don’t ever use a word like “no” or “stop” for your safe word, as it’s likely you would use them during a role play, and having the old, “wait, is that a ‘stop’ or a ‘STOP’?” conversation in the middle of sex can be really awkward. 

Page 8 

Most of all, have fun\! And remember: this is *your * fantasy. Not being in control may be part of what you find arousing, but you still have to do the work to communicate what you want to your partner. 

Trust me, a little work beforehand will make things safe and sexy for both of you. 

Page 9 

Train your Husband to be your Sissy 

- The Comprehensive Guide of Sissy Training – 

Version 1.1 

\[play safe, sane and consensual\] 

Now boys, before you all go racing out to buy a pair of frilly knickers, the women, usually, don't want to fuck sissybois. They just love the idea of owning a subjugated male whose sole job is to fluff their "bulls" and to then use their tongues to clean the bull's cum out of their pussies and ass and off their faces after they've been used like the sluts they secretly yearn to be. 

So, ladies, this is how to do it. But beware because it more often leads to complications than not\! And know that if you're going to do this you're committing yourself to at least 6 month project. But if your man is, as is described below, it's going to be more like a 2 -- 3 year project\! 

I have assumed here that you're not already in a D/s \(Domination/submission\) relationship with your man and that you haven't already 'played' with another woman \(willingly or just because you wanted to keep your man with you and happy\) 

*If you're already in a D/s relationship with you as the submissive partner, good luck breaking* *him out of that\! He's already getting everything he desires and he won't give that up easily. It's* *not impossible though as it's widely held that virtually no one is 100% dominant or 100% *

*submissive, we all have, to some degree, switch desires and capabilities within us. * 

I'm also using, as my start point, a 'worst case scenario' for you. Your man is 100% straight and has no interest in doing anything with another male. He has believed, until now, that he's the dominant partner and will resist being turned into the less powerful one and will absolutely resist any attempts to introduce another cock into your relationship. Your current sex life is probably plain old vanilla 'cock in vagina' fucking where he hardly considers your wants or needs at all. He thinks a quick tweak of your tits and rub of your puss means you're good to go. 

*There's a pretty good chance he's actually a whole lot more submissive and willing to be* *dominated than you would believe. As I've observed many times in the past. Submissive men* *are a lot like dog shit on a Parisian street. You can't help but stand on some every time you* *turn around\! If he is most of these steps won't be needed. You'll be able to tell by how readily* *he accepts being locked into the cage and feminised and how soon he accepts you bringing* *another cock into your relationship. I'd still recommend starting with a transgirl or* *crossdresser, though, because he's much less likely to get freaked out\! \(After all the only* *difference between a straight man and a bisexual man in a 6 pack of beer, a hot tub and a* *reasonably attractive transgirl\!\) It's also that he'll be much more willing to let a pretty* *crossdresser or transgirl suck him off and to go down on her than a masculine man the first* *couple of times. Most men are sluts and, as long as they're getting their rocks off regularly,* *they don't care whom it's with\! *

Page 2 

**1. Getting him started on his journey. ** 

Buy your man a chastity device \(cock cage\). One that is lockable, make sure the key is well hidden. Then, on a Friday night, induce some sex play and, as you go down on him, say you want to try something a little kinky then lock him into the cage. Now tease him mercilessly. 

Kiss and stroke all of his erogenous zones. Neck, nipples, perineum, spine, backs of knees, etc. Create as heightened a sense of arousal in him as you possibly can. As soon as he is as turned on as you can possibly make him grab him forcibly by the hair, or back of the neck if he has none , look directly into his eyes and say firmly "I'm not going to let you out until you have satisfied me completely." 

Then lie back. You must not allow him to go directly to your breasts or pussy. He will try to, trust me\! He must start at your feet and massage/kiss/stroke his way up both legs, skirt around your whole pussy area, and do the same across your stomach, skip your breasts and work on both of your arms. You must then roll over and make him kiss the nape of your neck and trail kisses down your spine. Have him tongue the cleft of your ass, allow him to taste your taint and tongue your rose bud \(if it's something you like having done, make him do it\) then down the backs of your legs. Have him softly lick the backs of your knees. 

Once he has completed the tour of your erogenous zones, and only after he has toured them all. 

*You must get him used to serving your needs primarily before considering his*. 

And no matter how turned on you are, you will then turn on to your back and guide him to your breasts. Show and tell him how to do it properly. 

*If you really want to know how having your breasts fondled and caressed properly feels like* *get another woman to do it\! * 

Voice your approval as he learns how to caress, suck and fondle them the way you like. Once you are as close as you can get to orgasm without popping guide his head down to your pussy. Once again, you will need to show him what you want. Tell him what you want/need. 

*You're training him to obey your voice and service all of your wants and needs primarily. * 

Show your appreciation as loudly as you dare when he does it well. Guide and show him when it's not quite right \(be careful to offer no criticism though\). 

As soon as you orgasm, or are satisfied, if you're multi-orgasmic, immediately roll over and go to sleep. 

*Pretend if you have to\! * 

Page 3 

He will probably protest but pop an eye open, throw a hand over him and say something like 

"My God, baby, that was so good\! You've completely worn me out. I'll take care of you in the morning, I promise." 

**2. Making him horny**. 

As soon as you wake, try to be as late as possible, get out of bed. Shower, get dressed, do your make up and go out for most of the day. He will probably follow you out hoping you will 

'take care of him as promised' but look at your phone or watch or clock and go "Fuck\! I'm late\!" When he asks where you're going sigh and say something like "I really don't know why I bother telling you anything because you never remember\! I'm meeting the girls \(or your parents, or you've got a work thing\) for brunch, remember?" 

*It doesn't matter that it's not true because he probably would have forgotten any way, right? * 

Grab him by the cage, he will be excited and trying to go hard, but the cock cage will be preventing it, pull on it tightly enough to be slightly painful and say "You were so good last night, lover, I hope you can give me a repeat performance this afternoon?" Kiss him passionately, try to fan his arousal levels as high as you can with your kisses and touch whilst keeping hold of the cage. 

*You have to remember men are very cock centred in their arousal. * 

Press your breasts against his chest or arms, kiss him again, let go of the cage and walk out. 

*If he wants out of the cage give him a mischievous smile and say "No, you'll just have a wank* *as soon as I go, I know you\! And I want at least as good a performance when I get back as I* *got last night\!" * 

You must go out until at least mid-afternoon but send him regular, but irregularly spaced, texts telling him you're thinking about how good the sex was last night and how much of a stud he was and how you're hoping for another session at least as good when you get home. 

**3. Getting him to wear his cage all the time. ** 

When you get home grab him by the hand and lead him straight to the bedroom. Drop your clothes to the floor just as quickly as you can, climb up on the bed, spread your legs, touch your pussy and say "Hurry up, baby, I need you right now\!" 

Make him strip naked, except for the cock cage, of course, before letting him up on the bed. 

Page 4 

*He'll probably want you to take off the cage. Say "Not till after you've done me first\!" Give him* *a really big smile and pat the bed beside you. * 

This time allow him to go straight to your breasts, you're turned on, remember? You don't 

'need' him to warm you up this time. He must start at your breasts, though, and you must make him go slowly and gently so that he is actually turning you on. 

*Remember, you are teaching him that your needs come first. * 

Make sure you are vocal in your appreciation of what he is doing, guide him, show him, not so much verbally, but by guiding with your hands and by moaning loudly when he gets it right. 

Once you are ready guide him down to your pussy and have him tongue you to another orgasm \(or multiple orgasms\) until you are satisfied. 

Once you're done pull him up so his head is on the pillow with you, snuggle your naked body as close to him as you can to him, grab hold of the cock cage and gently play with it. 

*By now his balls will be aching and he will badly need to come. * 

Kiss him and praise his love making generously. Tell him how good he was and how good he made you feel. 

*Here comes the key part \(because you need him to stay caged\). * 

Pull a little more insistently on the cock cage and say something like "I think this has really helped. It seems to have made you much more enthusiastic and conscientious about looking after me first and not just looking after your own needs. If I promise to look after you too, will you leave it on for me?" 

You must now wait\! Men are like steam engines\! They can't do anything without a whole lot of huffing and puffing. He will voice some protest but it's vital you remain quiet until he either agrees or goes silent. If he hasn't answered "yes", simply look him in the eyes as adoringly as you can, and say "Please?" He will still likely say no, but you must not relent. Just pout and say "Please, baby, I really like being like this with you." 

If he still says no, don't insist, you'll just make him angry. Release him from the cage. 

You'll probably have to let him fuck you to keep up your end of the bargain. But don't allow him to touch you sexually again until he agrees to be caged. Every time he asks or tries to initiate something just sigh and say something like "I don't think you care about my needs at all, only about your own." 

*Men really hate feeling like they've disappointed the woman they love. * 

Page 5 

Over the following days, at least a couple of times during every night, fondle him to hardness but when he turns to you and tries to initiate something shrug him off with an annoyed grunt as if he's woken you up. 

After a few days he will, more than likely, put the cage on himself. If he doesn't ask him to put it on for you again. He'll huff and puff again, but you need to remain silent, if he doesn't acquiesce say "Won't you do this one little thing for me? It feels so good, for me, when you're in this and looking after me first." And look at him fetchingly. If he masturbates don't say anything just look disappointed. 

*Keep this up and he will fold and agree if for no other reason than that he knows he's not* *getting any until he has. *

**4. Once he has agreed to being caged voluntarily, and has gotten used to wearing it,** **you can move onto the next stage: Sissifying him. ** 

You start by grabbing the cock cage and saying "All this pubic hair must make wearing this really uncomfortable. Let me shave it off for you\!" Don't let him say no. Just drag him by the cock cage into the shower, turn the taps on, take off the cage, grab his razor, lather him up with some soap, and begin to shave the area. Make sure you are teasing and playing with him, take him in your mouth and say "It'll be easier if you're hard cos everything will be out of the way\!" 

*Do not let him come\! * 

Make sure his whole jockey brief area is well shaved. Remove all the hair from around his cock, balls, perineum and ass. Tell him, very vocally, how good it looks and how sexy you find it, that it's turning you on and that his cock looks so much bigger shaved like this\! 

*Cock ego and envy is very central to a man's psyche. * 

The area will rash the first few times if you don't treat it properly. It's the itchiness and rash that stops most men from wanting to repeat the process. To prevent this, baby powder works well, so does baby oil. Put it on for him over the next few days, until it's time for him to shave the area again. Use it as another way to keep his arousal levels high. 

As he is now as hard as a rock, and aching to come, you need to get rid of his erection before you can get the cage back on. So lead him back to the bed. If you're not already shaved around your pussy area bite your lower lip and look a little shy and ask "Will you shave me down there too, please?" 

*Keep in mind you are trying to teach him to obey your every whim and command. * 

Page 6 

Send him to get a towel \(for under your bottom\), a hand mirror \(so you can see if he's got everything\), his razor, some shaving foam, a facecloth and a bowl of warm water. Get him to shave you clean. Allow him, in fact, encourage him, to play with your clit and pussy and to slip his finger inside you. Luxuriate in the attention and let yourself get really turned on so he can feel the wetness and heat coming from your pussy. 

*Obviously if you're already shaved or waxed or lasered down there you can skip this part. * 

As soon as he's finished guide his tongue back onto your pussy. Tell him you want to see him masturbating as he eats your pussy but he's not to come until you tell him you're satiated. 

Once he has satisfied your needs say something like "I want you to kneel between my legs and masturbate until you come on my pussy. I want to feel your come hitting my labia and leaking down my pussy, being shaved like this, it will be so hot\!" 

*It's very important that you don't allow him vaginal sex until he is ready to become your sissy* *cock slave. * 

Trust me, it won't take him long to come. Tell him how hot that was to watch and feel. Place your hand on the back of his head and see if he will let you guide him down to use his tongue to clean you up. If he doesn't resist or he seems willing but a little hesitant say "Use your tongue to clean me up, baby\! That would be so hot\!" 

Do not insist though, he needs to think he is a willing participant in his sissification. If he doesn't want to lick you clean you still need to make him clean you up. Send him to get a wet warm washer. 

*Cleaning you, as well as your bull up, after sex will be one of the sissy's main tasks. * 

Don't let him take too long though or he'll be hard again and you'll have to repeat the process of getting rid of his erection. While he is still soft lock him back in the cage. Tell him how sexy it looks and how much you like how he has been 'looking after you' sexually and how much fun it's been and is going to be. Make sure he knows how much you like how his cock and balls look shaved and in the cage \(so horny making\) and how you expect him to keep the area clean shaven now. If you'd like to remain 'bare' down there make shaving you part of the weekly duties he has to perform to be allowed to get his reward. 

*If he presents unshaven refuse to even allow him to touch you until he's cleaned himself up. * 

It's very difficult to keep everything around the cage completely shaven so make it a weekly event that you release him from the cage, have him shave it all properly \(and you if that's required\), show you how good a job he's done \(that he's been a good boy\) and then masturbate onto your pussy or stomach or breasts. 

*Never onto your face, no matter how much you like it\! And never let him come on your ass* *because you want him to get used to showing you what he's doing. * 

Page 7 

*There will be things that he will never be allowed to do, like coming on your face or fucking* *you in the ass, because they are reserved for your bulls. He needs to eventually learn that the* *reason you have to take a bull is because he in inadequate for your needs. * 

Then he goes straight back into the cage. 

**5. Keeping him in a constant state of frustrated arousal. ** 

This once a week masturbation is the only relief you will allow him. Make sure you tease and play with him every chance you get so he's in a constant state of frustrated arousal. Keep telling him that you will 'look after him, too'. But that having him so attentive makes you so horny and feels so good that you want him to stay that way a little longer. Say "Think about how good it's going to be, for both of us, when I finally let you fuck me\!" 

*It's also vitally important, for now, that you don't 'make him come', not with your hand or* *mouth or pussy or ass. His role is to satisfy you, then, if he's been a really good boy and* *satiated you completely, you will allow him to get himself off. * 

Every so often you will need to pretend he hasn't done a very good job at getting you off \(even if he has\). That you're not 'properly satisfied' and make him watch as you pleasure yourself to a very loud orgasm \(pretend if you have to\). Then refuse to let him come on you as he masturbates because he hasn't satisfied his end of the bargain. Make him come on his own stomach. Gather some of his come on your fingers and see if he will lick it off for you, wipe it on his nipples, if he won't. 

After he has come, spread your legs, touch your pussy and ask if he'd like to try again to get the chance to come on your breasts? If he will help and guide him so that you can have a really good orgasm and reward him appropriately. If he refuses don't let him anywhere near you until the next week. 

*He will, of course, be trying to insist on actually fucking you \(putting his dick in your vagina\). In* *turn try to insist that he doesn't because "I want to keep exploring what we're doing together* *because I don't think either of us have had so much fun or come as hard as we have these* *last few weeks\!" * 

*You may need, from time to time, to break the 'no penetrative sex' rule to keep him from* *rebelling and refusing to play anymore games. *

## **6. Starting his feminisation. **

After a few weeks of this, and on a day just after he's shaved and is about to masturbate, throw him a pair of your knickers, or a pair you've bought specially for him if he is too much Page 8 

bigger than you to wear yours, and say "Put these on for me, lover? I think they will look so sexy that I will probably get really horny, and you know what happens then\!" and smile. 

*It works especially well if it's a pair you've worn and been aroused in, ask him to sniff them* *first and then put them on. * 

He will most likely protest "I'm not a pooftah", he'll say. Reply "I know you're not, silly\!" Touch your pussy or cup your breasts. "You've shown me that very well lately\! I just think it will look as sexy as hell\!" 

As before you now need to remain silent. If he refuses shrug and tell him to put the cage back on. Say "I don't know what your problem is. It's going to make me horny and you're going to get to come, so why won't you put them on for me?" 

Refuse to let him even masturbate, let alone, come on you, if he won't put them on. 

*Use the same process as before. He'll cave even quicker than the previous time. * 

*Always make him lock himself back into the cage so he knows he's doing it voluntarily. * 

Once he has them on you need to exclaim over them. Grab his ass and tell him how hot they make his ass look. Caress all over them. Push your finger up towards his rosebud through the material, pull them out of the crack of his ass and slip your fingers inside the leg opening and caress his ass and entrance to his anus. Mouth his caged cock through the material. Tell him how hot it's making you and that you're going to need him to make you come again. Guide him into a 69 and, as he services you with his mouth, play with his knicker covered ass. Slide your hands inside and caress his ass and his caged cock. Work a finger toward his anus, touch and stroke the entrance to his anus. If he protests just go "Shhh\! It's turning me on, can't you feel it?" and keep going. Let him bring you really close to orgasm then push him off, pull his panties down far enough to take the cock cage off and immediately lie on your back with him between your legs. Say "Fuck this is so hot\! I want you to masturbate yourself over the top of the waistband of your knickers, whilst I make myself come. I need to feel your come splash on my pussy as I pop\! Can you come with me? Come on my pussy as I orgasm?" 

*He will, of course, be keen to come. * 

Once he's shot his load take him by the back of the head and guide his head down to clean you up again. If he still resists say "I think watching and feeling you clean me up will make me come again. Please, baby, make me come again? You make me so horny\! I need to pop again, please, baby?" 

If he does it you need to come\! Fake it if you have to\! Then tell him over and over again how fucking hot it was, how good it felt and how you hope like hell he'll do it again. 

Page 9 

*If he doesn't want to use his tongue to clean you still it's important that you don't make a big* *deal of it. Just keep trying every couple of times and tell him how hot the thought of him doing* *that makes you until he does. * 

*Don't forget to hand him his cage so he remembers to put it on. *

**7. Starting to teach him his role. ** 

Make this part of your weekly routine but remember, it's vitally important it's not you that makes him come. He needs to learn that having you give him an orgasm will only be allowed when he's been a very good boy. 

When he gets used to wearing the knickers as part of your weekly play sessions, on a day when he is out, remove all of his boy underwear and replace them with a selection of women's knickers. Have some frilly ones, some thongs, some boy cut briefs he can wear for work and any others you think will suit him. When he complains simply say "Your ass is so sexy in your knickers I want you to wear them all the time. It'll make me so horny at work knowing you're wearing some sexy knickers I chose for you I'll probably need you to fuck me as soon as you get home\! Please, baby? It will make me happy\!" 

Silence now, is again your best friend. If he tries to refuse say "What's the big deal? Only you and I will know and it looks sexy and it turns me on. Don't you like turning me on?" 

If you quietly but stubbornly insist, using the same techniques as before he will soon give in and agree to wear them. 

*Every time he 'gives in' you need to thank him and reward him for acquiescing to your needs. *

*Let him have an extra orgasm or make him a really nice meal, something. *

**8. Training him to like ass play. ** 

Now is the time to introduce more and more ass play when he's servicing your needs. Play with his butt, slide your fingers into the crevice of his butt. Get him used to you stroking and playing with his taint. Keep sliding your finger toward his anus until he allows you to touch and play with his rosebud. Wet your finger and use it to rim his anus. Slip a little bit of your finger in. Every time he protests tell him "Shhh it's turning me, and you on. I can tell by how your cock throbs every time I do it." 

But remove your finger for a bit before returning to it again. Start to play with his balls as he masturbates for you. Stroke his taint as you handle his balls. Wet your finger and reach toward his rosebud and make the area as moist as you can. Slowly get your man used to having your fingers around his taint and anus and a finger probed a little into his butt. 

Page 10 

Obviously you will need to sit up to do this. Let him rub his cock on your breasts if he's letting you play with his taint and/or ass, but lean back away, so he can't, if he resists your probing fingers. Push him away if he tries to follow you with a curt "no". Reward him with contact with your breasts once he lets you start playing with his ass again. 

Once he allows you to slip a little bit of your finger inside his ass as he masturbates tell him how horny doing that is making you, how slutty it makes you feel and how much you love doing that for him. He will eventually relax and enjoy the sensation. Once you can tell he is enjoying having his ass fingered \(it might take a few sessions\) wait until he reaches that point of no return and is starting to come and push as much of your finger into his ass as you can and hook your finger back towards his balls. Hopefully your finger will scrape across his prostate, if it does then then, trust me, he'll want you to do it over and over again. Push the mounds of your breasts firmly around his cock and let him come on them. Come if you can, pretend if you can't, and say "Fuck\! I came just from doing that\! Fuck doing that is so hot\! You have to let me do that again\! Oh, baby I came so hard\!" 

As usual, make him use his tongue to clean you up but guide his head between your legs again because he's made you so horny. Again, pretend if you have to, he needs to know that what you're doing to him you're doing not only for him but because it turns you on. Trust me, he loves the fact he makes you horny enough to come. 

*Getting him to do what you want is really a simple matter of rewarding him when he obeys* *and ignoring him when he won't but continuing to fan his sexual arousal. *

**9. How to enjoy anal sex. ** 

If you're thinking you're going to want to try anal, or you've already experienced it, but it wasn't done properly, so it hurt, and you want to try again, this is the time to teach him how to service your ass. Lift your hips up and throw your legs over his shoulders. Guide his head lower until his tongue is licking your taint. 

*Don't do this unless you are scrupulously clean in that area and around your 'starfish'\! * 

Use verbal encouragement as well as constant pressure on his head to encourage him to keep licking there and/or to go further towards your rosebud. Tell him how good it feels and how hot it's making you. 

*Remember, eventually, you're going to want to get him to the stage he willingly does this for* *your bulls \(prepares your ass to take their dicks\). * 

Make him tongue your ass and lick your taint and rosebud. Roll over onto your stomach, put a pillow under your hips, so your ass is raised. Then he'll be able to tongue you from your clit, across your vulva and perineum, and all the way to your rosebud. Every time his tongue hits your rosebud groan in appreciation. He'll soon get the hint to concentrate on there. Instruct Page 11 

him to hold your ass cheeks apart and tongue your rosebud and to push his tongue as far into your ass as he can. Have him 'fuck you in the ass with his tongue' shoving his tongue as deep as he can, withdrawing it, then repeating. You need to be very verbal about how good it feels. 

Reach between your legs and start to masturbate yourself. Make sure you show by your moans and thrusting hips how much you're loving what he's doing. 

*At this time he is going to try and fuck you, probably in the ass, but definitely in somewhere* *\(he'll ask you to take the cage off so he can\). It's extremely important you don't let him\! No* *matter how turned on and horny you are you must resist\! Fucking you in the ass is going to be* *something he never gets to do, it will be reserved for your bulls. His job is going to be to make* *sure your ass is ready to receive the 9in monster you're hoping to score with. * 

Tell him you're too scared to let him fuck your ass because every time you've tried it it hurt but that you want to lie on your stomach and finger yourself to orgasm as he rubs his cock along the crack of your ass between the cheeks. Remove the cage and have him tongue your whole crack until it's sopping wet with saliva then have him lie on you with his cock between your cheeks and let him hump you. Every time he tries to slip it into your ass or pussy, and he will try, tell him "no" curtly and that you're going to make him get off and put the cage on if he continues to try. 

Tell him you want to feel him come on your ass as you orgasm \(to help him, regularly squeeze your ass cheeks together around his cock\) so he needs to wait until he feels and hears you starting to come. Once you've come, and he's shot his load, make sure you have him clean you up, but now, as he has been a very good boy, you need to reward him. I'll leave that up to you. You can let him fuck you, or give him a blow job, you choose. Definitely one of those two, though. But, as soon as he has come and cleaned you up, back into the cage he goes. 

*He'll be even keener to please you now as he knows when he does he will get his prize of* *actually fucking you or being blown. *

**10. Teaching him more of his role. ** 

He now needs to get used to preparing your ass to receive your bull's cock. Ask him to buy you a series of butt plugs ranging from really small to as big as you think you might like to take. Say to him "I want you to be able to fuck me in the ass." 

*Be crude in this situation because he loves to think you're a 'dirty' girl* 

"But you're too big. Will you help stretch me?" 

Hand him some lube, your vibrator and the smallest of the plugs, lie on your stomach, spread your legs and slide your hands down to your pussy and start to play with yourself. Ask him to tongue your clit and vulva and to make your taint and ass all wet and slippery. Ask him for the Page 12 

butt plug and to watch for a moment. Lasciviously suck it and make it as wet as you can make it \(he'll love the show\) then hand it back to him and tell him to be gentle. Have him rub it around your rosebud and to gently apply pressure to the entrance. Your 'starfish' will get dry fairly quickly so keep getting him to tongue the area as it does tell him to lube up the plug as well. When you're ready tell him to gently push the plug in. 

*He needs to be in his cage for this because, if he isn't, he's going to try and substitute his dick* *for the plug and if you're as turned on as you should be by now you'll probably let him\! * 

As the plug slides into your ass it will probably hurt some \(even when you're stretched, and used to taking cocks up there, as the head pops through your knot there is usually a stab of pain\). Ask him to stop and clench down on the plug with your ass sphincter. 

*Similar to those Kegel exercises you were meant to do after having your children, remember? * 

Then relax your sphincter and give a gentle push, as if you're trying to push the plug out, then relax and tell him to continue \(repeat as necessary\). Once it has popped through the knot \(it will feel similar to when a man's cock head pops through\) the part of the plug after the widest bit is quite narrow and will sit inside you comfortably. Give yourself time to get used to being 

'filled up' while continuing to play with your pussy and clit. Use your imagination, if you have to, and pick someone you'd really like to have in your ass and fantasise it's him. Once the plug feels comfortable get him to tongue the cleft of your ass and gently pull back and push in on the plug. Make sure it doesn't slip past the knot until you are used to that feeling \(clench down on it with your sphincter if it feels like it's going to\). 

*You'll probably come to love that sudden intense feeling as the plug, or your bull's cock, pops* *through the knot but probably not immediately. * 

As your excitement rises tell him to increase the speed of his pushes and pulls. As you get close ask him to use the vibrator on your clit and pussy. Use your fingers to guide him because he probably won't know what he's doing. As you get to almost 'that' point tell him to turn the vibrator all the way up and push it firmly against the plug and slide a couple of fingers as deep into your pussy as he can. Continue to play with your clit, and ride the intense feelings as you feel the plug vibrate through the thin wall between your ass and the inside of your pussy. 

Once you're satiated he needs to be rewarded again use whatever method seems appropriate to you \(except for your ass, of course\). Be extravagant with your praise. Tell him how good he is to you and that you just love how well he has looked after you since he put the cage on. 

*Always make him think it was his idea to be caged. * 

What an awesome lover he is and how much you love him and how you feel so much closer to him now he takes care of you first and so well\! 

Page 13 

Hand him his cage. 

*Repeat with the other plugs until you can comfortably take one the size of the cock you think* *you might like to take up there. *

## **11. Continuing his feminisation. **

As soon as you feel that your man is no longer even really thinking about wearing women's knickers, except when you're grabbing his ass and exclaiming how hot he looks, you can add some 'stay up' stockings and a butt plug \(for him\) into the mix. 

After he has finished in the shower, and has shaven his genital area all clean, hand him a really brief thong and a pair of 'stay up' stockings. Don't make any fuss about it simply say 

"Can you wear these for me as well please, baby?" 

He will obviously protest. You should reply something like "You have really sexy legs and they will look even hotter in a pair of stockings\!" 

He'll want to know why you want him in 'this shit'. Just say "Because you've been so good to me, I've been considering raising the kink level so you can start to have some of your fantasies fulfilled\! But I don't think I can do it. I'm too nervous. So I thought we could play some role play sex games where we 'switch roles'. I want you to pretend to be a 'woman' so I can see if I can make love to you like that and get more comfortable with these games we've been playing together. If it goes well I'd like to see about finding a female lover for us both to play with. Please help me?" 

*How can he refuse? * 

Help him put the stockings on because he'll try to put them on like a pair of socks \(he won't roll them up first\) so you'll have to show him. As soon as they are both on burst out laughing and say "They look ridiculous with your hairy legs\! Come into the shower and I'll shave your legs for you." Start to walk towards the shower as if it's a given he will follow you. 

He'll raise the usual protests "what if the guys at work, or my mates, see it?" Point out that he works in an office \(if he does\) and wears long trousers all day so who is going to see? If he works in shorts point out that manscaping is a really big thing now and you thought it would be a thrill if he 'gave it a go' because you think he will look hot\! And say that after he's done it, he can tell everyone at work that you fucked him senseless all afternoon and night \(because you're going to\) and they will all consider doing it too\! 

If he continues to object fold your arms under your breasts and give a really disappointed sigh 

"Why do you keep resisting me when every time we do something together like this our sex life gets better and I learn to love you a little more?" Take his hand again and insist he follows you to the shower. 

Page 14 

Shave his legs smooth. Keep exclaiming how sexy his legs feel and look now they're getting smoother. Once you've finished lean back and say something like "Fuck you have sexy legs I can't wait to see you in the stockings\!" At this point ask if he wants you to just go ahead and shave the rest of him because "in for a penny, in for a pound, right?" 

*Hopefully he will acquiesce, but it doesn't matter if he doesn't, because you'll get him there* *eventually. * 

Take him back to the bedroom insist on rubbing some moisturiser into his legs and tease him mercilessly. Stroke his dick, play with his balls, finger his ass and constantly croon about how fucking sexy his legs are and how you can't keep your hands off them. Rub some into his stomach, chest and back if he's let you shave him all over. 

*The object is to bring him as close as you can to orgasm but not let him over the edge. This is* *called edging and it's something you need him to be able to do for long period of times, as* *you'll see, in the following passages. * 

Help him back into the stockings. On the pretence of 'helping him' stroke his now smooth legs and keep telling him how much his 'sexy legs' are turning you on. Let him feel your pussy so he can feel your arousal. Hand him the thong that you've chosen for him \(the thong needs to be big enough to cover his bulge\). 

You'll want him in his cock cage, and given you've just spent 30 minutes winding him up, he's going to be as hard as algebra so tell him you're just so horny you have to come now and you want him to come on your tits as you finger yourself to orgasm like, right now\! 

*This is a time to fake it again if you can't quite get there. What you want is him coming as* *soon as possible and to be soft enough to fit back into his cage. *

## **12. More feminisation. **

Once he has finished and has you clean again tell him you want him to look as much like a girl as possible so you can pretend that you're going to be making out with another woman and the cage will help smooth the bump \(it will, but only because it won't let him get hard\) and get him to put it back on. 

Have him climb up on the bed and lie on his back, get him to raise his hands above his head and hold onto the headboard, if you've got one, or the back of the mattress if you don't. 

Instruct him that if he lets go and touches you the session is over. Tell him he is to close his eyes and keep them closed. 

*This is, once again, getting him used to obeying you, and only wanting to satisfy you not just* *getting himself off. And helps move him towards taking the more subservient role you have in* *mind for him. * 

Page 15 

Now make love to him like you would like to have someone make love to you. Kiss the nape of his neck, blow gently into his ear, and nibble on his lobes, kiss him gently then passionately, softly lick the corner of his mouth, trail kisses down the centre of his chest and slowly circle into his nipples. Tease and nip and gently pull them with your teeth. Swirl your tongue around them and softly suck on them. 

*Around now you will need to remind him he must stay still, keep his eyes closed, and not to* *touch you no matter what\! * 

The next thing is to start to talk to him like he was a woman. Tell him how sexy 'she' is. How you love her tiny tits and rock hard nipples. Kiss slowly down his stomach stroking and gently tweaking his nipples as you go. Trail kisses down to his thong then kiss where a woman's pussy would be. Use your tongue to lap at the area as if you were licking a pussy through her knickers. 

*Make sure you are using the feminine pronouns whilst talking to him in these situations as* *you want him to get to the point where he knows his role is to service cocks, not use his*. 

Tell 'her' you can feel how hard her clit is and how wet she is and how you can feel the heat of her arousal. 

Move him a little more towards the centre of the bed so you can get into a 69 position. 

*Remind him again he must keep his hands off you but can lower them if they're getting* *uncomfortable. * 

Lower your pussy onto his mouth and ask 'her' to eat you out. 

*Explain to him he needs to pretend he's a woman and be gentler with his administrations, like* *a woman would be. * 

Sit on his face so he can't see what you're doing and reach into your night stand and bring out the massage oil and the smallest of your butt plugs. Lean forward into a classic 69 position and slide the thong strap out of his crack and apply a generous amount of oil to his ass and gently start to rub it into his rosebud. Start with your finger, as usual, and slip it into his ass. 

Mouth his cage through the thong and tell him you're giving her a little bit of finger while you're eating her 'pussy'. Slowly stretch his entrance until you can fit a second finger into him. Slowly insert the butt plug. He'll probably clench down and resist. Tell him to relax and enjoy as there's nothing like having your clit licked whilst there is a vibrator inside your pussy. Once you have the plug fully inserted, hopefully deep enough to be resting against his prostate, grab your vibrator and apply it to the base of the plug. This will send extremely pleasurable sensations across his prostate and colon, through the thin wall that separates his prostate from the base of his penis, and into his dick. 

Page 16 

*There's a pretty good chance, if you've done it right, he'll come, even though he is still soft in* *his cage. This is the start of training him to the point that the only way he can come is with a* *cock, preferably the cock of one of your bulls, in his ass and rubbing across his prostate. * 

Make him pleasure you until you are satiated. Let him take off his cage and remove the butt plug then reward him for being a 'really good boy' by letting him have vaginal sex with you. It won't take him long to come, properly, this time. Make sure he uses his tongue to clean you up. 

*Remember that you're going to make him clean your cum filled pussy after your bull has had* *you so get him used to it now. * 

Once you're clean, cuddle up with him and raise that fact that even though he tried really hard and you tried your best to imagine him as a woman it didn't really work as he is just too masculine dressed only in panties and stockings and wonder, out loud, if he would be prepared to go a few steps further to 'pretty' himself up so it would be more convincing? If he doesn't immediately say "yes" drop the subject. Make sure he is back in his cock cage and let him sleep. 

About here you need to assess where your man is up to in his conversion from 'Alpha male' to 

'subservient cocksucker'. You have him, at this point, exactly where you want him to be when your bull arrives. Basically naked, with nothing on but a tiny thong, is completely shaved down from head to toe, and is in a cock cage\! 

So let's look at some possibilities 

He's raised little to no objections to this point. This would mean he's actually quite submissive and you can start to accelerate his transition. 

He has willingly, or even better yet, enthusiastically gone along with all of the 'games' so far then you have a natural submissive and it will be quite easy to convert him to into a 

'cocksucking submissive' as he, pretty much, already lives only to please you. 

If your man is in the first category you can mix and match some of the below to get him more quickly to part 25 where he meets Abby. In this scenario \(what you do is slightly different to the suggested actions below\) you should ask him to dress in his thong, etc. before 'she' 

arrives but raise no objection if he doesn't want to. 

If he is in the second category you can skip down to part \(25l\) where Abby comes over the second time. 

Remember we're not trying to create a transgirl here \(not sure if that's even possible\). We're trying to create a cross, or more accurately, fetish dresser \(n. One who dresses in the undergarments normally associated with the opposite sex to them for the purposes of sexual gratification\). 

Page 17 

There is a third category, of course, in which he resists you every step of the way. This means you're going to have to 'break him' into the role. The following instructs you how to go about breaking him down. It mainly involves stripping away his male persona and force feminising him completely so he will later be appreciative of the fact you've 'allowed' him to return to some semblance of masculinity. 

## **13. More and more feminisation. **

The next morning fuss over him and tell him how sexy he looks in his stockings and thong with his shaved legs. Rub your hands up and down his legs cooing over how smooth and wonderful they feel and look. Cup his cage as if you were cupping a woman's vagina and finger the entrance to his ass. Emphasise how womanly he looks from the waist down and how you wish he had a pussy so you could go down on it because you think you would be able to do it this morning as you're so horny. 

*Kneel down and mouth his cage to show you think you could. * 

Make him pleasure you with his hands and tongue. Explain to him the reason you have your eyes closed is because you're imagining that he is a woman servicing your pussy. Come hard and loud, even if you have to fake it. Get him into a 'scissor' position where your pussy is grinding against where his 'pussy' would be. 

*Remember you're actually grinding against his cock cage and his balls are in a fairly* *vulnerable position inside the cage so you need to be careful\! Crushed balls is not a* *pleasurable feeling\! You will want to push hard enough so that it causes him at least a little bit* *of discomfit occasionally, but not too much pain, just to remind him who's in charge\! * 

Tell him you need to come again and start fingering yourself as you're scissoring with him. 

Have an orgasm \(pretend if you need to\). 

Gasp to him that you had a sudden vision that he really was a woman and that he was fucking you with a large strapon and it popped you over the edge hard. Say "Fuck that vision was so fucking hot\!" Bite your lip and look nervous. Start to say something and stop, blush if you can. Start again and stop then say, really softly, "I think it would be so hot if you bought a strapon, slightly bigger than your beautiful cock, dressed in your knickers, stockings and your cage, and then fucked me with it. I think I'd come so hard I'd have to give you a really good reward after. Would you do that for me? It might help me decide if I really can let a woman do that to me when she is making make love to me." Smile and say "Wouldn't that be a great show for you?" Look down and away as if embarrassed to be asking. 

*Silence is once again your best friend. Never beg and never berate him if he won't do it. Just* *use the withdrawal of affection and reward system we've discussed earlier in this post. * 

Page 18 

Give him time, if he hasn't bought one after a week, ask if he had thought anymore about getting a strapon as you really wanted to try it with him. That it makes your pussy throb every time you think about it, which is all the time. You need to make sure that you give him no relief during this time. Even if Saturday comes around, and he's all freshly shaved down there, tell him to put his cage back on and say that he may have a wank by himself before putting it back on if he wishes. Don't allow him access to the net though. Make him come up with his own fantasy to get off. If he does manage to come get him to tell you what he was fantasising about. 

*Hopefully it won't have been about your sister. * 

There'll be a good chance it will be about you with another woman and him joining in. Tell him it's a possibility but that he needs to help you get over your fears first. And that having him shave off all hair below his eyebrows and dress like a woman then make love to you like he was one would certainly help ease some of your fears. 

**14. Teaching him his cock is not needed. ** 

He will eventually buy the strapon and give it to you. Make sure you bring the fantasy to life as soon as possible after he has given the strapon to you. Get into the shower with him when it's time to for him to shave himself down and do it yourself. Use all of your skills to get him as excited as he can be without coming. It is, of course, impossible to get the cage on if he is fully hard so here's what you do: Tell him you want to raise the kink to a new level and take him into the bedroom. Using some of your pantyhose, tie him, spreadeagled, to the bed. 

Blindfold him with one of your scarves and stuff a recently worn pair of your knickers in his mouth 

*Recently worn is best, especially if you were aroused when you were wearing them, because* *the smell will drive him wild. * 

If you've made him horny enough in the shower he won't raise even one objection. 

Go to the kitchen and get a damp cloth and a teaspoon. Wrap some ice inside the damp cloth and give it a few minutes so the cloth is really cold. Go to the bathroom and rinse your mouth with a little bit of toothpaste. By the time you get back to the bedroom he will have started to flag a little, but won't be soft. Take his cock in your hand and start to make him hard. As he reaches hardness take him in your mouth. Don't suck, just mouth him and gently breathe in an out with him in your mouth. The minty freshness of your breath will first cool and then warm his cock and bring him instantly close to orgasm. 

*Do not let him come\! * 

Page 19 

As soon as you sense he is close hold the damp cold cloth against his balls and smack the eye of his penis with the teaspoon really hard\! Unless he's a total sadist he will go soft immediately. 

*You want him horny but not hard. * 

Place the cock cage on him then proceed to make him as turned on as you possibly can again. Do the same as you did the night you first pretended he was a woman and made love to 'her'. Keep tormenting him until he is groaning in pain because his cock is throbbing against the limiting constraints of the cock cage. Ask him if he wants to come? Of course he will say yes. Then say "If you dress up as a woman again put the strapon on and gently make love to me until I'm satiated I'll take your cock cage off and let you fuck me for real, deal?" 

He will instantly agree. Untie him, take the blindfold off and your knickers out of his mouth, and then hand him the stockings, thong and strap on. As he wrestles with the stockings, hand him a camisole top to wear as well. 

*Don't say anything just indicate he should put it on, too*. 

Once he has all of the gear on help him to put the strapon on and tighten up the straps. 

Position it so it's actually resting on his cock cage not his pelvic bone as it should be. 

*You'll want this to be a little uncomfortable for him so he won't want to do it too often. The* *goal is to get him used to the idea you're going to want a bigger cock than he has in you* *before too long and that he can't satisfy this urge by getting increasingly bigger strapons. * 

Once he is all done up lie back. You're going to do as little as possible so that everything is up to him. Tell him he needs to warm you up with lots of foreplay because 'that's what a woman would do and you want to experience that'. 

*He should be stroking and kissing and licking all of your erogenous zones before he's even* *going to go close to touching your breasts or pussy. * 

Once he has completed his tour of your erogenous zones get him to gently massage and stroke and lick your breasts until he can feel your arousal. Then use his tongue on your clitoris and vulva to drive you even higher and to dip his fingers inside your pussy, gently stretching your pussy with one, then two, then 3 fingers to prepare you for the larger sized 

'cock' he's going to fuck you with. 

When you're ready to be penetrated ask him to lube the 'cock' and to gently insert it into you. 

*You'll need to lube it as there is no precum to prepare the way and your own juices probably* *won't be enough. * 

Take your time, and make him take his, until you are used to the extra girth and length. When you're ready whisper huskily into his ear "Fuck me hard now you beautiful sexy girl\!" 

Page 20 

*Make sure you push back at that 'cock' hard enough, from time to time, so that it hurts his* *balls. * 

Keep calling him by feminine pronouns. "Fuck me, darling girl. My god, you sexy bitch, you're making me so hot\! Etc." so he believes you are fantasising about him being a woman. Come hard and loudly at least once, numerous times, if you can. 

Once you're fully satisfied ask him to gently remove the strapon from your pussy and tell him to take it off. But ensure he remains in his female clothes including the thong and top. 

Release him from his cage and get him hard as quickly as you can. Guide him inside of you then ask him to fuck you hard again. As he fucks you continue to call him by female pronouns. As soon as he comes, come too. 

*Time to pretend if you have to. * 

Drag him over so he's lying on his back and snuggle in as close as you can to him. Play gently with his cock. Stroke his stockinged legs and slide your hand inside his camisole and stroke his chest. Lavish praise on him. Tell him how good he was, how hard you came, how much you love him and how much you appreciate what he did for you. Call him your sex god and the best lover you've ever had. 

*It's called 'stroking his ego so he'll want to do you like this again. * 

Don't even make him clean you up or put on his cock cage. Tell him you want to fall asleep with his come running out of you to remind you how good a fuck he is. 

## **15. Further feminisation. **

In the morning he is going to be hard again and will want to fuck you because he will think things are returning to normal. Don't let him\! Tell him you are too sore from last night \(doesn't matter if you are or not\) Send him off to get a warm wet facecloth. Wash yourself under the covers Say "because you don't want him to see he's hurt you by fucking you that hard and well," if he asks. 

Then tell him you want him to come on your breasts. 

Don't help him at all other than to let him straddle your torso as he wanks himself off. Once he has come, gather a little bit on your finger and make a real show of swallowing it. Then make him use his tongue to clean you off. 

Make him clean his cock and groin area with the same washcloth you used and put his cage back on. 

Page 21 

Tell him you feel like some Maccas for breakfast but don't let him take his female clothing off. 

Just allow him to put something on over the top so the fact he is wearing women's clothing is hidden and send him to get some. 

When he returns with breakfast emphasise to him that you expect him to stay clean shaven from the eyebrows down now and that, except when he was wearing shorts where he could leave the stockings off, he was to wear the stockings, knickers and a camisole top all the time as it makes you so horny to think of him as your 'secret girl'. 

*Explain to him that if he did this he will get rewarded for making you happy. * 

Over the next few days you need to keep him in a constant state of arousal. As soon as he gets home make him strip off his male clothes and put them in the wash. Explain to him that you find him so sexy dressed 'enfemme' you want him to be like that all the time you're alone together. Give him time to get used to the idea that at home he is to openly be 'your girl' and when he is out of the home it makes you really horny thinking about how he is now 'your secret girl'. 

**16. Teaching him to appreciate others paying attention to you. ** 

If he works in an office or in retail turn up at his work with the cage key, have him sneak you into the staff cubicles, undo your top and tell him you want him to come on your tits but only if he is still dressed enfemme. Make him show you he is. If he's stripped them off don't make a big fuss about it just let him know you're really disappointed and immediately leave. Give him the usual cold shoulder treatment until he promises to wear the clothes as you want. 

If he's still wearing the items take off his cage and kneel down so he can shoot on your breasts. Guide his head down to clean you off but leave some and say you're going to leave your top undone enough so that people will notice his come on you as you leave his office and when you are walking around. Put his cage back on before you leave. If people you don't know notice give them a really big smile and lick your lips. 

If he works in construction, or elsewhere outside, turn up at his work dressed as sexily as you can manage. Short skirt, tight see through top, black bra, make up just perfect and enough buttons undone so you're just about to pop out the top of your outfit. Swing your hips and toss your hair, smile and wave at all the boys, then march straight up to one. 

*Even if you've seen your husband pretend you haven't* 

Ask for your husband by name. Ask "Who's the boss?" And then ask that person \(the boss\) if your husband can take you to lunch. Smile wickedly and promise you won't keep him long. Of course your man will say that he can't get away so pout and lean in and ask quietly if he's still wearing his knickers and camisole top. Make him show you, but not obviously, probably when Page 22 

he walks you back to the car. Same as above, if he isn't wearing them just walk away. If he is tell him you're going to give him a reward when he gets home. 

As you walk back to the car make sure you swing your hips and make eye contact with as many men as you can and flirt with your eyes and smile. If you catch them staring at your breasts or ass, smile and wet your lips with your tongue. 

*This is the start of getting him used to, and appreciative of, other men paying you attention. * 

When he gets home, if he has been a good boy, make sure you reward him by letting him come somewhere on you. 

*If he bitches about you turning up at work dressed like a slut look really hurt and say "I just* *wanted to do something nice for you and to show all your workmates you have a hot wife who* *really cares for you. Why wouldn't you want that?" If he fusses more say "Fine\! I won't bother* *anymore, now do you want to come and have sex or do you just want to piss me off so I won't* *let you?" * 

Tell him that he can tell the boys what a hot fuck you are, if he wants, and that he can describe some of the things you have gotten up to. Tell him you think it would be hot to know some of his workmates and/or friends were lusting after her. Make him tell you which ones have said you were hot and remember their names. 

**17. Moving him more towards being your sissy is next. ** 

Start to buy him some girlie outfits. Dresses, skirts, blouses, sexy nighties even matching bra and knicker sets. Make them as slutty as you can possibly find. Really short skirts a size or two too small so he will have to squeeze into them when he begins to wear them and his ass will hang out of the bottom. Tops that barely cover anything and will barely do up across his chest. Dresses that have a mile of cleavage and will leave the cheeks of his ass exposed. 

Don't say anything just place them in his wardrobe. If he asks just shrug and say something like "Dunno, they looked sexy and I thought you might like them." Refuse to answer any more questions about them. 

Start to expand on the amount of time you spend arousing and teasing him. Try to keep him right on the edge of coming for as long and as often as you can but make the times you allow him to service you then get some relief more and more sporadic. Other than insisting he wears his stockings, knickers and camisole all the time don't ask for anything more. 

He will start to wonder if he's done something wrong. Tell him "no" but then pretend as if you're going to say something hesitate and stop. Look away... "No, nothing". 

Page 23 

He'll know something really is bothering you and ask you to tell him. 

Reply "I can't help but think of the night you made love to me, dressed in your stockings and thong, with the strapon and I get so horny\! I really want you to dress up in one of the outfits I chose for you and fuck me again but I get scared to ask you in case you don't want to. That you think I'm weird. Then I want to cry because I think maybe you don't want to please me anymore." Well tears a little if you can. 

*Keep in mind here that boys are not good at taking hints so you may have to spell it out for* *him. * 

If he doesn't offer ask him "Will you let me choose you an outfit, put the strapon on and fuck me again?" If he does offer, or when he has agreed, uncage him and send him off to make himself totally clean shaven \(if he isn't already\). Emphasise that he must stay soft because you want him in his cage so the unsightly bulge isn't evident and ruining the fantasy the he is a woman, but he's not allowed to have a wank to do so. 

Smile wickedly and say "I can repeat the ice and spoon treatment if you need me to?" 

Once he has returned with his cage on have him dress in the knickers from a matching lingerie set that you have chosen and put the stockings on. Hand him the slutty skirt you have bought for him and help him into it. Make sure you play with his ass and cage whilst you are doing it. Exclaim over how sexy his ass looks in the skirt. Cup the cheeks of his ass where they hang below the bottom of the skirt and tell him how horny he looks. Tell him how feminine his ass looks in the skirt and how much you like it. Kneel down and ask him to bend over then kiss and nibble on his ass cheeks. Wet your finger and rim his ass. Then slap his ass and tell him to hurry up and finish getting dressed. Hand him the matching bra as if it's a given he will put it on. Just say "It goes with the outfit I've chosen for you" 

*He probably won't be flexible enough to do the straps up behind his back so show him how to* *do it up at the front and slide it around to the back before putting his arms in the straps. * 

As soon as he has the outfit on slip your hand inside one of the cups and go "Fuck that looks so hot\!" and play with his nipples for a bit. Hand him the blouse you have chosen and only do the buttons up to where his cleavage would be if was female. Compliment how he looks. 

Tease him by saying what a sexy girl he makes and how you're sure all the boys would love to fuck 'her'. Help him put the strapon on making sure the base is positioned on his cage again. 

Strip off and climb onto the bed. Spread your legs and touch your pussy. Say "Make love to me, my sexy girlfriend\!" If he goes in too hard, he's male so he probably will, remind him that he's pretending to be your female lover and that he needs to make love to you properly and not just fuck. Make him take his time. Use oral queues to guide what he is doing. Moan and tell him when he has got it right, guide with your hands when he isn't quite there. 

Page 24 

*Never criticise or complain though, just guide. His ego can be easily bruised in the beginning* *when he's like this and, if it is, he won't want to do it again. * 

Have him play and tease you until you are ready for the 'cock' then moan "Fuck me with your girlie cock, lover\!" Make sure you use female pronouns as he slips it in you. Close your eyes and imagine whatever you need to to give yourself the biggest orgasm you've had yet \(pretend if you have to\). 

Once you are completely satisfied push him off and take the strapon and cock cage off him, hand him the strapon and tell him to clean it off using his mouth and tongue. Say "Pretend it's my clit you're cleaning. Baby\!" And tell him "Besides, all good girls clean their lover's cock off after being fucked\!" and laugh. 

Once it's clean put the strapon on yourself. Position it so it is on your clit \(if you didn't already know this\) show it lewdly to him and ask him if he likes you having a girlie 'cock' and whether he thinks it's sexy? Push him onto his back and have him hold the headboard or top of the mattress and close his eyes again. Admonish him that he needs to hold still and keep his eyes closed or you're going to stop. 

Tell him you're going to pretend that he is your 'new girlfriend' and that you're going to make love to him as if he was a girl. Give him a female name you have chosen for him and call him by that name for the rest of the session. 

*This is part of training him to be 'Becky Cockslut' \(as an example but don't use the 'Cockslut' *

*part until he's pretty much already there\) when he is dressed enfemme. A submissive cock* *sucking little whore that lives only to please her Mistress and her Mistress' bulls. * 

Once again make love to him like you wish someone would make love to you. Tease and play with all of his erogenous zones except his cock *. * 

*Girls don't have one of those so why would you? * 

Slowly centre onto his taint and ass. Use plenty of saliva and get the whole area as slippery as you can make it. Rim his ass with your finger then slip it inside. Change to your middle finger and start to slowly stretch his hole. Hook your finger up towards his balls, you should hit his prostate if your finger is long enough. 

*You'll know when you have because he'll groan and both he and his cock will jump. * 

*Don't let him come\! * 

Reach into your dresser and grab some lube and grease up the strapon. Push his legs back and apart and position yourself between them with the strapon aimed as his rosebud. Keep fingering him in this position until he gets used to having you between his legs. Then swap your finger for the strapon. 

Page 25 

His eyes will fly open as he feels it pushing at his entrance. Cover his eyes with your hand and say "Shhh my darling girl. You made me feel so good fucking me I'm going to return the favour\!" You'll need to be slow and gentle so his ass gets used to the intruder. Once you get it almost all the way in grab the 'cock' part by the base and angle it upwards so it's scrapes across his prostate as you pull slowly back. 

*He'll grunt and jump again when it hits*. 

Do this a couple of times but slowly so he doesn't actually come. 

*Remember, it's no longer your job to make him come, it's his\! * 

Let him lower his arms and place them on your hips. Say to him "Pretend you're my female lover, baby\! Tell me how much you love having my 'cock' in your pussy. Push back at me like I do when you're fucking me." 

Keep encouraging him to talk to you like he is a woman and to thrust his hips like a woman does. Tell him you want to hear him grunt and moan and to beg you to fuck him some more. 

To encourage him, grab his balls just under the shaft with your forefinger and thumb making a circle. Gently stretch his balls away from the shaft of his cock so that you can virtually close the circle of your thumb and forefinger. Hold him cupped in your hand so his balls remain stretched a kittle away from the shaft then stroke his cock until he's hard again \(if he isn't already\). 

*Be careful not to let him come. * 

As you slowly push into him release the pull on his balls and, as you pull back, gently pull downward on his balls. This will pull on the skin just below the tip where his 'helmet' pulls up and is his most sensitive part. Encourage him to move his hips so he is fucking himself on the 

'cock'. As he lifts his hips gently pull downward on his balls. 

Once he has established a rhythm stop moving and make him do all the work himself. He'll have to lift his hips to get the pull on that most exquisite spot and push down to get the stretch happening again. Be very vocal whilst he is doing this. Tell me how much of a fucking whore he is and how much you love it. Call him your dildo loving lesbian lover. Tell him he's your dirty slut and that you want him to come for you now. 

*It's called trained orgasm where he will learn to only come on your command and immediately* *when you command. And is a good start on him learning to love coming on a cock that's in his* *ass scraping on his prostate. * 

As he shoots, come yourself as if you found him doing that a total turn on \(pretend, blah, blah\) and congratulate him effusively. Tell him what a good little girl he is and how fucking hot watching him do this is. 

Page 26 

Once he has come make sure he uses his mouth to clean any splashes off you if there are any. Scrape some of his come up onto your finger and make a big show of tasting, licking, then sucking your finger clean. Scrape some more up and offer it to him. Tell him to suck your fingers clean as it'll be so sexy for you. Send him off to clean himself and the dildo up. Tell him to hurry back because you need to come on his magnificent cock \(this being his reward for being a 'good boy'\). 

*Do so, as soon as he's back. Hand him his cage once he's cleaned you and himself up. *

## **18. Punishment and reward. **

Have him fuck you like that a few times then, after he is doing it willingly, make him get dressed like that to earn his weekly 'reward' of servicing you and being allowed to come on you. 

*Once he becomes accustomed to having to do that, tell him if he gets himself all girlie* *dressed once he gets home you'll probably want to fuck him more often as you love the* *thought of him being your lesbian lover. * 

He will try and demand you get a real lesbian in as promised. Just look at him really tearfully and say "Don't you want to be my lesbian lover? Why would I need more than you?" 

*Yes, it's called emotional blackmail\! * 

Every time he does come home and get into his female clothes make sure you reward him. 

You'll need to get him more used to ass play so start fingering him and massaging his prostate every time he masturbates for you. After he has come always scrape up a little bit of his come and make a show of swallowing it and feed some to him. Make him continue to clean the rest up with his mouth and tongue. 

*Remember, he must always take care of your needs first\! * 

Once he is starting to change almost every time he gets home remove all of his male clothes, except for his work ones, of course. If he says anything shrug and say "You hardly wear them anymore now that you're mostly my girlie lover and lesbian partner and it makes more room for the slutty outfits I love buying and dressing you in." and smile lasciviously. "Now hurry up and get changed\! I left an outfit on the bed I want you to put on and fuck me in\!" And smack his ass. 

*You need to buy him a pair of 4in heels*. *On average his woman's shoe size will be about 3 *

*sizes bigger than his men's size. Don't make the mistake of getting the 7in heels, because he* *won't be able to walk in them. * 

Page 27 

Leave the heels sitting with the outfit you have chosen. Have a note on them saying "Put these on too, sexy girl" with a big smiley face. If he hasn't put them on when he comes out go and get them, kneel before him, and encourage him to put them on. Use compliments and touch to get him to put them on. If he refuses, pout and say "I guess you don't want to fuck me tonight. It was going to be so good, too\!" Then get up and walk away. When he protests turn to him and say simply "You always fight me even though you know it's going to feel good, and then you do what I want and it does feel good, so why don't we skip the first part and go straight to the 'do what I want and feel good part' this time? Put the damned shoes on and come and fuck me\!" And head for the bedroom. 

*You should be already wearing the strapon. * 

Strip naked, place the pillows so you can lean back in a semi reposed position. Spread your legs and play with the 'cock' part of the strapon. When he comes in, if he has the heels on, stroke the 'cock', pat the bed and say "Come here, lover girl, Mama has something nice for you" and smile. When he gets up on the bed say to him "I want to role swap tonight, baby. 

You be the woman and I'll be the man. Fuck I'm so hot just thinking about it\! I had to masturbate twice today imagining you doing this for me\!" Stroke on the cock and press the base against your clit and let out a heavy moan. "Come suck Mama's 'cock', baby girl" And guide his head down onto your 'cock'. 

*I know I referred to you 'role swapping to the male role' and now you're using 'Mama' but* *these things take time\! * 

If he resists keep moaning and thrusting your hips "Please, baby? I'm so fucking hot for you\!" 

If he refuses allow yourself to snap at him and tell him his boy's clothes are in the spare room closet, he can go get changed and sleep in there if he's not prepared to please you. 

*You must take this risk if you want an obedient cock slave for all of the time and not just when* *he is horny. He has to learn that his role is nothing more than to make you happy. * 

*I told you it leads to complications\! * 

Once you have him willing to suck your 'cock' make plenty of noise as he is doing it *Men are very auditory as well as visual. * 

Tell him you're loving it. Call him a good little cock sucker and that he is your little come whore. Tell him to do to the 'cock' exactly what he loves you doing to him. Encourage him to be as realistic as possible in the way he is sucking that 'cock' because it makes you so fucking hot\! Get him to slip his finger into your 'ass'. 

*Really your pussy because your ass will be exclusively for your bulls, remember? * 

Like you do to him and make him give you an orgasm. 

Page 28 

Once you have come, push him off you, and as butchly as you can say "On your back, baby girl, Mama needs to fuck you now\!" 

Make him lie back, remove the cage, and make love to him as before. Undo his blouse, but leave it on, caress his nipples under the bra, cup his cock and balls and finger his ass, tell him you're imagining you're dipping your finger into his cunt 

*I know most women don't like this word but, in this context, men do. * 

Work some lube onto your fingers and into his ass. Make sure he is well stretched and insert the 'cock' into his ass. Be gentle until he starts to push back at you. 

*He should have learnt to love having things in his ass by now. * 

Then fuck him as hard as you can. Keep telling him how tight his 'pussy' is and what a slut he is and how much you love fucking his tight hole. Fuck him to an orgasm and come with him \(pretend blah blah\). 

*Make sure you reward him again, if he's up to it, and give him his cage. * 

*Never let him go without his cage, except in the cases described. Keeping his cage on him is* *the key to you being able to keep him both horny and frustrated. It also guarantees he won't* *go and try to find some slut to fuck to prove to himself he's still a real man and bring some* *lovely disease back for you to experience. You'll know if he has found someone to screw* *because he won't want to play anymore and will want out of his Becky role. * 

Once he is done snuggle up with him and stroke his chest, stomach and squeeze his ass. Tell him you love having him like this, all pretty and girlie. Drop in, casually, that you need to get him a wig and maybe do his make up next time to complete the fantasy. Don't make a big fuss of it no matter what he says. If he protests just kiss him and say "You know you're going to do it because you love me, and love to please me, and it will make me happy" But don't say anything more about it unless he says he's willing or wants to. 

## **19. Keeping him on track. **

There's a chance, about now, he'll start to wonder if you've gone lesbian on him so make sure you reassure him and tell him how much you love his cock. How much you love having him make love to you and feeling his jism shoot all over you. Tell him \(often, as well as right now\) how great a lover he is and that you adore experimenting sexually with him and pushing both of your boundaries. Explain that you're only trying to get comfortable being with a woman because you know it's something he wants you to do but you're still terrified at the thought of going down on a pussy and aren't sure if you could let a woman go down on you. 

Page 29 

He may also wonder at why you've suddenly become so interested in having lots of sex all of a sudden. A sudden increase in sex drive is an obvious symptom that your partner may be playing around behind your back. Explain that now he looks after you so well it's made you realise how much you love having sex with him and that you want to keep exploring with him because it's so much fun. 

## **20. Further feminisation. **

Encourage him to put the heels on with the rest of his outfit every time he comes home and changes. After he's gotten used to the idea of wearing them tell him you now expect him to wear them all the time he's dressed and that you'd like him to always get changed into Becky \(or whatever name you've given him\) as soon as he gets home every day. 

*You'll no longer reward him for getting changed as this is now what is expected of him instead* *you will give him the silence and cold shoulder treatment when he doesn't do as expected. * 

Start calling him by his female name around the home. If he doesn't answer scold him "Becky\! 

Aren't you listening to me?" He'll protest that his name is Brian \(or whatever\) not Becky. 

Simply point out that not dressed like that he's not, that he is 'Becky Cockslut' your lesbian lover and life partner and how much you love him and how much you love him being like that. 

Point out that your sex life has never been better, has it? And that you've never been closer. 

But he can end it if he wants? All he has to do is take off the clothes and go back to being Brian but that you don't think you'll want to be with him anymore if he does because he obviously doesn't want to please you. But why would he want to? He's getting more sex than ever. You're having more fun together than ever before and it's only the two of you that know so you don't understand what the problem is? 

*Complications, right? * 

*If he takes the clothes off and dresses back in his male clothing, and you really want an* *obedient sissyboi as your partner, you need to make him move into the spare room and* *remain strong. Tear up when he comes home and doesn't get changed. Refuse to greet him* *unless he has changed. Cry when he tries to talk to you and tell him it feels like he's ripped* *your heart out because he's withdrawn his love from you. It's only a small simple thing and it* *makes you so happy when he does it so why won't he do it? Remind him how often you used* *to fuck together when he was dressed up and wouldn't he like to do that some more? *

**21. If he stays the next step is to get him more accustomed to taking the female role. ** 

Choose a Saturday and send your hubby off on an errand that gets him out of the house for a time. Previous to this day you will have bought yourself a male's business suit. Underneath Page 30 

the suit you'll want to put on your sexiest lingerie. A bustier tightened to the point of difficulty in breathing so your boobs are almost popping out of the top. A stocking and garter set and the tiniest of thong. Wear the highest heels you can. 

*A small note here. It doesn't matter if you're thin, medium, average, voluptuous or huge. Guys* *will find you attractive and want to fuck you anyway\! Nothing is as hot as a woman, especially* *a curvy woman \(thin ones are gorgeously sexy as well\) in a tight bustier with garters and* *stockings and a tiny thong\! Except, maybe, one in a full corset\! * 

*Make sure you are totally shaved down there. * 

Do your makeup as over the top as you can \(think drag queen not model style\) with 'whore red' lipstick as its crowning glory. Pull your hair up into top knot, if you can \(think: I Dream of Genie\). Have it pulled or brushed severely away from your face if you can't. Put the strapon on over your knickers and under your suit. Wear nothing but your lingerie, the strapon and your man's suit. The suit should be buttoned under your breasts and positioned in such a way that it exposes all of your cleavage. 

When your man comes home tell him to hurry and change because you've got a surprise for him. 

You will have laid out the sluttiest outfit you can put together for him along with those 7in heels you're going to want him to be able to wear. Tell him to leave the top and bra off and to come out and see you once he has the stockings, knickers heels and skirt on. 

When he comes out take the cage off. Stroke him until he is fully hard. 

*So he's distracted from what you're about to do* 

Then take your blush brush and about a fingers width from the centre of his chest, where his pecs circle, paint a thin to medium line, straight down to the bottom of his pecs and draw a small distance, in a curve towards his nipples around the bottom of his pec \(where your boobs would be\). Repeat on the other side. 

While you're doing this make sure he's leering at your cleavage. Tell him how much you like him looking, that it makes your pussy wet and does he think the boys at his work would like it? 

Which ones? 

Take him by the hand and lead him to the bedroom and tell him to put his bra on, turn him to the mirror, have him bend over facing it, and show him how painting the lines, along with the shadow cast by the light, makes it almost look like he has boobs. Stand behind him and slip your hands inside his bra and play with his nipples, tweak and pull on them insistently until it's obvious they're a little sore. Say to him "Look, baby, I'm playing with your tits\!" 

Page 31 

*Note: You have breasts and a pussy and an ass and make sure these are the terms he uses* *for them. He has tits, a boy clit or sissy cock and a cumhole or man cunt. * 

Reach around and grab his cock, apply a little lube to your hand and stroke him until he is close to coming then let go and stand back. Tell him to sit on your stool, or a chair you've placed there, in front of the mirror and see if he will let you apply some makeup. Don't make a fuss if he refuses but, either way, when you've finished at the mirror, unzip the fly of your trousers and take your 'cock' out. Rub it on his lips and ask him to "give it a wee suck, baby, please?" If he's allowed you to put some makeup on him make sure you smear his lipstick a little so that he looks really slutty. Make plenty of noise as he sucks it as if he really was sucking your cock. Tell him how good he is getting and encourage him to try and deep throat it. 

*Don't force the issue though*. 

After a few minutes push his head back, clean the lippy off your 'cock', if there is any, and put it back in your trousers. Tell him to hurry up and finish getting dressed as you'll be waiting for him in the lounge. Say that you want his cock hard as a steel bar, bulging out of his knickers and pushing his short skirt up when he comes out so he can play with it if he likes. 

Go and sit on the lounge with your hips placed on the edge of the seat and lean back. Place some cushions for comfort, you're going to be there for a while, so you'll want to be comfortable. Unzip and take your cock out and make sure it is well oiled. 

When he comes back into the lounge exclaim how fucking hot his cock looks bulging out of his knickers and jutting out from under his skirt like that. Compliment him on how big it looks. 

*It doesn't matter whether he's small, average, big or huge in the cock department you'll still* *fuss over how 'big' he is when you refer to his cock. It's called feeding his ego. * 

Grab your 'cock', point it at him and say "Come here, baby girl, Mama has what you need\!" 

When he gets close take him in your mouth and deep throat him, be careful not to let him come. Finger his ass and ensure it is well lubricated. 

*As you've been using the strapon regularly, or, making him use a butt plug he shouldn't need* *much in the way of stretching anymore. * 

Have him turn so his back is toward you and back up around your closed knees and thighs. 

Lean back, make yourself comfortable, grab the 'cock' and point it towards his ass. Tell him to 

"Lower his cumhole onto your cock. You need some of that sweet man cunt of his\!" 

Guide him down until he is fully impaled on your 'cock'. Lean forward so you can grab his boy clit with your oiled hand and start to stroke it. Grip it just under the head quite firmly and instruct him to "Ride my cock and fuck my hand\!" 

Page 32 

Have him raise and lower his ass on the strapon and let his cock slide back and forth in your gripping hand. Keep making him shift his position slightly until you feel the strapon hit his prostate. 

*You remember how to tell when it has, right? * 

Grip his boy clit a little firmer and tell him "Fuck me harder, Becky, my little cock whore\!" Make him keep going until it's obvious he's going to come. Then push him off. Have him get up on the couch on his hands and knees and spread his boy cunt for you. 

*This is one of the very few times you are going to actually fuck him, but it's part of training him* *to like being fucked in the ass and to come when someone is doing it. * 

Slide the strapon into his ass, don't be gentle this time. Imitate how one of your bulls is going to enter you. Have him shift his position until the 'cock' hits his prostate again. Slowly fuck him with the strapon sliding across his prostate. 

Now it's time to change your pronouns. As you feel his excitement rise start to sex talk to him. 

Something like this: "Oh my darling Becky Cockslut Daddy is fucking your sweet ass\! Do you like Daddy's cock in your cumhole? Push back at me you fucking slut, Daddy needs to come in your sweet fuck hole and make you my little cumwhore\!" 

Encourage him to tell you how much he likes it 

"I love it when you talk all girlie and slutty to me, baby. Talk dirty to me my little Becky Cockslut. Fuck I'm going to come so hard\! Tell me how much you love it you, fucking slut\!" 

Keep referring to yourself in the male pronouns and him in female ones and fuck him to an orgasm. Come yourself as he does \(Fake it blah blah\). As soon as he has come slip the 'cock' 

out of his ass and pretend to collapse to the floor. Tell him how fucking hot that was, how hard you came and how good he was. Tell him it looks like he shot a gallon of come out and that he's such a stud\! 

*There's some chance he will be feeling a little guilty about pretending he was letting a guy* *fuck him and was able to come so you will need to reassure him he's still actually your super* *stud man and that he is your absolute sex God\! If he starts to worry you're turning him into a* *pooftah he's going to be very difficult to keep training. * 

*You are, kind of, but he doesn't need to know that\! * 

Before he has too much chance to think about things drop your man suit and the strapon to the floor take his hand and say "Come to the bedroom, baby. I need you inside me right now\!" 

On the way make sure he knows you've dressed like you have just for him because he is your lover and you love dressing sexy for him, just as you love him dressing sexy for you. 

Page 33 

If he has allowed you to put makeup on him show him, in the mirror, how wrecked it now is and tell him how goddamned sexy it looks and how much you loved making him look that slutty by fucking his ass\! 

Lie back on the bed, spread your legs and instruct him to go down on you as he strokes himself to hardness again. Encourage him to be quick because you need to feel him fucking you again. Make sure he gives you a proper orgasm this time, if you didn't actually get one from the pressure of the base of the strapon rhythmically pushing against your clit. 

*If you can't come like that consider getting one of the strapons that also have a part that slips* *into your pussy so it fucks you as you fuck him*. 

Make sure he comes in you as hard as you can make him come. 

Once you're satiated remind him he needs to clean you up then send him to pick up your suit and the strapon and to place the suit on hangers in your closet and to wash and dry the strapon and put it in your dresser. Tell him to hurry up because you need to sleep in his arms. 

Cuddle up to him when he comes back then casually say "There's a small shopping bag inside your wardrobe with a surprise inside for you. Sleeping in these things" indicate what he has on "Must be uncomfortable. Take them off and put on what you find in the bag." 

Inside the bag there will be a baby doll nightie just the right size for him so it's comfortable for him to sleep in. Say "Put it on for me, honey, and come cuddle. We'll be girlfriend sleepover lovers together." And give him your best smile. 

As he goes to put it on smile and say "Don't forget your cock cage" and pretend to doze. 

*Ensure he is wearing the cage when he comes back and has put the nightie on. Insist, if you* *have to. * 

Once he's up on the bed look him in the eye with a serious expression on your face. "You know how much I love you having this on, don't you, babe \(cup the cage\)? You look after me so well when you're wearing it and you make love to me so deliciously as 'Becky' that I want you to wear it always. Plus it makes you so horny that you come so hard for me when we make love and I really like that\! I know you used to masturbate sometimes when you didn't have the cage, and this stops that, so you're much keener to look after me so I'll make you come. But if you want to take it off I will let you, okay? Do you want to take it off or do you want us to continue like we are? I hope you want to continue, my love, because I have so many more things I want to do with and to you and have you do to me." 

If he immediately wants to take the cage off just sigh and look disappointed but don't say anything\! Give him the key. Don't let him even try to initiate intimate contact until he is back in his cage. 

Page 34 

*You must take this risk because he has to surrender his will to you and it will help bring him to* *the realisation that his only role, in life, is to please you and that wearing the cage and* *dressing as 'Becky' pleases you. *

**22. Teaching him to love ass play. ** 

A big part of this will be bringing him to the realisation the only time he is going to get to come is when you or, eventually someone, is fucking or fingering his 'man cunt'. That he is only going to be allowed to have penetrative sex with you \(have his cock in your mouth or pussy\) on very special occasions when he has proven what a good boy he is. 

You start him on this path by giving him a whole heap of 'ruined orgasms' in a row interspersed with some magnificent ones when you're stimulating his prostate with the strapon or butt plugs or are fingering him. 

*A ruined orgasm means his flow is interrupted just before he starts to come but is at that point* *of no return. Right at that moment he is about to start shooting you do something to* *completely distract him from the fact he is coming*. 

The easiest way to achieve this is to simply 'accidentally' bang him in his balls, hard, just as he is about to blow. Apologise most profusely but continue to make sure he can't achieve a fulfilling orgasm unless you're in his ass. 

There's plenty of ways to achieve a 'ruined orgasm' for him. Cry out in pain suddenly and lurch forward just as he's about to come and head butt his chin \(tell him your back spasmed suddenly, or something\). Pretend to get a sudden cramp and push him off you just at that critical time. Another way is to grab his balls as if you're going to help him get there and pull or squeeze too hard so that it's really painful. 

The goal is to train his body's reactions to come to expect a 'ruined orgasm' unless his prostate is being stimulated. If you make sure he has regular mind blowingly intense orgasms every time you finger and/or use toys to penetrate his ass, and ruined ones every time you're not, it shouldn't take long before he is wanting, or even begging, for you to play with his ass when he needs to come. 

Of course you don't want to have to do this for him, except as reward for him being an exceptionally good boy, so you'll need to buy him a good prostate massager and present it to him. 

## **23. Prostate orgasms. **

### Page 35 

The first time he uses it you'll want to make it a special occasion for him. When it's time for him to receive one of his rewards of being allowed to come somewhere on you and he is kneeling above you with his thighs either side of your thighs. Sit up, tell him to close his eyes and hold still. Get the probe, and put some lube on his ass and on the probe. 

*A prostate massager is usually quite thin, reasonably flexible and a little hooked so he won't* *need any stretching to be able to accommodate it*. 

Cup his balls, turn on the vibrating feature and slip the probe into his ass searching for his prostate. Once you've found it rub the probe across it until he is just about ready to come. 

Take it out and ask him to lie on his back, hand him the probe and instruct him to find his prostate and massage it with the probe as he wanks himself. Tell him that you're going to lie on your side with your head on his stomach, but away from his cock, and he is to try and shoot his load into your waiting mouth 

*This will probably be the very last time you will ever let him come on your face as he is sure to* *miss your mouth. Coming on your face will be reserved solely for your bulls. * 

Be very vocal about how hot it looks and how much it's turning you on, play with your pussy as he does it, and say how you can't wait to swallow his come. It won't take him long to blow, trust me. Once he has shot his load immediately make him lick his come off your face. 

*The reason you've done this is to start to get him used to licking your bull's come off your face* *as well as out of your pussy and ass. * 

Then go down on him and make him hard again. Get him as hard and as hot as you can then say "Hold there I'm going to grab my vibrator." 

Lie on the pillow beside him, and say "Let's come together while we use our vibrators. Fuck that's going to be so hot\! But you have to wait for me, okay?" 

He is still probably going to come fairly quickly as having your prostate vibrated is a very intense feeling. Whatever you do don't make any issue at all if he comes before you\! Simply ask him to help you get off by kissing and fondling your breasts and kissing you passionately and talking dirty to you. Encourage him to call you Mistress and/or his Queen, groan loudly when he does. When you come, be loud\! 

*Men love this\! * 

Tell him you want him to use the massager every time he is coming for you now as you love how hard he comes when he does and you hate how it's always a disappointment when he's not having his prostate massaged. Don't insist, just look disappointed when he doesn't use it and refuse to join in. But keep ensuring his orgasms without it are ruined. Be delighted, enthusiastic and vocal when he does use the massager. He'll soon get the hint. 

Page 36 

**24. Making 'Becky' meet others. ** 

By now you should have trained him to accept being made up when he's pretending to be your lesbian lover and fucking you and you should be teaching him how to apply the makeup himself. You will have bought him a nice blonde wig. 

*Always blonde for his first wig as we all know blondes are the sluttiest. * 

But may not yet be insisting he wears it yet. Once he's totally enfemme, all made and wigged up, every time you 'fuck together as lesbians' you need to slowly introduce him to the thought of allowing someone else to see 'Becky'. You'll need to convince him that he is very sexy and you'd love to see if others thought he was too. 

Open an account on one of the free 'dating sites' like AMM or Bioz under both of your names. 

*Probably Bioz as this site allows even basic members one free message a day. * 

Label it as 'lesbian couple looking for playmates' and post some pics of you both together with him as Becky. 

*Take the pics on his phone so he knows he can delete them at any time if he wants to. * 

*If he objects to posting a face pic onto a site where someone you both know might see it* *explain to him "If anyone we know is using these sites they're also doing the same type of* *things we are so we can out them as easily as they can out us so why would they? And if it's* *a guy we know doing this behind his wife's back he will know we can easily drop him right in it* *with his wife, so nobody, I repeat nobody will ever say I damned thing\! And, besides, if a guy* *you know does say something about seeing you on Bioz ask him 'So what were you doing on* *a 'gay website'?" * 

Login to this site regularly so he can see how much attention you both are getting and encourage him to read the messages you receive with you. 

*They will be almost exclusively, if not totally exclusively, from male wannabe dreamers who* *will never follow through but the attention is nice, isn't it? * 

*Note: If you've decided to use Bioz there are an awful lot of 'tranny chasers' on this site that* *are going to want to see explicit pics and/or to hook up with your man. If your hubby makes* *any kind of mention that maybe it would be 'kind of hot' to send someone some pics then* *100% encourage him as he's already considering, or even fantasising about, 'playing' with* *another cock. * 

*If he \(fingers crossed\) hints that he might like to meet one of the guys from the site get him to* *invite the guy over as soon as possible\! * 

Page 37 

Look at how many 'profile views' you are both getting daily. He'll say it's all you but insist it's mostly him\! Say you're going to prove him wrong and open two other separate accounts, one for each of you, with the exact same details: Female, lesbian, married and looking for playmates: male, female and trans. Have a pic of each of you alone on these profiles, you as yourself, and him as Becky. 

*This is what to do to ensure his view count is higher than yours. Check your and his stats* *every day and, if yours are getting ahead of his, there's a delete and/or block function on* *these sites. Pare yours back, if you have to, so it's a lot less than his. Once his are* *significantly ahead of yours show him and tell him "See? I told you it was all you\!" * 

What you're looking for on these sites, ideally, is a couple in the same relationship you're trying to create for yourself. A dominant woman with a crossdressing or sissy submissive husband and is willing to help you with your hubby conversion project. 

*Pfft\! Good luck with that search\! Oh, they're there but they're going to either want to play too* *quickly for your uses, or, the female partner will want the two men going at it way faster than* *your man is going to allow. And, you're in the lesbian sex scenario you're trying to avoid* *\(assuming you are wanting to avoid it?\). * 

So settle for a reasonably attractive, sexy and experienced preop transgirl or crossdresser to approach. 

*I'll call her 'Abby' for convenience sake. * 

Get chatting to him/her and confirm 'she' will play with you and your 'girl' together. 

*This is no time for someone who is 'bicurious' or just learning. You need 'her' to be* *experienced in this kind of play so she's 'good to go' the first night\! * 

*You're extremely unlikely to find one that is 'passable' as it's the virtually impossible ideal. * 

*Note: An awful lot of crossdressers still identify as 'straight' and won't want anything to do with* *a male cock. Another lot more are 'transbian' and only want to have sex with women and/or* *other crossdressers/transgirls. You're looking for one of the latter. * 

*Another note: If you are female, and you're prepared to date and have sex with crossdressing* *males and transgirls, and especially if you want to be the dominant partner, you will have a* *queue of 'girls' a 1000 miles long to choose from\! * 

See if 'she' would like to come over for a chat. Emphasise it will only be chat the first time. If you're fairly sure she's the right one send her for an STI test and email you the results once they're through. 

*For obvious reasons. * 

Page 38 

Preferably you want one who wants to 'get dressed up' at your place after he has got there. 

*Do this from your account without your trainee sissyboi's knowledge. * 

Once you're sure you've found someone that will actually turn up show him/her to your trainee and make him admit that he thinks 'she' is quite sexy... for a guy'. And say you've invited 'her' 

over for a chat so he can see that being a 'secret girl' is actually quite common. Reassure him that he can wear his 'boy's clothes' for the meet, if he would prefer, and that you're going to take his cock cage off for the night. 

If he's in the first category this is where you join back in. But you're being a lot more insistent he's got his stockings, thong, bra and camisole on \(underneath his boy's clothes, is fine, also\). 

Make sure he knows that 'she' is going to dress herself 'enfemme' after she gets here and that it is definitely only for a chat and absolutely nothing else\! 

When Abby arrives sit her down for a chat and get her to talk about 'dressing as a girl' and how good it makes her feel and how horny it makes her. 

Once you are all comfortable send Abby off to your bedroom to get changed. 

Tell your man "See? Lots of people do it\! And I can already see you're a much sexier 'girl' 

than she is\!" 

When Abby comes out you'll need to reassure her she looks very feminine and sexy. Have her do a pirouette and tell her that her ass is hot and that her legs are divine\! Turn to your trainee and say "I think you are much prettier than 'she' is when you're all dolled up." But leave it at that. 

You'll need to loosen your man's inhibitions up so feed him liberal amounts of alcohol. Subtly touch and stroke him so he gets really turned on. Surreptitiously play with his nipples and squeeze his ass. Casually brush your hand across his bulge and try to make him as hard as a rock. 

When Abby takes a toilet break whisper to him "Fuck I wish she was a real girl and you were totally dolled up as Becky so we could all play lesbian together\! I'm so horny right now\!" Take his hand and brush it across your nipples so he can feel you're turned on. 

*Ice them just before you do this if you're not actually horny*. 

Keep teasing and tormenting your man so he becomes desperately horny. Once you know he's loosened up, and he is a horny as you can make him, ask him if he would like to go and put on one of his bra and knicker sets as well as his stockings and heels and camisole \(or just take his boy clothes off, if that's the case\) and come out for you? 

*Assuming he hasn't already \(as described above\). * 

Page 39 

Tell him he can wear one of his dresses as well if he's embarrassed to be only in lingerie. Tell him you just want to compare the 2 of them. Do not make even the slightest of complaints if he refuses, just look disappointed. 

When your man goes to get changed \(hopefully\) or when he goes to the loo \(if he hasn't wanted to change\) let him catch you squeezing the Abby's ass when he returns. Release it immediately and look embarrassed. Apologise profusely "I'm sorry, baby, it's just that I love the look of a man's sexy ass in a pair of knickers so much, and yours wasn't here for me to squeeze." And give him a really big smile. 

*Why? You're definitely pushing on some of his boundaries here and if he explodes at this* *point you're likely to be no chance of forcing him into the role of 'sissy' so you need to pack* *this project up and save your marriage right now\! * 

*Apologise to Abby and get her out of the house as soon as possible. * 

*Grab your man and apologise to him profusely. Use tears and the likes of "I'm so sorry, baby. *

*I just wanted you to have some fun" to placate him. Get your man into bed and fucking you as *

*'Brian' just as quickly as you can get his clothes off. If he won't make love to you you're really* *going to have to work on massaging his ego and getting him to desire you again if you want to* *keep your marriage alive. * 

*Over the next few days lavish attention on him so he knows that you know you've 'fucked up' *

*but leave his cock cage in an obvious place on his dresser and/or next to his side of the bed. * 

If he puts it away or throws it out, it's done. Enjoy your marriage and hope that some of the lessons he has learnt about how to warm you up and please you hold. If he continues to wear the knickers you purchased for him you're still in with a chance and if he puts the cage on himself, without any hint from you, it's still game on. You just pushed him too far too soon and you can circle back to this after a few more weeks of arousal and denial, interspersed with some fantastic orgasms, until you think he's ready for you to push him again. 

**25. You're going to have 2 scenarios here. ** 

Let's look at scenario one: He does go and get changed. 

If he didn't you can skim over most of what is happening below and go down to 26. 

When he comes out and catches you feeling your guest's ass and you've apologised to him. 

Walk over and kiss him as passionately as you can, he's uncaged, so try to get him as hard as you can make him so that his dick is bulging out his dress, if he's put one on, or jutting out of his knickers, if he hasn't. 

Page 40 

If he freaks about you obviously groping him in front of another 'man' I'm afraid your chances of turning him into your sissy are virtually none. Tell Abby to go home, take your man to bed, fuck him well and drop the whole thing. 

This is why I've emphasized so strongly to this point that you must keep him caged and in a constant state of both arousal and desperate to come. It's so when you get to these key points they only thing he's really thinking about is his need to fuck, come and ease the pressure on his balls\! 

Ask your Abby if she thinks your 'girl' is sexy? 

Instruct Abby that she must stay where she is sitting because this meeting is only for a chat. 

Tell your man how goddamned sexy he is in his girlie clothes. Casually grope his cock and say, loudly enough for everyone to hear, "Fuck I'm horny right now\!" and kiss your man again. 

Tell him to walk a little way away from you and do the same pirouette as Abby did and tell him his ass is definitely sexier than 'hers' but maybe Abby's legs are a little better than his. Ask Abby to stand next to, but a little away, from your man. 

*It's way too early. If 'that man' touches him, or gets too close now, he's probably going to* *freak out\! * 

Have them both do a slow turn around so you can compare. Casually give both of their asses a squeeze and say "Fuck you're both so very sexy\! But I love my man best\!" 

Send them both to the bedroom to get changed but hold Abby back and whisper to her to try to casually brush your husband's cock with the back of her hand as they both strip down. Tell her that if he objects just apologise and explain that it was an accident and get out of there quickly. If he doesn't give it a bit of a stroke and tug but leave it at that and get out of the room. 

*You're pushing him again to test if he's going to let you to continue to take him down this path. *

*If he freaks out at Abby's touch, you've got a long way to go. If he lets 'her' have a bit of a feel* *and a tug the below will go much quicker and easier, so let's hope he lets her grope him\! * 

Send Abby home and then fuck your man's brains out. Make him service you with his hands and tongue first. Keep exclaiming how horny you are and how badly you need to come. 

Describe how the whole time 'she' was there you kept having visions that Abby was a real girl and that he was going to turn himself into 'Becky Cockslut' that, actually, he was going to be 

'Becky Cuntslut' for the night. 

*I know, there's that word again but, trust me, he'll love how dirty it sounds in your mouth* And that they were all going to fuck each other. Tell him to talk to you as if he was Becky as he makes love to you. Once you are satiated let him slip inside your pussy and play with his Page 41 

ass until he comes, hard. See if you can get him up and have him go again. Don't act even a little disappointed if he can't. Once he is totally spent tell him that you once again want to feel his come leaking out of you as you sleep but you'd like him to put on the cock cage and his baby doll nightie and cuddle up to your back. 

Tell him you want him to wear his cage because you "Know he is a naughty boy and will be hard in the morning and try to slip it in you\! But you want to give him a special treat tomorrow so he needs to be patient." 

**25a. The 'dream' **. 

In the morning get your pantyhose out again and tie his hands and feet to the bed. Remove his cock cage and make him as hard as he can be. Use one of your scarves to blindfold him and stuff last night's knickers into his mouth. Lie beside him then stroke and touch him all over in random places, especially his nipples, but always go back to his cock. Oil it up and keep it well lubed so that you can give it an oily rub every few seconds. 

*Do not let him come*\! 

Start to tell him about the 'dream' you had last night and how fucking hot it has made you this morning. Describe in lurid detail how you dreamed that the two of you and the 'girl' from last night, except she wasn't really the same girl because she was so gorgeous, that if she didn't have a cock, you wouldn't have any idea she wasn't a 'real girl'. 

*Describe her in lurid detail. Long blonde hair, full luscious lips, and a long neck, high firm* *boobs that had to be at least a full C cup and that they were so gorgeous you really wanted to* *feel and kiss them. Long shapely legs that any woman would die for and all men would drool* *over along with a firm round butt. * 

Explain how the three of you were sitting on the couch talking, you in the middle, and you had gotten so horny from looking at her breasts and seeing his cock jutting out that you just had to pull this \(fondle his cock\) out of his knickers and start playing with it. And, what was best was, that the girl didn't seem to mind at all\! That she just started to play with herself through her dress as she watched you stroke your man's cock. 

Tell him how you dreamt that, as he wasn't protesting, you leant over and took his cock in your mouth and all he did was lean back and groan. So you then proceeded to suck and deep throat his cock and that it felt so naughty and sexy to be doing that in front of someone as beautiful as our new friend. 

Straddle his thigh so that he can feel how hot you are. 

*Make sure you are\! Go to the toilet and play with yourself and fantasise first if you need to. *

*Imagine you have the first of your bulls in there with you, perhaps. * 

Page 42 

Start to dry hump his thigh as you describe the 'scene' to him. Tell him you lifted your head up so you could adjust your position and saw that the girl had taken her cock out of her knickers, and that it gave you a sharp throb in your pussy to suddenly remember that this gorgeous creature had a 'girlie dick' just like yours, just not so big. 

Describe how she had lifted her dress up so she could play with the head of her dick and tell him that seeing her like that made you so horny you got on your knees, grabbed these \(cup your man's balls\) and, in one swift action, took all of him down your throat. Describe how, in your fantasy, you dreamt you had lifted your skirt up and pulled down your knickers so you could play with your clitoris and finger your pussy as you sucked him. 

*You'll need to be very careful here because you want to keep him on the edge and not over it* *into an orgasm. You're trying to give him the proverbial 'blue balls' until you are ready for him* *to come. * 

Tell him that as you were deep throating his cock you became aware that the girl had gotten on her knees right beside you and was watching avidly as you blew your man. That having that beautiful creature right there made you even hotter. Explain that she now had her cock right in the palm of her hand and she was furiously pulling on it. And fuck was that hot\! And describe how her head kept getting closer and closer to the action and that her pulling got harder and faster as it did. 

Say that you in your dream your jaw had started to ache so you pulled his cock out of your mouth and offered it to her and she immediately swallowed virtually all of it. 

*Ignore any protests he might be trying to make but increase the strength of the grip you have* *on his oily cock and stroke it a bit faster so he remembers he's horny and forgets everything* *else. * 

And then she rocked her whole body back so his cock slid slowly back out of her mouth. 

Describe how your mouth went dry and you almost came seeing her deep throat his beautiful girl dick. Tell him how she then swirled her tongue around the head before letting it slide back down her throat. Say you remember being amazed at her oral skills as she alternated between deep throating him and swirling her tongue around the head and you \(give him a nudge in his ribs\) didn't even seem to notice that someone else was now sucking his cock but, in your dream, you just didn't care because it looked so fucking hot all you could do was think about his mouth on your pussy and how badly you needed to come. Explain how, during all of this he just continued to squeeze his eyes shut and groan as he concentrated on not coming because it felt so good and didn't want it to end. 

*You should now be moaning loudly as if you're about to 'pop' and pinching his nipples as well* *as occasionally giving his cock a nice oily stroke. Make sure he can hear how aroused you* *are. * 

Tell him that, in your dream, because she was giving him such an awesome blow job, and that he was enjoying it so obviously, you felt free to sit up on the couch beside him and lift Page 43 

your skirt up, pull your knickers down and play with your clit, finger your pussy and masturbate as the sexy scene played out in front of you. But when you leant over and kissed him his eyes flew open and he looked at you, looked down to see who was blowing him, and then all he did was groan and grab her head with both hands and say "Fuck that feels so good\!" And started to hump up into her mouth. 

Say that, in your dream you remember being so angry that he didn't even care that someone other than you was blowing him that you wanted to punish him so you peeled your knickers off, stood up on the couch with your legs either side of him, pulled up your skirt, and sat down heavily right on his face. That you grabbed him by his hair \(or back of his neck if blah blah \) pushed your pussy as hard into his face as you could and hissed "Eat my pussy you fucking whore\!" 

And you ground your pussy into his face. Hissing "Lick my clit and lap my pussy\! Make me come you slut\!" 

And he did\! Say that in your dream that as you came on his face, you heard him groan and shoot his load into the girl's eagerly sucking mouth. Then the dream ended and that now, remembering the dream, you are so fucking hot, you're going to need him to do what he had done in your dream to you for real. 

Then immediately rise up, pull the gag out of his mouth and sit on his face. Hold the back of his head and hump his face, Grind your pussy as hard as you can onto his face and rub your clit across his nose. Hiss at him like you did in your 'dream' "Eat my pussy you fucking whore\! 

Lick my clit and lap my pussy. Make me come, you dirty slut\!" 

Ride his face to as many orgasms as you can. 

*Try to actually smother him occasionally with your thighs and pussy, not for real, but for a few* *moments. * 

Once you are totally satiated push your knickers back into his mouth. Smack his balls and insist if he tries to resist. Then put your strapon on, loosen up his leg restraints so you can lift his legs up and get access to his man cunt and roughly fuck him until he comes from the 

'cock' scraping across his prostate. Scrape up as much of his come on your fingers as you can, take your knickers out of his mouth, and feed it to him. Tell him how hot it makes you watching eat come. 

*Not 'his come' but just come. * 

Then play with him until he is hard again and ride him until you both come again. 

You need to come at the same time as him, or, very soon after. So if you're not going to be able to you'll need to pretend again. 

Page 44 

*It remains vital, at this stage, that he still feels like he's is your fuck star, your sex god, and* *that no one else could possibly be as good as him. * 

Once you have both come, release him from the restraints, remind him he needs to clean you up and put the cage back on. Don't let him clean himself up, tell him it looks so slutty on him and that you love it\! Cuddle up with him and take a hold of his cage and say "Fuck that was so good\! I think we should get 'Abby' \(the 'girl' from last night\) back and make her sit on the couch, dressed all pretty, and actually do what I dreamt about, what do you think?" Explain that you know he won't really want 'her' to blow him, because, you know? She's actually a guy, but it would still be really hot to blow him in front of her and to sit on his face as he eats your pussy while Abby watches and maybe they could let Abby play with herself as you did? 

Would he be in it? 

Keep bringing it up until he agrees to have her come back over and 'see what happens'. Use the "You know you're eventually going to let me do this because you know it will make me happy and you love making me happy" approach along with big smiles and kisses and strokes of his cock. 

**25b. Bringing the 'dream' to reality. **

During this time you'll need to stay in contact with Abby and keep her up to date with what is happening. Tell her you're hoping to get her over again soon and that it will be for some limited play this time. Instruct her to always refer to you as Mistress and/or her Queen when she addresses you as you want your sissyboi to get used to calling you that too. Tell Abby that when she comes over next she is to go straight to the bedroom and get changed into the sexiest outfit she has. Choose her one from your husband's collection, or buy her one yourself, if she doesn't have one and lay it out for her. 

Say that, once she has fully changed, she is then to sit on the stool at your dresser because you're going to do her make up for her this time. 

*Assuming she isn't already proficient at it. If she is proficient tell her to make herself up as* *prettily as she can then come out. * 

Because, this time, you want her to be as feminine as possible. 

Once another visit has been made make sure your man knows he's to be already dressed as Becky, this time, when Abby arrives and that you expect him to go 'all out', heels, stockings, garter, knickers, the shortest of short skirts, bra, a skimpy top, wig and full make up because your dream was sucking off 'Becky' not 'Brian' in front of Abby. Remind him that he doesn't need the cage because you're going to be blowing him, probably, if it feels right. 

Page 45 

You should don your 'man's suit' outfit along with all of the same gear as before \(except for the strapon, it will be too much for him at this stage if he sees you with it on\) and do yourself up as well as you can. 

*Get lessons yourself if you have to. Most cosmetics counters at department stores have* *women who will teach you everything you need to know as long as they think you're going to* *buy something\! * 

When Abby arrives greet her warmly and send her straight to the bedroom to get changed. If you need to do her makeup tell her to call you when she is dressed and follow her in, tell your man to wait. 

Make her up as sexily as you can possibly make her. 

*You're hoping your man will forget she is a he at some stage during the night and let her blow* *him. * 

Lead Abby back into the lounge \(or when she returns to the lounge if her makeup skills are proficient. Proficient, not adequate.\) kiss her cheek and introduce your man "You've kind of met Becky before but Abby this is Becky, Becky Abby" and tell them both to kiss cheeks, not shake hands, because that's what girls do \(nothing more than that and air kisses are fine at this stage\). Have them sit separately on the couch and/or a seat. Hand them either a glass of wine, or something else girlie to drink. Tell them you expect them both to be perfect ladies and to sip their drinks slowly \(but you will want to keep your man's drink well topped up so you can loosen is morals and libido up\) and to keep their knees together and to have good manners. Promise them that they will both get a really big sloppy kiss from you if they can manage to, squeeze Becky's thigh and laugh as if it was a joke. 

Chat about this and that as you regularly feed your man and her alcohol, and let them both relax. 

Admonish them every time they let themselves 'man spread' \(they will, they are men after all\) and remind them they have a kiss coming each, if, they're 'good girls' and laugh again. Keep making jesting comments about how sexy they both look and how much fun it is to have two 

'girlfriends' to chat with and tease. Well not tease her, indicate Abby, but you know what I mean, baby\! 

You need to start to turn your man on so either sit on the arm of his chair or beside him if he's on the couch and use all of your well learned skills to get him as hot as you possibly can. Get him rock hard so that his cock is obviously showing. 

*Remember: you're not trying to train a transgirl here, you're training a 'fetish dresser', a* *sissyboi. Someone who is a man most of the time but dresses as 'Becky Cockslut' to get* *himself and, more importantly, you and your bulls off\! This means you want him to remain *

*'cock centric' so most of his arousal remains in his cock and balls \(the rest of his arousal,* *hopefully, by now is centred on his ass and having his prostate stimulated\). I know I've* Page 46 

*concentrated on feminising him completely up to this stage but this is so that he becomes* *totally comfortable with being 'Becky Cockslut' and knows that that is to be his role when you* *and/or he needs sex from now on. * 

*And here is where another one of those 'complications' may arrive: He may decide that he* *likes being 'Becky' so much he wants to be 'Becky' full time and to start to transition. Up to* *you whether you accept this or not, but you're very unlikely to turn him back into Brian if he* *does. If you stop letting him be 'Becky' he'll just hide it from you and continue to do it behind* *your back. * 

Encourage him to leer at your boobs and make sure he can feel how hard your nipples are \(ice them blah blah\) so he knows you, too, are turned on. Lean forward and give Abby a really good look down your front. Ask her if she thinks you have sexy boobs and when Abby says 

"Yes, Mistress\!" 

*Of course she will because having them mounded up like that in your bustier is fucking hot\! * 

Laugh delightedly and squeeze your husband's hard on. "She thinks I have sexy boobs, babe\! 

Did you hear that? And she called me Mistress\! Fuck I like that\! I wish you would call me Mistress or your Queen more often instead of only when you're servicing me\!" Then smile and say "You like them too, don't you Becky, baby?" Smile coquettishly at him, push them up with your hands and press them into his face. "Tell me how much you love my boobies, baby." 

Smile and chuckle lewdly when he does. Touch him fondly if he adds a 'Mistress' or 'my Queen' to his statement. 

Keep trying to make him come without actually touching his cock until he is squirming and writhing, maybe even softly moaning. If he tries to touch his cock slap his hand away and tell him "that's only for me tonight". Let him play with your nipples and stroke your thigh though. 

Moan a little to encourage him. In this position he won't be able to reach your pussy \(but that's okay\). 

Abby will more than likely be hard by now too and trying to surreptitiously play with 'her' cock too. Every time you catch her doing it smile and wink without letting your man see that you have. When it becomes really obvious Abby is playing with her cock whilst watching you winding your man up, get your man's attention, and say "Look, baby\! Abby girl has a girl dick too\!" Squeeze his cock and laugh delightedly. "Do you think we should let her play with it, or nah?" And laugh again. 

*You want to keep this as light as possible as if it's all a big joke to you. But you're leading him* *gently to the place where you can initiate some sex play. * 

If he says that she can play with 'her' cock if she wants to. 

*Unlikely, he will most likely just stay silent. * 

Page 47 

Tell Abby to slide her hips to the edge of the couch \(or seat\), pull her skirt up, take her girl dick out and play with it. Emphasise that she is not allowed to come. 

*If she comes she will, more than likely, be undressed and out the door so quickly you'll think a* *whirlwind has blown through your home. * 

Make it obvious to your man that you are watching Abby stroke her cock. Grab your husband's dick and say "Fuck that is so hot\!" indicating Abby. Don't give him even the slightest chance to protest just get down on your knees and immediately go down on him. 

*Don't let him come\! Or he'll want Abby out of the house and to get out of his 'Becky' clothes* *immediately as well because he will probably feel all dirty and ashamed again. * 

If he doesn't say anything when you ask if he thinks Abby should be allowed to play with her cock keep winding him up as much as you dare before going down on him. 

In both cases indicate to Abby that she should kneel down beside you once you have his cock in your mouth. Slap her hand away from her cock and take a quick breath so you can tell her to 'just watch'. 

If your man protests about her being there just suck on him harder\! 

Make sure Abby is in a position she can easily take your man's cock in her mouth and you can easily grab her cock. Bring your man right to the edge time and time again. 

*If he gets too close squeeze his balls painfully and tell him he's not allowed to come until you* *say he can. He should be well trained in edging like this by now, as you've done it often* *enough. * 

When he starts begging you to come instruct him that he needs to say "Please, Mistress, may I come?" 

If he doesn't actually start to beg but just continues to give almost anguished groans ask 

"Would you like to come, baby girl Becky?" 

He will, of course groan "yes" \(or just groan\). Squeeze his balls hard enough to get his attention and make him obey you by saying to him "Then you need to say to me 

'Please, Mistress, may I come?'" 

Take him back into your mouth and bring him to the edge again. If he doesn't say the words, squeeze his balls again and say "Well? Do you want come or not?" He'll groan again "Then say the words\!" 

*He will, of course, say it. * 

Page 48 

When he does beg you to be allowed to come say "Eyes tightly closed, my little Becky Cockslut and just concentrate on how good this is\! You may come, my little slut, just as soon as I have your cock in my mouth." 

Grab Abby's cock with one hand and offer your husband's cock to her with the other. Quickly stroke her off as she swallows your husband's cock. 

*You want them both to come as quickly as possible*. 

As soon as your man has shot his load down her throat get up on the couch, straddle his head and sit forcefully down on his face and repeat the phrases you 'dreamed' you were saying. Squeeze your thighs quite tight around his ears so you can whisper to Abby that she should get changed and leave and that you'll see her again soon for some more fun. Make sure he makes you orgasm at least once to give Abby time to get out of the house. 

Once Abby is gone lead your man to the bedroom and make him service you until you are completely satiated. Remind him he needs to because you've been so good to him and let him have an amazing orgasm. Let him use his prostate massager and come again if he wants to but don't help him. 

If he asks who sucked him off and just smile and ask, quizzically "Whose throat do you think you came down?" 

If he says he thinks it was Abby's, or, that he doesn't know smile again and say "Does it matter? It was really good, wasn't it? Besides, I was there and I obviously really enjoyed it because I came so hard on your face\!" 

*The fact you didn't say "mine" will tell him it was probably Abby's*. 

## **25c. Separating his two roles. **

Tell him to go wash himself up and change as you want Brian back now. He will probably be confused. Sigh and say "I need my man back now. I'm feeling a little vulnerable so go and change back into your usual night wear \(if he usually sleeps naked when he's in male mode tell him you want him to put on some shorts and a t-shirt because you need him to feel masculine against you tonight\) and come and give me a cuddle." Ask him to put on his cock cage though. 

*He's never to be without this on except for the rare occasions you want him to actually have* *access to his cock. He has to eventually realise he's never going to get to come on, or in, you. *

*That only after he has done his service and cleaned up you, and your bulls, that you will allow* *him to remove his cock cage long enough for him to have a wank. * 

Page 49 

*He'll possibly resist putting it back on at this time because he won't want to feel emasculated* *at all at this point. Unless you're prepared to totally break him right here or have him leave,* *don't push the issue too much. Just fling it aside and say "Fine, don't make me happy then\!" *

*and refuse to discuss it any more. * 

He'll be a little confused now. Tell him "I need my husband back now. Becky is for fun, Brian is my man\! We've had our fun, now I want my hubby back\!" 

*This is how you start to separate his two different roles. Brian, your hubby and partner, and* *Becky Cockslut, your bull fluffing, cum swallowing sissyboi. Unless you're prepared to have* *him as your sissyboi 100% of the time? How does he go to work or visit your friends and* *family with you then? Remember, though, that he, for now and except on the occasions when* *he has been exceptionally good, can only have sex with you, or anyone, as 'Becky Cockslut' *. 

Make sure you're asleep when he gets back \(pretend blah blah\). If he tries to initiate anything and he probably will because he'll be feeling a bit 'butch' and wanting to prove to himself, and to you, that he's not some queer that likes having a guy suck him off. Just push his hands or hips away and tell him you're going to go and sleep on the couch if he won't just cuddle you and let you sleep. 

**25d. In the morning if he wants to have sex. ** 

*He probably will because he'll still feel a bit weird about whether he came in a 'guys' mouth* *and want to prove to himself, and you, he's still a 'real man' *. 

Give a heavy sigh and say "Okay, go put Becky back on again and we will, but can't I have Brian for at least one day?" 

He'll be confused because he's right there and willing to have sex. Say "No. Brian doesn't take care of me properly when we're making love. He just looks after his own needs. The only time you have ever really made love to me properly, and brought me to the best orgasms, and totally fulfilled and pleasured me is when you're in your cage and being Becky. As Brian you just want to fuck \(put as much scorn into this word as you can\) and come as quickly you can." 

He'll promise you the world to get what he wants. He'll tell you he will be just as good as Brian as he is as Becky. He'll do all the same things so you are totally satisfied. Reluctantly agree say "It just won't be the same, I know it\!" Get yourself into the mindset that, regardless of how good he is, you're not going to get turned on or come. 

*If you come during sex now you've lost the game. At the very least you're all the way back at* *stage one and your chances of getting him to go back through the stages are both Buckley's* *and none. So if you can't be sure you'll stay dry \(mostly\) and not come you'll have to flat* *refuse to have sex with him with him as Brian except in those carefully controlled situations* *we've discussed above. * 

Page 50 

Lie back on the bed and do nothing. If he kisses you be reluctant to let him slip his tongue in. 

If he tries to stroke you erogenous zones switch between shuddering because his touch was 

'too light and it was just creepy' and "Ouch, too rough\!" If he tries to tongue your ass or taint push him away and rub your hand across his chin say "Too rough\! Your face feels like sandpaper on me down there\!" Roll over impatiently so he has to start on your breasts. As he fondles your breasts don't say anything but jerk as if he's hurt you and give an occasional cry out of pain. Keep rubbing his chin and face and saying he's too rough. 

*He'll be really trying hard to turn you on like he does when he is being Becky but you must* *resist\! Imagine it's your creepiest uncle or workmate, or whomever, that's trying to do this to* *you against your will. * 

If he tries to go down on you refuse to let him. 

*Who cannot get turned on by a good tongue job? And he is very good because you trained* *him, right? * 

Tell him that he is just too rough and you're scared he'll rub your freshly shaven pussy raw if he does. 

He'll want to go and shave so he's not too rough but just spread your legs and pull him on top of you. Go "No, honey, I know you need to come, so just fuck me, please?" 

Take off his cock cage \(if he's put it on\) and let him make himself hard, it won't take long, and guide him into your pussy. Wince as he pushes in as if he's hurt you because you're not 

'properly' turned on. Try not to move at all. If you do have to move make it a motion as if you're still a little dry and it hurts. Don't help him at all. If he takes more than a few minutes to come in you start to fidget as if it's starting to hurt quite a lot because he has 'rubbed you raw' 

down there. If he wants to stop look up at him tearfully and say "No, I want to please you, so hurry up and come in me, please?" 

Now, whether he comes, or, gets off you, immediately burst into tears. Tell him that it just wasn't the same\! That you could tell he was trying but that he's so much better when he's making love to you when he has his cage on and is being Becky. He's so much softer, more attentive of your needs and more loving when he's in his cage and wanting, really badly, to impress you. Remind him how often and easily you come for him when he's being Becky. 

Wail that "I'm scared that you just don't want to make me happy anymore and you only want to go back to thinking about your own needs and I just know you're going to leave me\!" 

*Got to love that emotional blackmail * 

Ask "You do still want to be with me, don't you? I thought you loved our little games? You always come so hard during them and seeing you enjoying yourself so much makes me so very happy because I'm only doing it for you\! I want you to always know I'm going to look after your needs." And cry. 

Page 51 

He's again going to wonder if you're going lesbian on him. Make sure you say something like 

"Fuck no\! Even after all we've done I'm still terrified of going down on a pussy, I can only pretend with you because you have the cock I love and want. But I'm going to really try for you so that you can experience it. I still doubt I could let a woman even touch my pussy let alone eat it." Remind him he is still your fuck star and sex god, when he's being Becky, and that it's only him you love. 

*Well it is, isn't it? You just want to be a slut with big cocked bulls as well . * 

Hesitate and say "You can go and put Becky on and we can try again, if you want?" But I'm really sore so it probably won't be any good either. Besides I really want my man back with me today. I'm tired of always being \(your name\) and Becky I want to be \(your name\) and Brian for at least today. Then, when I'm feeling up to it, maybe in a couple of days' time, you can dress up as Becky and fuck me senseless again?" Pout and say "You do like fucking me senseless, don't you?" 

Silence is, once again, your best friend. If he doesn't immediately say "Of course I do" screw up you face and look as if you're going to cry and say "You do want to, baby, don't you?" 

*Of course he wants to please you, he loves you, and secretly loves being your little cock* *whore, mostly because he gets so much more sex than all of his married mates seem to be* *getting. He's, more likely than not, been bragging about how much sex he's getting, to his* *workmates and to his buddies. He won't, of course, have said a damned thing about what he* *needs to do to be getting it\! Except maybe to say, ever since he's started to 'man scape' *

*regularly, you can't seem to keep your hands off him. Some of them will have started to do it* *as well and be confused as to why their wives don't seem to be reacting the same way. \(He'll* *say this to cover why he's always completely hairless across everything they can see.\)* **25e. Learning how to keep his two roles separate. ** 

He'll agree to be Brian for you when and where you need him to be and to be 'Becky' the rest of the time, after all, what other choice has he got? Hand him his cock cage, make sure he puts it on, and then take him out for the day. Do something really normal like go out for lunch and catch a movie or go for a walk. Maybe go and see some friends. Anything, so that he can see you still see him as your husband Brian and not just as Becky Cockslut. 

*He needs to learn that him being Becky is something you do together when you have sex* *together, and later on in the future, with others, but the rest of the time he's just to be himself,* *Brian. Making sure you keep him really horny through a combination of constant stimulation* *and teasing, and the denial of sex, unless he has made himself into the total Becky Cockslut* *package you have taught him to be, is the key to achieving this. Simply put, if he needs to* *come, he needs to dress himself completely up, no half measures, totally satisfy you sexually* *and then be rewarded. * 

Page 52 

You'll still want to, mostly, make him make himself come on you and then clean you up with only the occasional reward of a hand or blow job from you if he's been exceptionally good or been very good for a long time. Vaginal sex should always remain something he gets only on those very special occasions when he has taken another step down the path of becoming your true sissyboi. 

*I know that you're going to be badly needing to have some cock in pussy sex during most of* *this time, but suck it up, princess\! Suffer some short term sexual frustration for long term total* *wanton sexual expression gain\! If you need to come, because you are sexually frustrated,* *take care of yourself\! * 

*FFS do not take a lover at this stage, you'll screw everything up, especially if he finds out\! I'll* *show you when it's time to take your first lover a little later\! * 

If you absolutely have to have some 'cock in vagina' sex, do not do it with Brian\! Make him dress as Becky and only let him fuck you to orgasm after he has also fingered and tongued you to at least one other orgasm. Make sure he knows it's a reward for 'doing you so well'. But you need to keep these occasions to an absolute minimum so he will be prepared to take more steps along the path of becoming your sissyboi. 

*You should not ever give him any indication that this is your ultimate goal\! *

## **25f. Confirming the role separation. **

At some stage, while he's still being Brian, you will need to swap his wardrobes around again. 

Move 'Becky' into the spare room except for the knickers that you'll always make him wear as a reminder he's still secretly 'your Becky'. And move 'Brian' back into the main bedroom. 

If he asks why say "Becky isn't my husband, you are. She's the one that needs to be separate" and give him a big hug and kiss. 

You'll need to check that he is still wearing knickers and make him go change if he isn't. Take some into his work and make him show he still has a pair on and make him change into the pair you've brought if he isn't. You can't allow him to back slide too far\! 

## **25g. Back sliding. **

If he ever stops keeping himself totally clean shaven from the eyebrows down and/or tries to stop wearing knickers touch his stubbled face, arms, chest and chin, express disappointment he has 'let himself go' and remind him how much you like him being smooth and how sexy you find him when he's totally smooth and how turned on he makes you. 

Page 53 

Remind him that he is still, kind of, trying to keep himself somewhat 'feminine' in the hopes you're going to get comfortable with the idea of taking a female lover so you can fulfil his fantasy, as promised. 

Don't tease and torment him during this time, as you do when he's being Becky and refuse to allow him to even touch you. If he comments just say "You being Becky just makes me so horny because I so love how you look all dolled up, your legs and ass and chest are just so fucking sexy, that I can't keep my hands off you\! When you're Brian it kind of feels like it did before we started having these adventures so it's all a little bland, really." 

He will ask if you want him to go back to being Becky. Shrug and say "It's up to you, when you're ready. But I do really love the games we play together when you're being Becky\!" and give his balls a little tweak and smack his bum. 

*During this time you need to stay in contact with 'Abby' and make sure she knows you're* *going to want her over again fairly soon and that you hope the three of you will do a bit more* *together next time. * 

If he doesn't pretty much go and get changed there and then you'll have to press the issue, no more than a day or so later simply say "I'd love to have my 'girl' back again, baby. I really miss having my 'lesbian lover' to play games with. When do you think I'll see her again? Now, maybe?" 

*You may need to emotionally blackmail him again but you can't let him think he can just be *

*'Brian' all the time*. 

**25h**. **Driving home his new roles. ** 

As soon as he has completed his total Becky transformation, you must, absolutely immediately, jump him. Kiss him passionately and rub yourself against him and rub your hands all over his legs and ass and tell him how sexy they are when he's dressed and how you can already feel yourself getting wet. Cup his cage and finger his ass. Give him your biggest and brightest smile, try to glisten a 'happy' tear if you can, and give him a massive hug and a huge sloppy kiss. Take him by the hand and pull him toward your bedroom. Almost run in there dragging him along. Quickly strip off, jump up on the bed, spread your legs, and pat your pussy and say "Come on, baby girl, mama needs you to make her pussy feel good\!" 

*If you're usually hairy 'down there', and if he hasn't offered to shave you during his time as *

*'Brian', you should have left it to grow out. Hopefully the area will be stubbly. Make sure you* *really grind his face into your pussy. When he complains its hurting say "Well whose fault is* *that? You haven't exactly been looking after my needs as Brian, now have you?" A little guilt* *is good for him\! It will make him try to please you all the more\! Send him off to get the stuff he* *needs to shave you clean. Tell him to hurry because you're really fucking horny\! * 

Page 54 

Make him tongue and finger you to as many orgasms as you can stand. Then get your vibrator out and show him how to use it to give you another one. Pull him close and cuddle and kiss him. Stroke as much of his chest, back, legs, arms as you can reach. Play with his nipples. Tell him how fantastic he was and how much you missed him looking after you like that and that you "just need a little rest before you're going to make him feel really good." 

*This is going to be one of the few times you're going to 'look after him' as you wish to *

*'welcome him back to being your girl'. * 

*You do this, probably a few times, so he knows that the only way he is going to get sex is to* *be sissified. * 

Tell him to get up on his knees in front of you so you can take his cock cage back off. Suck him to full hardness and push him onto his back with a pillow under his hips. Mount him 

'cowgirl' style and guide him into your hot wet pussy. Guide his hands onto your breasts and tell him you want him to tweak and pull on your nipples quite roughly when he feels you starting to come and that you want him to unload in your pussy at the same time. Place your hands in the middle of his chest and ride him as mercilessly as you can. Slam your pussy down onto his cock, and give yourself up to total abandonment. Toss your head and be really vocal. Start to call him by all the dirty and slutty names you can think of. Call him your cock whore, your cum slut, your fuck toy. Tell him you're going to make him come into you so hard that his balls are going to shoot out his cock too. Tell him how good his girlie dick feels in your pussy. 

*The dirtier and more vocal you are the better \(remember to use the female pronouns\). * 

If he starts to groan and writhe because he's getting close to coming, glare down at him and growl "Don't you dare come until you feel me come\! Get ready to tweak my nipples." 

Let yourself come as hard and as loudly as you can. Again, be very vocal about it. Growl at him to "Fill my cunt with your seed you fucking slut\! 

*I know that word again but blah blah, he'll love it. * 

Pull and tweak my nipples\!" groan and tell him to do it "harder\!" Call him all the slutty names you have for him, and try to invent some more Becky Cockslut, your filthy cum slut, your dirty pussy eater, \(make sure you include 'cock sucker'\) etc., as he comes inside you. As soon as you have both finished coming, straddle his face and make him clean you up. Make sure you rub plenty of his, and your, juices all over his face and forehead. Don't let him get up and clean himself up after he has finished cleaning you. Lie against him and gather some of the come on your finger and feed it to him. If he tries to clean his face stop him and say "Don't, you look so sluttily sexy with my juices all over your face\! I fucking love it\!" 

Hand him his cock cage and explain that you feel since he has 'back slid' over the last few days when he was being Brian that you want him to go back to being Becky all the time. So he's to go back to wearing the stockings and camisole top under his work clothes. Tell him Page 55 

you want him to change back into the total 'Becky' package as soon as he gets home every night, as well, until you are sure he won't back slide again. 

*It's inevitable that he will try to 'back slide' into Brian the first few times you give him control* *over what he wears. Don't be surprised and don't let him get too far away from what you're* *training him to be. The key, as always, is keeping him as horny as possible and the giving and* *withdrawal of rewards depending on his behaviour. You want to teach him that he remains* *your sissyboi at all times regardless of what he's wearing. A sissyboi is always what he is and* *he knows it\! *

**25i. Distracting him from realising he's becoming effeminate. ** 

Now that he is virtually always wearing a cock cage his cock and balls will have started to atrophy. At this time it's imperative you don't let him realise he's 'package' is getting smaller. 

Instead keep telling him how much bigger he looks shaved and in the cage and how you could swear he is getting bigger. You want his shaft, especially, to shrink because you're going to use that as an excuse to get your first bull *. * 

*You need a bigger cock than his because the strapon just isn't the same as a real cock and* *his dick just isn't big enough to satisfy you properly anymore. *

**25j. Changing him from straight to bisexual. ** 

You need to start getting him used to the thought of sucking a cock and Abby's is the obvious one for him to start on. Start by dressing as sexily as you can every day. Make sure your breasts are always on display when he's with you, every outfit you have should expose a large amount of cleavage, but only cleavage, not nipples \(yet\). Go braless if you're still firm enough to, use a push up bra if you're not \(get some 'chicken fillets' to enhance them if you're small\). Lean over so he can peer down your top at your cleavage at every opportunity, especially when you're out with him. 

Let others have a peek as well. If he complains just touch him affectionately and say "What does it matter? You're the only one that's actually going to see or touch them and, besides, it turns me on" take his hand and touch it to your pussy "see?" 

You'll have to have a really short skirt on with nothing but a thong underneath to do this and you'll have to spread your legs so his hand can go up your skirt. Try to let the guy\(s\) who have been ogling see you place his hand on your pussy. 

*Sigh, I don't care if you're a 'bigger girl' there's an awful lot of us guys that like bigger girls and* *love to look at their plump thighs and ass and their swelling bosoms, so you should never* *wear a skirt that is lower than your mid-thigh when you're out with your man and wear one* Page 56 

*that shows your ass cheeks at home. Bend over in front of your man regularly when you're at* *home together and show him your ass. Allow him to feel and/or kiss it if he wants to \(haven't* *you always secretly wanted to tell him to 'kiss your ass'? \). * 

*It'll help to turn him on and you're trying to get him to the stage where he is also responsible* *for his own arousal and erections. It's not going to be your job to make him hard and horny, it* *will be his. * 

Let your skirt ride up when you're sitting so we can peer right up to where your upper thighs meet. 

*Learn to enjoy the feeling of being lusted over and even objectified. Despite what the* *feminists have tried to do over the years we're still men and victims of our lust, we're just not* *so obvious about it anymore. * 

When men look down your front, or up your skirt, try to make eye contact with them so they know you know they're ogling and give them a big smile. Move a little so your breasts jiggle \(it doesn't matter if they don't because your top will move and it will look like they have\), or cross your legs so they can catch a glimpse of your knickers. When your man peeks grin and touch your top lip with your tongue. So he knows you like him looking. Take your mounds in your hand and give them a bit of a lift up and make sure he, and everyone else who is looking, sees you doing it. 

*As I said before men are both very visual and very aural. *

**25k. Starting his cock sucking lessons. ** 

When you're wearing the strapon you should have it positioned so it is down the inside of your thigh and tied in place so it's not immediately obvious \(the hem of your dress or skirt will need to be just long enough to hide it.\) Use a quick release tie to hold it in place \(a Velcro strap works perfectly\). 

*No, not when you're out in public, silly . If you're going to wear it in public, maybe to his* *workplace when you do one of your periodical checks on him, you wear either a long skirt or a* *pair of trousers. If you do wear it to his work, at the very least, make him feel it and tell him* *you brought it along just in case he wanted a little taste and give him a big smile. * 

When you start dressing sexily at home for your man he probably won't even notice at first. 

It's because he's male and we don't, right? But if he does, \(if he doesn't ask him if he likes how you've been making a special effort for him every night?\) tell him you think it's only fair because he is always so sexy for you. 

As soon as he reappears as Becky \(or is Becky if you get home after him\) make sure you give him lots of kisses and cuddles to make him horny \(and keep him that way\). Every time he's Page 57 

sitting down make sure you straddle his thighs and push your breasts into his face at least a couple of times every 30 mins or so and pretend to ride him If he asks why you're suddenly doing this all the time say "Because you make me horny, silly\!". Hold your breasts so they squeeze together. 

*Double sigh, it doesn't matter if you're too small for your mounds to surround his face, it's the* *action that matters. * 

If you're braless encourage him to lick your nipples and make sure he knows how much you're enjoying it. 

*He really knows how to do it right, right? You taught him\! * 

If you're not ask him to lick between the curves of your globes because that's almost as nice, right? If he doesn't immediately put his hands on your ass. 

*What the fuck is the matter with him? But he may have gotten used to not doing anything to* *you unless told to*. 

Grab them and place them on your hips. And tell him to knead and squeeze them and to pull you down on him cos you love feeling his hands on you when you're horny. The times you don't have the strapon on take a hand and guide it to your pussy so he can feel you're hot and wet. 

*Make sure you are\! Fantasise and masturbate to wetness beforehand if you have to. * 

Let him finger you and revel in the feeling, be audible in your appreciation. If you do have the strapon on, undo the tie, grab it and tell him "Suck Mama's girlie cock, Becky baby\! It makes me so horny when you do it\!" Tell him 'she' is a good little cock sucker and sucks Mama's cock so well. 

*If he tries to object to being called a 'cock sucker' just say "OH FFS\! It's called role play,* *Brian\! It's making me want to fuck you. Don't you want to be fucked tonight? Now suck Mama,* *my Becky girl\!" Don't stop calling him a cock sucker and, as he gets used to it, add things like *

*'cum licker and/or swallower' as well. Say "All really good girls love cock and you love your* *Mama's cock, don't you baby girl?" make him tell you "yes". Keep him doing it by reminding* *him he's going to get fucked tonight if he pleases you. * 

Reward him in the usual way if he obeys you, punish him in the usual way if he doesn't. 

*This is all about getting him used to you and, eventually, him, and finally him on others and* *you on others, performing sex acts outside the bedroom with you in the dominant role and* *him as the 'girl'. *

Page 58 

**25l. Becoming the dominant partner** 

Pick a night to invite Abby over again. Tell Abby you want her to be in a cock cage and that she should also wear a pair of 'control briefs' so her bulge is not evident this time because you want her to take the total girl's part. 

*She'll have them for sure. * 

If she objects simply say "If you want to have any chance of serving me and maybe having sex with me, you'll do as you're told\! No cage and control briefs on and you go straight back out\!" 

*Get used to taking the dominant role\! The only time you are ever going to be in the* *submissive role with is when you're being serviced by your bulls\! And, even then, the real* *power is with you because, once they've come, what real use to you are they? Other than to* *humiliate your sissyboi? * 

Emphasise to her that your husband is still only slowly progressing in his journey so you don't know how much will happen. 

Make sure your man knows she's coming, but it's only for a few drinks and a chat again. You will need to make sure your man isn't able to have an orgasm, or has ruined ones, for at least 2 weeks before Abby gets there. 

*The simplest way, of course, is to not let him out of his cage for the 2 weeks leading up to this* *encounter. Tell him you feel he's back sliding again and until he's lifted his game back up he's* *not getting out of the cage, or near you\! Don't even let him out when it's time for him to do his* *weekly shave down. Say "No, you'll just masturbate in the shower. I know you\!" * 

If he asks why you keep inviting 'her' over just say how much you love having two 'girls' being attentive to you and that it helps with the idea that you're eventually going to make out with a real woman for him soon. 

Tell him that, before she gets there, he is to make himself up as slutty as he can because you love that. 

Send Abby into change and do her makeup as soon as she gets there. You will have made sure she has, and is wearing, breast forms to enhance the illusion of femininity. Tell her to call you as soon as she has completed her transformation. 

You want your man to be already '3 sheets to the wind' \(tipsy, heading towards drunk\), and as horny and turned on as you can possibly make him by the time Abby gets there. 

*Drunk and horny has been many a man's downfall\! * 

Page 59 

You, also, need to be dressed as sluttily as you dare knowing that your man is still going to see Abby as a man and may be bothered by you revealing too much to 'him'. 

When Abby says she has completed her transformation go to the bedroom and make her show you that she's put on her cage as expected and is wearing the control briefs and make her give you the key \(you might consider keeping it if you want a more permanent thing with 

'her'\). 

*Don't let hubby see you take the key\! * 

If she hasn't put both of them on make her immediately put them on. Tell her severely 

"Nobody here wants to see that unsightly thing. My man has the only girly cock I want to see or touch\!" 

Once you've confirmed she is dressed as she was instructed head back to the lounge and do as you did last time and keep your man in as heightened a state of arousal, without coming, that you can possibly get him. 

**25m. Distracting him from your real goal. ** 

Make sure, this time, all 3 of you are on the couch. Sit in the middle and tell hubby to come and sit beside you. You'll want him to sit on the same side as your dominant hand so you can easily play with his cock. Have Abby sit, a little away from you, on the other side. 

Just chat for a time and try to make Abby relaxed. Keep playing with hubby's cock to keep him close to coming. Hopefully he will be beginning to get quite frustrated because he's not allowed to come and needs to really badly. Stroke him a little more firmly, cuddle very close to him and kiss his neck and jawline. Get his attention so that he is looking at you, indicate Abby Say "She really is quite sexy don't you think? Especially with those 'boobs'. I bet, from this angle, if I was making out with her it would look just like two women were doing it. Look\!" 

Keep your back between him and Abby and lean over and give her a quick soft kiss on the lips. Turn back to your hubby and say "See?" 

*Indicate that Abby should move until she is right up against you and put your arm around her. * 

Turn back to your hubby and say "I want you to watch me and her make out. We're going to make out like we're two lesbians going at each other. Just like you've fantasised about. I reckon if I can do this I'll be ready to do a 'real woman'." 

*Make sure you keep hold of his cock firmly so he has no choice but to move across with you* *because you're definitely going to want him thinking about how badly he needs to come and* *nothing else\! * 

Page 60 

Start to make out with Abby. If Abby tries to touch anything but your face, head, shoulders or back \(and she's really a man so she probably will\!\) tell her firmly "No\! They're exclusively for my man." 

You want to be sure your man hears you say that so say it loudly and firmly. But keep kissing her and stroking her hair and arms. Start to play with her 'tits' as if she really was a woman and they were real. 

Now cross your fingers and hope he doesn't lose it. If you've got him horny enough that he's pretty much only thinking about his need to come he should go along with the fantasy and will actually enjoy the show. If he freaks out and heads to the bedroom to strip 'Becky' off and wants Abby out of the house immediately you're screwed. And there's a good chance your marriage is over. Complications, remember? ** **

Keep playing with his dick as you make out with Abby. 

*I know it's going to be a bit like rubbing your stomach and patting your head, but you're a* *smart girl, you'll figure it out. * 

Still holding onto his cock, straddle Abby. Once you're settled onto her and he's kneeling beside you with his cock still in your hand, really go to town with Abby. Make as passionate love to her as you do to your husband when he's being Becky. Make sure you use female pronouns and tell 'her' that she is beautiful and her lips are so soft and her breasts feel so hot against yours, and you can feel her hard nipples in your hands and the heat rising from her pussy. 

*You're trying to make Brian \(yes Brian\) convinced that you are right into the fantasy that* *you're making out with a real woman so he doesn't make a sudden appearance and lose his* *shit\! Ruining everything, including your marriage\! The reason you've insisted Abby is in a* *cage and control brief is because you definitely don't want her cock to appear on the scene* *suddenly reminding 'Brian' she is a he and what's more he is making out with his wife\! * 

Continue to tell her off she tries to touch your breasts or pussy, threaten to stop and send her home if she continues. Pause long enough to let go of your husband's dick, grab him by the back of his neck and pull him down into a passionate kiss, repeat the kiss every few moments. Groan with excitement every time you kiss him and tell him how fucking hot this is making you\! Move less toward him and move him more towards you, every time, so that he gets closer and closer to where you and Abby are kissing. 

*Do not try to make him kiss her\! But if he does start to kiss you as you kiss her encourage him* *to go further by pulling his head closer and swap between kissing Abby and him by groaning* *and saying how fucking hot it is\! Say "Kiss her, baby, that'd be so hot\!" \(If he does this is* *going to be a whole lot easier than we thought \). * 

Page 61 

You need to be rubbing yourself against her legs by now. Groan and say to your man "Look, baby, I'm humping her legs\! Fuck it feels good\! She's so soft\! Why have I waited so long to do this?" 

Kiss him passionately again. By now his head will be very close to where you and Abby are kissing. 

*Now that you have let go of his cock you will really need to work on those audible cues so* *make plenty of moaning and groaning noises as you three are making out. * 

Keep swapping between kissing Abby and him, but make sure you're now mostly kissing him while Abby kisses your cheek, and neck and in that really nice place where your neck meets your shoulder and along your collar bone. Make sure he can hear how good it feels. Keep grinding on Abby's thighs and groaning as you do it. 

**25n. Coming in a 'man's' mouth. ** 

Here comes the key part because you want your man to let Abby suck his cock. 

Say this to him "Bring your cock up here, baby. I want to suck on you\!" 

*He'll probably have to stand on the couch to do it. As he positions himself so that you can* *suck him make sure Abby is easily able to kiss your lips so position yourself and her so she* *can. * 

Take his cock in your mouth and bob up and down. Let it fall out of your mouth and rub against the opposite cheek to Abby and kiss Abby before taking it back in your mouth. Make sure he sees you're alternating between sucking his cock and kissing your 'lesbian lover'. Be loud about how much you're getting into it. Tell him to balance himself by sitting on couch's back and leaning back against the wall. 

*Having him fall off the couch about now would ruin the whole scene\! * 

Then demand he closes his eyes. Threaten that you're going to stop sucking him if he opens them. 

Slowly redirect his cock so that it points between your and Abby's mouths. Wrap your lips round your side of his shafts and pull Abbey's lips onto the other side in the same position. 

*His shaft needs to be parallel to your lips not pushing in and out of your mouth. * 

Kiss her lips, and have her kiss yours, tongues and all, around his cock, passionately. Groan as if it's giving you as much pleasure to do this as he's getting from receiving it. 

*The vibrations will only add to the sensations he's experiencing. * 

Page 62 

Slide your lips along his cock in tandem with Abby. Have your tongue pushed forward so it's sliding along his cock. 

*You need to do this slowly so that your lips and Abby's lips are never off his shaft and are* *together so he's not 100% sure, with his eyes closed, that you're not the only one sucking his* *cock. * 

Slide up towards his head and lick that area just under the eye of his cock. 

*The same one you were pulling on when you were tugging on his ball sack, remember? * 

Grab his shaft, lean back and demand of him that he doesn't come yet\! 

*If you've been making him edge as often as you should have been he should be able to last* *for a while longer. * 

Return to what you and Abby were doing but, this time, when you get up to the head of his cock move your head so the tip slips into your mouth, swirl your tongue around the eye then slide your lips, with Abby's, back down his shaft. The next time up let Abby do the same thing to him. Repeat this a few times, alternating who is taking him in their mouth *Keep in mind that you've had him edging for a long time so you don't know how much longer* *he is going to last*. 

Fairly shortly, because he's going to come, one of the times Abby is about to take him in her mouth let your lips come off his shaft, wet your forefinger with your tongue and rim his ass as his dick slides into her mouth. 

He's going to immediately come because that's going to be too much for him. Have Abby deep throat him \(push her head down on his shaft\) and get up so you can passionately hold his head and kiss him. As he spurts his seed out tell him, loudly, how fucking hot watching him do that is. 

*He should spurt quite a lot of times because he's been edging for so long. * 

Yell at him "That's it, baby, choke that fucking slut with your come. Fill her so full it leaks out her ears\! Shove your big cock down her throat so she gags\! Fuck her slut mouth\! Make her your bitch\! Make her your cock sucking cum queen\! Fuck what a dirty cum swallowing fucking whore she is\! Show that useless fucking lesbian bitch what a real man's dick tastes like and what it's like to be mouth fucked with a real cock, instead of the dildos she usually uses\! 

*It's 100% imperative you give him what he needs to be able to maintain the fiction in his mind* *that he is coming in the mouth of a woman, who is also his partner's lesbian lover, and not* *into some guy's mouth. If he snaps into the realisation that he's just let a 'man' suck him off* *he's going to lose it and you're going to be in deep shit. He will probably never forgive you. * 

Page 63 

**25o. Getting him to let you play with another. ** 

You need to push Abby off his cock as soon as he's finished coming and send her up to the end of the couch. Make sure she knows she has to stay quiet. Drag him down into a sitting position and make sure your body is between him and Abby and you're really close to him so he can't easily see her. You need to keep kissing him and stroking his face. Tell him what a fucking stud he is lasting that long and then coming that much. 

*You must feed his ego and absolutely ensure he knows he's your man and you are in awe of* *his sexual prowess. That he makes you so incredibly happy and you feel almost ready to take* *a lesbian lover now. Gloss over the 'almost' if he says something. You should try to not have* *to take one, unless it's something you actually want to experience, if you can avoid it. *

*Because it's all about you, remember? * 

A little confusing, isn't it? I get you to break him down and then have you build him back up. 

But these things take time and if you push him too far too fast he'll snap out of the sexual spell you have him under and want to go back to being just Brian. And letting him realise that, not only did he just let a man suck his cock willingly, he enjoyed it and actually came in that guy's mouth, is definitely pushing your slightly homophobic husband too far\! ** **

The worst part is, if you lose him now and he leaves you, and because he has never had so much sex and orgasms ever before, he will, most likely, look for this exact thing with another woman and that bitch will get the benefit of all your hard work\! . ** **

Keep crooning at him and stroking him, stay away from his cock for now, because it will be too sensitive. But you'll want to be starting the process of heating him up again. Keep telling him what a huge stud he was during that session and how he has made you even more in awe of his love making prowess. Start to touch and stroke his erogenous zones, behind his ears, his ear lobes, etc. Kiss him more and more fervently and take his hand and put it near your pussy. 

*Make sure he can tell how badly you need to be fucked right now by touch \(wet and hot* *pussy\), sight \(writhe as if you're just so hot you could almost come, hold his hand in place on* *your pussy and hump his hand and leg\), and sound \(moaning and groaning and telling him* *how wet he's made you\). * 

Start to be more intense about getting him hard again. Slip your hand between his legs and rim his ass. Kiss him harder and longer. Kiss his nipples and moan. As soon as he is mostly hard again take him in your mouth. Be gentle\! Spend way more time licking along his shaft and swirling your tongue on that spot just below the helmet than with him in your mouth. 

*You want it to be erotic, not trying to make him come. Think making love vs fucking. Both are* *good but the intent is different. He makes love to you, generally speaking, you fuck him. But* *this is the time to make love to his cock. * 

Page 64 

Once his libido is once again racing \(i.e. his cock is hard and throbbing in your mouth \) roll back and lie across his chest, wrap his arm around your shoulders and put his hand on your nipple. Tell him to play with tweak and pull on it if he doesn't do it himself. \(If he's just playing with them tell him to be rougher\) Every time he gives them a bit of a twist or pull thrust your hips up and groan. 

*If you're not actually enjoying it's time to pretend again. He needs to believe you are as hot to* *go as you can possibly be\! * 

Keep your hand on his cock with a fairly firm grip. You want to be pulling on it not sliding your hand up and down it so you're stretching on 'that' spot again. Put his other hand on your other breast and squeeze his hand so he squeezes your breast. Groan and buck when he does. 

Turn your head and kiss him just below his ear and on his jawline. Moan "I'm going to make her eat my pussy, baby. Play with my nipples and kiss me while she does, please?" Sound like you're begging him to allow you to do this. 

*At this point he needs to feel like he's in control of things and that you need his permission to* *have her do it\! * 

Pull your skirt up and pull you thong off to one side, look at Abby and say "Eat my pussy please, darling?" 

*Remember you are trying to maintain the illusion that she is your lesbian lover so behave as* *you would if she was. Do not act with her like you do with Becky at this time\! * 

Abby will, of course, be really eager to do this. 

*Hopefully her skills match her enthusiasm\! But, regardless of her skills, you need to really get* *into it. Guide with your free hand as necessary to get her onto the places where you can* *really get off. * 

*Do not knock her wig off\! * 

Keep pulling insistently on your man's penis and kissing his neck and jawline and tongue that area. Every time he tweaks or pulls a nipple give out a guttural groan, arch your back and push your pussy harder into Abby's face. 

When you're getting close to coming, clench Abby's head between your thighs, sit up, still holding onto your man's cock, turn to him and say "I want to ride her face while you fuck me from behind, baby. Will you do that for me?" 

*You need to once more sound like you're asking permission. * 

Of course he'll be keen\! Tell Abby to sit on the floor with her head on the couch cushion. Pull your skirt off, but leave the thong on, straddle her head, pull your thong to one side and lower yourself onto her willing tongue. Make sure you say something like "Fuck this is so hot\!" 

Page 65 

Guide your man into your pussy, if you don't he's most likely going to try and slip it in your ass\! 

*You've got to admire his willingness to keep trying though, don't you? * 

Tell him to lean forward so he can maul your tits. 

*Sigh, yes, exactly like that, I know I said... blah blah... but sometimes, to achieve the result* *you want you need to break the rules\! * 

And tell him "Give it to me, baby. Make me your slut\!" 

*Very shortly Abby is going to be licking his balls and shaft as it slides in and out of your pussy. *

*Do you really wanting him to start remembering that 'she' is actually a he? * 

Dirty talk time\! Keep telling him to "Fuck me hard, own that pussy and make me squirt on your magnificent cock\! Shoot your load in me, fill my cunt up with your man juice." And others of the same ilk. 

*Yeah, that word again blah blah... * 

You need to intersperse those kind of comments with others about Abby "My god, baby, she's eating my pussy so well\! Can you feel her tongue on your balls, baby? Doesn't it feel so good? Wipe your cock on her face after you've shot, honey. Make her all slutty\!" Then, as he starts to fuck you harder, go back to the type of comments above. 

*You should allow yourself to come as many times as you can. At least twice, preferably 3 or 4 *

*or more times, moaning for her to keep licking you well and for him to fuck you hard. * 

*If you can't wtf is the matter with you? You've got a tongue on your clit and a hard dick in* *your pussy and soon it's going to be your sissyboi's tongue on your clit and that 9in monster* *cock you've always wanted to try in your pussy or ass. You should be in absolute seventh* *heaven\! * 

*If you can't come that much you're going to have to fake it to at least two until he starts to* *unload in your pussy. *

## **25p. Preventing an explosion. **

As soon as he's finished coming, push him back, move away from Abby, cup your pussy as if to catch the sperm running out of you, give him a really big 'thank you kiss', tell him how awesomely good it was and ask him to go and get you a warm wet washer, please? Don't give him a chance to stop and think. As soon as he's out of the room tell Abby to go and get Page 66 

changed and go home as quickly as possible, that you're sorry she didn't get any but that you promise you'll look after 'just her' soon. 

Follow your husband into the bathroom, turn on the shower taps and strip him off. Be desperate about it. Tell him in a little teary voice to hurry up, you need Brian back because you're a little freaked out right now. 

*He'll be confused as he'll be probably thinking 'hang on, you're freaked out? Shouldn't I be the* *one freaking a little here? * 

So say "I just came whilst a woman was eating my pussy, well she isn't, but it seemed like it at the time, you know? And now I feel all weird about it." 

Drag him into the shower and remove all traces of Becky from him yourself using your hands and lots of warm soapy water. Pay real special attention to his cock, clean it particularly well and lean over at give it a kiss, pat him on his chest, give him a tremulous smile and say something like "You have such a magnificent cock my gorgeous stud muffin\!" 

Hand him the soap and a cloth or loofa and ask, with a trembling lip "Please clean me?" 

Tell him how good it feels for him to be cleaning and caressing you. When he reaches your pussy give a little gasp as if it's hurt, or something. When he asks "what's wrong?" Say "It's alright. It doesn't hurt, it's just all a little weird right now\!" 

*You do this to stop him from freaking out. Now that he's not horny he's going to start to* *remember that he not only let another man eat your pussy he's now come in a man's mouth,* *twice\! But if he feels like he needs to look after you because you're weak and vulnerable he'll* *push it aside and concentrate on you. That's what you've been training him to do, right? * 

*You're really hoping here that he has quickly come to the realisation that a good blow job is a* *good blow job and what does he care whose mouth he came in? Then you won't have to do* *virtually any of what follows\! * 

Pay special attention to him when you get out of the shower. Take the towel and dry him yourself, pay a lot of attention to his cock, this time too. Quickly towel yourself off and lead him back to the bed. Ask him to get up and lie on his back. Climb up and snuggle into his chest, ask him to put his arms around you if he hasn't already. Stroke his chest softly kiss the side of his mouth and with a trembling lip ask "Will you make love to me, right now, honey, please? I need you to show me I'm still straight woman and that you still want me." 

*If he goes to get up to change into Becky, if you've trained him properly he should, say "No,* *like this, as my husband not my sexy slutgirl. I just want you to lick my nipples to warm me up* *a little before slipping inside me and making me feel good." * 

Page 67 

Have him warm you up a little but don't let him touch or lick your pussy \(unlike usually\) if he tries just say "Please don't, it just feels too weird at the moment, can you please just slide that superb dick of yours in me and make gentle love to me?" 

*If you've been denying him for 2 weeks he should be still good to go, if he isn't you know how* *to get him there. Make sure you come in a reasonably short time, fake it if you have to, then* *ask him, quietly, to "Come inside me, my love. I need to feel your seed in me." * 

After he's rolled off you, prevent him from going down on you to clean you up, \(he should, because you've trained him well, haven't you?\), cuddle up to him again and give him a loving kiss and say "You're so good to me, my love. How did I get to be so lucky?" Give him a light nudge in the ribs and say "Mind you, you're pretty lucky too\! How many of you mates have wives that let them fuck as often as we do?" Tell him "Maybe having a woman eat me out wasn't so bad as long as you're there with me." 

*Because you've trained him well he'll reach for his cage, let him put this on, and give him a* *hug and a smile of approval. *

**25q. Making him admit he liked it. ** 

Beat him up the next morning and bring him some breakfast in bed. Sit up facing him drinking your coffee and look at him quite intently. He'll eventually get self-conscious and say "what?" 

Say "I want you to be honest with me, okay?" He'll nod, of course. "Did you like last night? Did you enjoy having Abby suck your cock? Don't lie to me because I know how hard you came down her throat and I know having her lick your balls when you were fucking me was great because every time she did your dick jumped inside me?" 

He'll, more than likely, be really embarrassed so you'll have to reassure him. "Don't be embarrassed, my love, the whole thing was just so intense that we both kind of lost ourselves in the moment and thought she was real. I know I did, that was why I was freaking out a little last night\!" 

Give him a moment and, if he doesn't answer, say "Well? Did you?" 

If he says "yes" say "Good because I really enjoyed it, too. I was so hot and you fucked me so well that I want to do it again, soon. What do you think? Next time I'll make sure you get an even better show and get to do me even harder\! Please say yes, baby\! It'll be so good for us both, I promise\!" 

If he still refuses to answer say "Don't worry about it so much, honey\! We both had a really good time and we both had some really great orgasms\! I know you're not into guys but she's not really a guy. She's kind of like me but with a permanently attached strapon. Besides I Page 68 

really love having you and her please me\!" Pout and say "You do like pleasing me, babe, don't you? 

Of course, he now has to say yes. 

*There's that emotional blackmail again * 

Then, as above say "Good because I etc. " 

## **25r. Taking your first lover. **

Once he's agreed to another meet you need to arrange it as soon as possible. Phone Abby and make sure she is available for the very next Saturday, insist if you have to. Remind her she is still to wear her cage and control briefs when she turns up. Tell her you want to see her before then, at her place, so you can make it up to her for not getting anything on Friday \(or whenever it was\). Tell her to take a day off work so there is no chance of your man catching her with you and take the day off as well. 

*This is part of teaching yourself that you're allowed to take lovers where and when you* *please. That you are a sexy desirable woman that all men want to fuck \(well the straight ones,* *anyway \). Be very careful though, because if he catches you cheating behind his back with* *Abby it's going to seem like the ultimate betrayal to him\! But you need to ensure Abby still* *wants to be part of your play and if she's not getting to come, why would she? * 

How you approach your assignation with Abby is going to depend on what kind of relationship you want with her. If you want to add her to your list of sissyboi lovers *Not sure why anyone would want more than one, myself * 

Then instruct her to be totally made and dressed up when you get there along with her cage and briefs \(let's hope you remembered to give her they key back or she had a spare, otherwise she's been locked in it since Friday, probably not such a bad thing \), if you don't, tell her you want her in male mode. 

In the sissyboi scenario you'll want her to immediately learn, as your sissyboi has, that it's not your role to get her off. That she is responsible for her own orgasms. Have her remove her control brief and cage. Then you will expose your breasts to her and tell her you want her to jack off onto them. As soon as she has come on your breasts, make her clean them up with her tongue, tell her "Good girl. I'll see you Friday\!" And walk out. 

If you've decided the one sissyboi is more than enough for you make sure 'he' knows to meet you in male mode and when you get to his place make him fuck you immediately. 

Page 69 

*Yes, fuck, you're allowing yourself to know that having virtual strangers fuck you to orgasmic* *bliss is fucking awesome\! Unless you've already got the results of the STI test back make* *sure he wears protection. * 

*If you've decided to bare back, don't let your man to touch your pussy until you're sure 'Abby's* *seed' is no longer evident. * 

*Get used to doing this\! Your bulls certainly aren't going to be wearing a condom when they* *have use of your cunt. * 

Make sure he satiates you. Make him do it properly, but as a man would, so you can enjoy yourself immensely 

*This is all about you, remember? * 

If you want, let him tongue and stretch your ass, and fuck you in there. 

*Make use of the butt plug practice you've been making hubby give you\! * 

During your 'play time' with Abby you need to tell her she's expected to arrive at your place as Abby from now on because she needs to show her commitment to you and her possible new role as a fairly regular play partner. But she is to have a change of 'boy's' clothes to go home in. 

*She'll raise the usual protests of "What if someone sees me? And "I can't, I don't want to be* *caught\!" Don't give her the option. Just say "Its dark when you come to my place, put a long* *coat on and carry your heels until you get to the car. You park right outside the door when you* *get to my place so scurry inside and shut the door\!"\) Don't take no for an answer unless she* *says it's an absolute deal breaker and won't turn up if she has to come dressed \(trying to* *substitute a different girl in, at this stage, will make life difficult\). *

**25s. It's time to become the dominant partner. ** 

You're going to spend the week making sure your man's balls are aching. Tease him relentlessly. Send him pics of your pussy 3 or 4 times a day. Ask him if he can tell you're horny? Send some with your fingers straddling your clit or dipped into your pussy, always with your thong on and pulled to the side. 

*It's more erotic and less pervy. * 

Tell him he can show them to his workmates if he wants \(along with a smiley face emoji so he thinks you're, probably, joking\). 

Page 70 

*Sigh. It's your pussy, love. Neither the FBI nor CIA have a 'pussy identification squad' whose* *sole job it is to identify whose vagina that texted pic belongs to\! Besides, he'll love it and be* *scandalised \(and secretly really turned on\) that you're encouraging him to show his mates* *your pussy pics. * 

*Plus, whenever you're with his any of his workmates, you'll be able to tell which ones have* *seen them because they'll be 1\) obviously leering at you \(they're men and, given you're sexily* *dressed, will leer at you anyway but only when they think you're not looking\). 2\) Trying to look* *up your skirt to see what colour your thong is. 3\) Giving you a 'knowing' look. You want this* *attention and, you never know, one of them might be sporting that 9in schlong you've been* *craving. * 

Send him texts telling him how sexy his ass and cock look in his knickers and cage and how you can't stop thinking how great it feels when you rub your hands across them. Ask him \(again\) if he can tell you're horny? Tell him you've already come twice, at work this morning, reliving the moment he came in your pussy and on Abby's tongue and face and that "You're ruining my work performance you goddamned stud muffin\! I fucking love it\!" with a lot of smiley face emoji's. 

Constantly remind him how hard he came down Abby's throat and how much you loved seeing him do that. Remind him how good it felt having Abby licking his balls as he was fucking you. Tell him how much you love having 2 girls service you and you can't wait till you're both doing it again. Do this every day until at least Wednesday. 

**25t**. **Making him submit to you. ** 

For the next week, whenever you're with him, you'll wear your strapon as described above \(so if you get home after him put it on immediately\). You'll also want to keep yourself looking as sexy as you can all of the time you're with him so make an effort to go sexy yourself up as soon as you get home. 

*A note here: Men usually need a little time, when they are first back from work, to relax, wind* *down and switch back to home mode. So, when he comes in through the door, hand him a* *beer and tell him to strip off and go sit and relax. * 

About 10 -- 20 minutes after he gets home on the Wednesday night \(or after you've got home and done yourself up\), take his cage off, keep hold of it, and send him to shower and shave down again, don't let him protest just roll your eyes and say "Just do it, okay?" Next say 

"When you get out of the shower, I want you to put your stockings on, choose a pretty pair of knickers, and bring them out to me." 

When he's back, take the knickers from his hand \(or tell him to take them off if he's wearing them\) kiss him firmly, grope his cock, push down on his shoulders and say "On your knees, lover boy, Mama has something nice for you\!" Make him suck your 'cock'. 

Page 71 

Tell him how good it feels and use a lot of phrases like "suck Mama good, my little cockslut. 

Mama loves her cum slut sucking her dick. Show Mama what a good little cock sucker you are\!" 

Push him off your 'dick' and tell him "On your knees, Becky Cockslut, head on the floor and show mama your fuck hole\!" 

*You're at another one of those possible complications parts. If he won't accept you in this role* *and himself as the submissive partner here you're probably going to lose this war and he will* *want to go back to being Brian and have had enough of these 'games'. * 

If he resists say firmly and with absolute conviction you will be obeyed "I said on your knees, you fucking slut, show me your hole." 

Hold your breath, and remain silent, pointing at floor with as stern an expression on your face as you can have. He should cave. If he hasn't turned so his ass is toward you tell him sternly 

"No\! I said show me your fuck hole now turn around and show it to me\!" 

Once he's in position tell him to "Spread your cock hole, bitch\! Spread your cheeks and show Mama your cum hole is clean and ready for Mama's cock\!" Do not let him resist. Just repeat "I said blah blah..." and smack his ass. 

Kneel down behind him and let your strapon slide between his legs and across his balls and cock. 

*You'll know you've won if he's hard. You're hoping he's rock hard. If he's leaking a little* *precum things will progress very quickly now because he is already your sissyboi, he just* *doesn't know it yet. The below assumes he's only kind of half-mast. If he's totally soft you may* *be in trouble. * 

Reach up under his arm pits and run your fingers around to his chest. Rub down his stomach. 

*All of these actions should be done erotically so he comes to full hardness. * 

Say "Has my little slut made herself totally clean for Mama? Or has she been a bad girl and missed something? Becky is going to be punished if she's been a bad girl\!" 

*Don't find anything even if there is something obvious. I'm not sure he will accept punishment* *at this stage. * 

Once you've finished your inspection lean back and say "Warm your fuck hole up for mama, baby. Mama needs to have some of your sweet ass\!" If he goes to get up and get some lube hold him down and say "No\! There's no time for that\! Wet your fingers with your tongue and lube it that way." 

Page 72 

*You don't want to have to do a damned thing to help him get off, remember? He needs to* *learn that, if he wants to be allowed to come, it's all on him\! * 

Grab hold of your 'cock' and say "Make Mama all wet, baby girl Becky, so I can fuck your hole." When he's sucked it to readiness tell him to "Turn around and spread your cum hole again." Insert your strapon quite firmly but not so hard he jerks forward and collapses. 

*If he's taller than you you're going to have to squat to achieve this so I hope you haven't been* *missing leg day\! * 

Once you're all the way inside him have him lift up so he is in the classic hands and knees position and start to fuck his ass, gently at first. Do not let him touch his cock. 

*It's called pegging and a surprising number of guys love it\! If you can, try to introduce some of* *this activity into your sex life before you start him on this journey. It will do two things. 1\) get* *him used to taking the submissive role and 2\) Have him already used to ass play so you'll be* *able to skip a couple of the steps above. * 

As soon as you've pegged him to as close coming as you dare grab him by his hair \(or the top of his shoulders close to his neck if he's bald\) and start to pull him back onto your cock and slam that strapon into his cum hole as hard as you can. 

*He should almost immediately pop and start to come. * 

Hiss at him "That's it you slut\! Take Daddy's cock and cum like the fucking whore you are. 

You love Daddy's cock in your fuck hole, don't you? Tell Daddy how much you love it, you slut\! 

*FFS\! Do not call him a queer or faggot or anything that alludes to these slurs\! You need to* *maintain the illusion he's your lesbian lover still even though you've just called yourself *

*'Daddy' a number of times. * 

Continue to fuck him until he comes hands free. 

*If after more than a few 3 -- 4 strokes he hasn't come tell him "Take you boy clitty in your* *hand and come for me baby, please." * 

Once he's finished coming push him off your 'cock' tell him to roll over then sit yourself down on his face. Instruct him "Make me come, baby\!" and do so, hard\! 

*Time to blah blah. *

* *

* *

Page 73 

**25u**. **Setting the scene. ** 

On the day you've arranged to meet Abby you will spend all day telling your man you're really going to ramp up the fun for him tonight and that you hope he's ready to be fucked harder and longer than ever before\! Tell him he's going to come so hard and so often that he's going to beg you to stop but you're not going to. Explain that, by the time you've finished with him, neither of you are going to be able to walk for the rest of the weekend. And that you expect you \(you not him\) will be still walking bowlegged at work on Monday. 

*You're going to need to bring Abby into your plan so make sure she knows that you're going* *to try and get Becky to fuck her tonight. So, when the time comes and her control brief is* *being pulled down or Becky is feeling her ass, she is to make sure her hand is covering her* *cock cage and she is not to let go unless Becky pushes her hand away and wants to feel her *

*'bits' through the cage \(let's hope, right?\)* 

*Also, make sure Abby knows she is to have cleaned, stretched, douched and lubed her anal* *passage before she gets to your place and to give you a key to her cage when she comes* *inside. * 

*Don't worry, I can guarantee that she has probably already been doing this on the other* *occasions she's come over, because, just in case, you know? * 

Go through the usual process of having him ready for the evening's activities. 

*That you've taken his cage off and he's totally shaved down, dressed sluttily and his makeup* *is all done. You've got him as 'hot to trot' as you can make him without him coming. And* *you've loosened his morals and reservations by having him a little tiddly. * 

*Note: He should be keen, by now, to have regular play sessions with Abby \(although he's* *unlikely to admit it\) because 1\) he's out of his cage and 2\) Someone else is actually making* *him come\! 3\) Sometimes it's even you\! * 

You will have also made yourself into that vision of a sex Goddess that he, and Abby, have come to worship. 

## **25v. Pushing his limits. **

You're going to take the dominant role from the very beginning tonight so you'll need your strapon and his prostate massager somewhere close to hand in the lounge room but hidden from view. In your handbag would work, nicely. 

Tell 'Becky' to take the middle seat of the lounge and make herself comfortable. Tell her that she may 'play with her boy clit' because you like watching her do that but that she is, under no circumstances, to come\! 

Page 74 

*This is about getting him used to the idea that sex is something you have whenever you feel* *like it but he only gets to when you allow him. * 

You should be encouraging him to stroke and play with himself. Give it the occasional tug yourself as you wander by. If you're sure he won't come you can straddle his thighs, push your breasts into his face and tell him to lick them and let his cockhead slide across your clitoris and the entrance to your pussy. Groan as it does. You could even let the head enter you a bit. 

*Dangerous because he may pop and do you really want to be trying to fan the libido of a* *slightly inebriated man, that now wants to rest because he's just come, when there's another *

*'man' about to turn up? * 

*Later in his training it won't matter, because he'll be used to having you not care about his* *needs when you're going to be entertaining a bull. * 

*Note: You do this so he can feel, and be sure, just how hot and ready you are to go. * 

When Abby arrives, hand her a drink and tell her to go sit next to Becky. 

*If your man tries to object walk over to him, stand so you're looming over him cross your arms* *under breasts and look down at him sternly. After a few short moments lean down and grab* *his dick and say severely "You'll do it, and enjoy it, or you're going to be looking after this* *yourself tonight\!" * 

Keep hold of his cock, sit on the couch next to him on the other side from Abby, so he is in the middle. Say something like "Becky has such a beautiful girl cock, Abby, don't you think?" 

If Abby just nods or simply says "yes'. Say "Tell her then\! Tell Becky how beautiful her girl dick is. Tell her how good it feels in your mouth. Tell her how much you love her coming in your mouth and how you adore licking her balls." 

Insist that she does, in graphic detail, even if she goes all shy on you. 

*You're now at one of those critical points so give your man's cock a bit of a suck and lick while* *you wait to see what happens. * 

Hopefully, he'll just groan and hold your head as he enjoys the little oral you're giving him. 

*Do not let him come\! * 

After Abby has finished complimenting his cock you'll say something along the lines of "Oh, baby\! See? I'm not the only one that loves your beautiful dick\! Lean back I'm going to get her to suck it for you\! 

Page 75 

Give his dick a couple of firm tugs and a quick lick and suck yourself as you wait for him to lean back. When he does get Abby on her knees in front of him and your hubby's cock in her mouth just as quickly as you can. 

*If he is going to freak out on you this is where he will. If he does prepare to protect yourself\! * 

*If he lets her suck him, congratulate yourself because you've won. He's a cock sucking* *sissyboi and it's only a matter of time before he's fluffing bulls for you. *

## **25w. Preventing an explosion 2. **

Encourage them both to really go for it. Push Abby's head down on his cock and, when she gags, say "That's it Becky baby, make that slut choke\! Show her she can't handle a girl dick like yours\! 

*This has changed from last time. You want him to stay in girl mode and accept how good it* *feels without coming out of his role as Becky Cockslut. * 

Play with his balls and, if you can reach, rim him. Make him come in her mouth as quickly and as hard as you can. 

As soon as he has finished, push Abby off him and send her back to the end of the couch. 

Straddle him and kiss him passionately, lean back and take off your top and bra and guide his lips to your nipples. Grab his hand and guide it to your snatch. Moan and groan and tell him how fucking hot that was and to "Finger fuck me, baby girl. Mama needs you to make her come\!" Hold is cock as he does it if you can comfortably reach it in this position. At the very least make sure his dick is against your bare skin, somewhere. 

*You have to come as if seeing your husband shoot down the throat of someone that wasn't* *you was the greatest thing you have ever seen. If you can't WTF is that matter with you? *

*Your husband is soon going to be actively recruiting big dicked bulls to fuck you\! You should* *be in seventh heaven\! * 

*Note: Here is one of those complications moments\! Are you jealous of the fact your husband* *shot so hard and willingly down someone else's throat? If you are, good luck turning him off* *this path, now. If you try to turn him aside now there's a really good chance he will just be a* *crossdresser and get other crossdressers and transgirls to suck and, possibly, fuck him* *behind your back\! * 

Once you have had a satisfying orgasm \(or have pretended to. Just one, you greedy bitch\! \). 

You need to keep his attention on you, and away from Abby, until he's ready to go again. 

Page 76 

*Once you have him to the stage where all he can clearly think about is his need to come* *again you can ramp up his conversion from 'unwilling but willing to allow it because he's horny* *and needs to come' to 'willing participant' *. *So drop down to* the part of *25x where you're* *standing next to Abby holding your man's cock. *

**25x. This first part assumes he won't let Abby suck him off, just yet, but hasn't freaked** **out either. If he has, this part won't be needed. ** 

*If he refuses don't push the issue here. Very soon he'll be doing a whole lot more than letting* *some 'cock in a frock', blow him. He'll be inside her ass\! * 

Continue to ramp up his need to come as high as you dare. Once you know he's almost at 

'that' critical stage tell him to stand up. Move yourself across, next to Abby. Position yourself on the couch in such a way that you're that you're kneeling facing the back of the couch with your ass towards your man. Spread your legs and lower your hips so your ass is level with his groin. Hold the hand that isn't closest to Abby behind you and open and close it a few times. 

*If he doesn't get the hint tell him "Put your beautiful girlie cock in my hand, my gorgeous* *Becky girl\!" Then say, "Fuck Mama's hand, my sexy slut girl." * 

*Be careful to not let him come, remind him not to, if you think it's necessary. * 

Instruct Abby to get up beside you in the same position. Once she is in place pull your skirt up above your thong and pull hers over her briefs as well. Let go of your man's cock and say to him. "Fuck me my beautiful lesbian lover\!" 

Reach back between your legs, pull your thong aside and spread your pussy lips if you can reach. 

*There's a pretty good chance he's going to try and slip it in your ass. Do not let him\! Yes he's* *still going to try\! * 

Time to combine telling him to 'fuck me harder' with telling him how good it feels and "Don't you dare come yet, bitch\!" 

*Allow yourself to come on her cock and be loud about it \(you'd better hope all the edging* *practice you've been making him have works\). * 

*Just one, you greedy bitch\! Too much longer than that and there's no way he's going to be* *able to hold on\! * 

Once you've come, push him off you, grab his cock and stand up next to Abby dragging him with you. 

Page 77 

*Make sure you're both pretty close to Abby so that you're looking down at her back and the* *top of her ass, not at the globes of her ass. * 

Play with her ass over her briefs as he watches, slip your hands a little way into her briefs, look at him with a serious expression and say to him "Feel her ass baby\! Doesn't she have a sexy ass? Not as sexy as yours, but still really nice though, huh? 

Place one of his hands on her ass. 

*If he seems hesitant don't let him think\! Get his cock in your mouth and a finger on his* *rosebud as quickly as you can so he goes back to just wanting and needing to come, then try* *again. * 

Once he's openly feeling Abby's ass pull her control brief down so the cleft of her ass and the top of her rosebud are showing and say "I want to watch you fuck her in the ass, baby." 

*You want him to fuck her in the ass because she doesn't have a pussy, remember? He* *should be keen to go for it because he hasn't had anal since you started him on this journey. * 

"You've been so good to me, baby, I want to give you what you've always wanted, another woman to fuck at the same time as me\!" 

Assume it's a given that he is going to want to fuck her and pull Abby's briefs down. 

*This is why you told Abby to put her hand over her cock cage when she felt her control brief* *being pulled down. In a standing position her caged dick and balls won't be obvious. * 

Start to guide his cock into her ass. Give him a lot of quiet encouragement. "Do it, baby\! I want you to have her. Your cock looks so big against her hole. Fuck that sexy ass for me, please, baby? I'm going to stick my tongue in your ass as soon as you're inside her\!" 

*You have once again reached a critical point. If he suddenly slips out of Becky mode and* *back into Brian, both you and Abby, are in deep shit\! Even if he doesn't assault her, and* *possibly you too, your marriage is, most likely, done\! * 

*I warned you right at the beginning, remember? *

**25y. He fucks a 'man'. ** 

If he slides into her you need to make sure he absolutely gives it to her. That he 'slut fucks' 

her. You want him to give her an absolute pounding\! So be as vocal in your encouragement as you can. Egg him on and get him as lost as possible in the moment and the sensations. 

Page 78 

Once he establishes a solid pounding rhythm instruct Abby to start getting loud too. Say to her "Doesn't Becky's cock feel so good in your ass, you slut? Sluts like you love a good anal pounding, don't you? Tell me how good having your slut arse fucked feels\!" 

*Threaten that you're going to make Becky stop and fuck you instead, if she won't. * 

Once you can tell he's getting close to orgasm. Squat down behind him and tongue his ass until it's well lubed. 

*I know I said earlier to never 'make him come' but... rules... blah blah\! * 

Stand up and slip a finger into his ass, try to reach his prostate if you can. Put a hand on his ass, lean forward and say "Fill that slut up with your girlie cock juice, Miss Becky Cockslut\! 

Own that bitch's ass, make her slave to your beautiful girl cock\!" 

Continue to finger his ass until he shoots his load deep into her ass. As he comes, finger him a bit harder, and keep talking dirty to him until he's shot most of his load into her ass. Before he has totally spent his load push Abby off your man, lie on your back on the couch and guide him into your pussy. Clench down on his shaft with the walls of your pussy, pull his head down to yours and give him a big hickey on his neck and beg him "To fuck shit out of me\!" 

*This is why you insisted on her douching. Abby's ass, and therefore your man's dick, is clean. * 

Try to ride him all the way back to hardness again but, regardless of how hard he is, make sure you come at least once \(pretend blah blah\!\). Make absolutely no complaint if he goes soft just use all of your finely honed skills to get him 'bubbling along again' as soon as possible. 

*This is the reason I've had you denying him orgasms, keeping him sexually frustrated and* *having him edge for long periods of time. It's so that he's going to be unable to think about* *much more that his urgent need to come at these crucial points. * 

*It's time for his conversion from someone who is 'unwilling but willing to allow it because he's* *horny and needs to come' to 'willing participant' *. 

The above \(25v to 25y\) will be where the two scenarios merge. The one where he did go and change with the following one, where he refused. 

In some ways this scenario is actually easier as it's a lot more direct and involves a lot more emotional blackmail. The risk is that he's no longer willingly going along with things because he's horny and doing what you want gets him lots of release. Instead, you're going to be forcing him to your will so there's a lot more chance of resistance and that he snaps out of the sexual trance you've woven him into and will want to go back to being 'Brian'. 

Page 79 

**26. The other scenario. ** 

If your man refused to go and get changed you need to wrap this visit up as soon as is politely possible. Send Abby to get changed and escort her to the door. Apologise for nothing happening but that you'll keep working on him until he comes around and to stay in touch. 

*Make sure you stay in contact with her because you're going to need her again at some stage* *in the future. * 

Your man is currently holding doubts about what is going on, and all the things 'you have made him do' right now and he's out of his cage, remember? So you're going to need to get him horny and making love to you as soon as possible. 

*Yes I know I said to never let him fuck you unless blah blah... but you're in an emergency* *situation here and unless you want to lose all your hard work and not complete his* *transformation you need him 1\)horny 2\) Thoroughly enjoying a good fuck and 3\) Back in his* *cage ASAP\! *

**27. Getting him back on track. ** 

Once you've finished satiating him venture a smile and offer him his cage. If he refuses don't make any kind of fuss about it at all. Just put it down in his dresser, hug him, lie with your head on his chest and ask him what's going on? Listen to him carefully and quietly while you continue to stroke his chest and stomach \(stay away from his dick\), play with his pecs \(not his nipples\) and squeeze his biceps. He'll have a litany of complaints. He's not a pooftah so why do you keep insisting he dresses like one? Why the fuck was there some fucking sissy faggot in his home? And 'I don't want to do any of this shit anymore so it ends now\!' 

*FFS\! Remain calm\! He's spoiling for a fight so he can exert his masculine dominance over* *you with aggressive behaviours and tones and volume. If he starts yelling tell him you're going* *to go sleep in the spare room and you'll discuss it some more in the morning when he's calm. * 

*Remember men are like steam engines blah blah\! * 

Once he's wound down sit up facing him and say "I dress you pretty because I like it and it makes me horny and the more often, and sexier you dress, the hornier I get\! Don't tell me you don't like it when I'm horny\! Because we both know that's bullshit\! 

I know you're not a pooftah, honey, no pooftah could have fucked me as well or as often as you have over the last few weeks \(months/years if it's been that long\). 

Abby was here, at our invitation \(reminding him that he said "yes" when you asked if you should invite her over\), because I thought meeting someone else who does the same things we do would make it more normal for you and that you'd be less weirded out about it\!" 

Page 80 

Now you need to look sad and say "Of course you can put all of this away and we can stop playing sex games if you want to give all this up. Your choice\!" 

Change to a severe expression. "But if you think our sex life is going to go back to the way it was before you have another think coming, Mister\! I like being pleasured, I like you making me come first and I like you cleaning me up with your tongue afterwards and you're going to keep doing it or you're not getting anywhere near me\!" 

*You make the demands about your sex life not going back to what it was so you, at the very* *least, get something out of this whole charade. * 

"Now, are we going to continue our fantasy sex games, or am I sleeping in the spare room until you've calmed down?" 

*Silence is once again your friend here. Casually cup and push up your breasts to remind him* *what he's going to be missing out on* 

*You're at another of those crucial points here. He needs to willingly admit to you that he wants* *to continue. If he won't, you've lost not only this battle, but the war\! * 

The below assumes he has caved and said he wants to continue. If he doesn't cave then let's hope your marriage survives this experiment and he continues to make love to you properly for the rest of your time together so you've at least gained some positives out of it\! 

**28. On this path you're going to need to go down the woman on woman route. ** 

*You'll need to take a female lover and enjoy it in other words\! * 

So you can use that to emotionally blackmail him into allowing you to add an extra male in during one of your play sessions. So here's what you do. 

Probably on AMM, but definitely on one of the more kinky dating sites, purchase a full 3 

month membership for yourself and your hubby \(as a couple\) and look for as beautiful a female playmate as you possibly can. 

*Note: Often what a woman considers attractive in another woman is completely different to* *what a man finds attractive in a woman so make sure he chooses your potential lover \(if he's* *not attracted to her he won't want to have sex with her\). * 

*Another note: The men outnumber the women on these sites by a factor of about 125 to 1 so* *any woman you approach is going to have to wade through 100s of messages every day to* *find yours, so make sure it's a good one\! * 

Page 81 

You don't really care if she's married, single or other, just that she is 100% bisexual and willing to play with you and your man alone \(her hubby or partner is not invited, for now\). 

*Again, this is no time for someone who is inexperienced or 'bicurious' you want someone who* *is really into FFM sex\! *

**28a. First contact with your potential female lover. ** 

Once you've made contact with someone who seems willing to help you experiment ensure she knows that "Yes, you are doing this for your husband but you really want to try because you think it might be fun\!" 

*If you're not going to even try to enjoy yourself then don't bother with this charade. It's time for* *you to cave and hope some of the lessons on how to sexually please you hold\! * 

Get to know her a little through messages and at least 2 phone calls then ramp things up some. See if you can't get into a little flirty chat with her. Ask her what wicked things she would like to do to you and imagine them happening and see if you can't get at least a little turned on. Make sure she knows that you're a complete newbie so you're not sure how far you can go but that you're willing to give most things a go\! 

Invite her over to your place for a chat. Explain to her that your man will be there but emphasise to her, and to your husband as well, that it will be only for a chat and a couple of drinks so you can both confirm there is some sexual chemistry between you. Confirm with her that she is, at this stage, only going to get to play with you and only you and only if both you and she think it will be good. 

*I mean sexual chemistry between you and her\! Not you and him and her or between him and* *her. You have to know you can allow this woman to make love to you and that you can return* *the favour eagerly\! * 

*For this to work you need your man to be Brian for the duration of her visit, so normal male* *clothes, except for his knickers, of course. Take his cock cage off for him. * 

When she turns up \(I'm going to call her Ann for convenience sake\) offer her a drink and a seat on your lounge. Sit as close to Ann as you and her both feel comfortable with, but keep in mind that you'll need to eventually move close enough to touch and even kiss her if it feels right. Talk about this and that until you both start to get to know each other a little and relax. 

Allow yourself to start getting a little turned on. Imagine how soft her lips will feel when she kisses you. Think about how hard your man is going to get seeing you two kiss and how all of this is going to lead to you being serviced by numerous big dicked bulls. 

Page 82 

*If Ann and/or the situation you're in is not turning you then there is no chemistry between you* *two and it's time to wrap it up and send her home. * 

*It's okay to do this once or twice but you're going to have to choose someone and follow* *through with your 'promise' sometime soon or you're just fooling yourself and it's time to pack* *it in and give up on this project. * 

Move a little closer to Ann and touch her hand then take hold of her hand and snuggle in a little closer. Lay your head on her shoulder and sigh. Give her a little soft kiss on her neck. 

*Remember that your man is beside himself right now. He won't be able to believe his eyes* *and is probably about to lose his load into his knickers and, it's probably all he can do to not* *race over and join in, so you need to bring this to a fairly quick close. * 

Share a soft gentle kiss with Ann and turn it into a passionate one. 

*This is where it may become difficult for you as you need to be the dominant one with Ann* *just as you are with 'Becky' and 'Abby'. So suck it up, Princess, and hold the ultimate goal* *firmly in your mind and go for this\! * 

Turn towards Ann and pull her to you. Kiss her passionately and play with her breasts through her clothing. Get into what you're doing for about 3 minutes then pull back, straighten your outfit up, glance at your husband and say primly "Well that's enough of that\! This was only for a drink and a chat, remember\!" 

Be warm about it but show her out of the house. 

Take your man to bed and fuck him hard. Ride him to as many orgasms as you can have, be loud about it\! 

*Yes, I know I said above that you should never have vaginal sex with him except on special* *occasions and that you should never 'make him come. But you're in a different scenario here* *and you need him stay unaware of what you're actual goal is. Besides, this is a special* *occasion\! You've just experienced your first kissing and petting session with a woman\! Or was* *it? * 

Let him come inside you, make him clean you up and hand him his cock cage. He will try to protest, of course, so say 'Nah ahh\! My man\! If you're going to turn me into a pussy licker \(carpet muncher, mutt growler... pick your epithet\) then you're going to give me what I want and having you in this makes you give it to me\!" 

*Demand, with absolute conviction you will be obeyed, that he puts it on. * 

Cuddle up with your man and say "That was actually pretty hot \(kissing and petting Ann\). I started to get into it there for a bit before I remembered whom I was doing it with." 

Page 83 

Pause for a few seconds and ask "What do you think? Shall I get her over again and let her take me to bed?" 

*You should be toying with his cage and nipples whilst you are saying this. Try to make him* *think you're contemplating taking his cage back off so he can fuck you again. * 

Of course he's going to say yes so invite Ann over on the following Saturday night. Explain to her that things are really going to heat up this time and she's going to get to play with both of you for absolute certain, in fact you want her to screw your man that night\! 

**28b. Arranging the scene so you can blackmail him. ** 

All week you are going to absolutely drive your man sexually nuts. Spend as much time as you can winding him up sexually and try to keep him in a constant state of arousal and frustration \(because he is caged and can't get relief.\) 

Confide in him that you keep having dreams about kissing Ann, cupping her breasts in your hands then ravishing them with your tongue. Make him use his tongue to service you at least once, preferably twice, a day. Refuse to tell him what's got you so hot. If he asks if it's Ann smile shyly and say "Maybe". Ask "Would you like to fuck her? Tell me the truth here, baby\! I saw how hard you were and how it was all you could do not to jump on the couch with us\!" 

Make him admit he would love to then say "I think I might have to lock you in the cage on Saturday to make sure you don't forget yourself, what do you think?" and laugh wickedly. 

Remind him again that your deal is that you would agree to 'play' with a woman for his visual enjoyment not that you were going to let him fuck some slut in the pretence of encouraging me to have lesbian sex because I might enjoy it\! Then hesitate for a second and ask "Unless you'd like to find a guy to fuck me first? Seeing as I've found a woman, wouldn't that be fair?" 

And laugh outrageously as if it was all a big joke. 

*You want him so horny by Saturday night that somehow, accidentally of course, he finishes* *up with his dick in her pussy. * 

*So you need to ask yourself this question: Are you prepared to let this happen? You are, after* *all, hoping to be serviced by many, many bulls, is letting your man fuck one slut worth it? *

* *

* *

Page 84 

**28c. Setting the scene. ** 

All day on Saturday you'll continue to wind your man up. Send him off to the shower to shave himself down but follow him in. Say "I know you were planning to have a wank in here so I've come in here to make sure you don't\!" 

Show him you have the ice cloth and teaspoon to help him get back in his cage if he wants? 

*He'll argue that he wants out of the cage, as he was the last time Ann was over, but flat refuse* *him. Say "No\! It's the only way I can guarantee you won't try to join the action\! I know you, my* *love\!" * 

*You are going to leave his key on the coffee table just before you take Ann into your* *bedroom, but he doesn't need to know that\! * 

Talk to him while you're in there. Tell him you're really nervous about tonight but quite eager and a little horny as well. Extoll Ann's assets. Say things like "Don't you think she has the sexiest lips? They were so soft to kiss\!" and "She has a really good rack on her, wouldn't you say? Her breasts were really firm to my touch." And "She's in really great shape, she obviously works out all the time. Hey\! I wonder if she's shaved 'down there'." And say "Fuck, baby" then grin, "I might just let her make love to me tonight and you're not going to get to do anything but watch\!" and laugh delightedly. 

Let him get dressed into his male mode \(make sure he dons his cock cage\) and make yourself as beautiful and as sexy as you can. Go all out like it was your very first date all those years ago. 

When Ann arrives greet her with a warm hug and a big kiss, let the kiss linger for a while. 

Take her by the hand and lead her to the couch. Sit holding her hand and giver her another kiss. 

*What you're doing here is trying to create a visual smorgasbord for your man. You want him* *so horny he loses control of himself when you take Ann to bed. * 

Ask your man to make you both some drinks and make out with Ann while you're waiting for the drinks to arrive. Keep going even when your man gets back. Wait until offers them to you, then sit back, look a little embarrassed, and say "Oops\! Got a little carried away there\!" 

Virtually ignore your hubby while you sip your drink by looking almost exclusively at Ann. 

Keep leaning in for a kiss, stroke her hair away from her face and kiss her again. Keep stroking her arm and pulling her hand up to kiss. After about 30 -- 45 minutes of doing this put your drink down say "Fuck this\! Let's get this show rolling\!" Move confidently in close to Ann so that she has to lean back. Put your hand on her inner thigh and slowly slide it up towards her crotch. Push on Ann's inner thighs so she has to spread her legs then cup her vagina. If she's knicker less all the better\! Thumb her clitoris and dip your finger into her pussy. If she Page 85 

isn't, do basically the same thing through her knickers. Then impatiently pull them to one side so you can get your hand on her pussy. 

*It's certain that your man is going to be beside himself again, this is exactly what you want,* *him thinking only with his little head and not the one on his shoulders, so put on as good a* *show for him as you can\! * 

Sit back and take both of her hands in yours. Give her a quick lip kiss and ask "Would you like to come to the bedroom now?" 

Don't give her a chance to say no, stand up and drag her up with you. At your bedroom's door tell her to take her top and skirt off and jump up on the bed. Stop your husband at the door and say "The key to your cage is on the coffee table, let yourself out and get up on the bed beside us but you may only watch\!" 

Jump up on the bed, leaving all your clothes on, and whisper to Ann "I want you to tongue me to an orgasm then straddle my hubby, guide his cock into your pussy and make him blow in you as quickly as possible. As soon as he comes grab his head and insist he uses his tongue to clean your pussy up. Let him fuck you to an orgasm if you like, he's actually very good\! 

Then you and I will get into it, properly, okay?" If she quibbles say "I need you to do this so we can play in peace, besides, you're going to love having the come sucked out of your pussy\!" 

Make out with Ann, lying side by side until you feel hubby climb up on the bed. Then flip her over, push her arms above her head, tell her to hold them there, straddle her hips and see if all the tricks you use to drive your husband to extreme arousal also work on Ann. 

*They will, I promise\! * 

Take her bra off then kiss and fondle her breasts. Do to Ann's breasts what you like having done to yours\! Sit up and strip off your top and bra then lean forward and let your nipples drag across hers. Mash your and her breasts together and kiss her passionately. Stand up on the bed and drop your skirt and knickers, throw them to the side. Shift slightly so that your foot is between Ann's legs, lower yourself down and press your thigh against her pussy. Move your thigh slightly up and down so it rubs against her clitoris. When you're sure Ann is as aroused as you can make her lie down, on your back, between her and your hubby. Pull Ann over to you and kiss her passionately again then put your hands on either side of her head and guide her down to your pussy. 

*Revel in the sensations. A woman's touch is much softer and more delicate than a man's so,* *at the very least, it will serve as a fantastic comparison point for you\! * 

Have a very loud orgasm\! 

Guide her head up so you can give her a kiss and say "Fuck that was good\! Give me a sec and I want to see if I can do you, okay?" Slide your eyes towards your husband and give her a surreptitious push in that direction. 

Page 86 

*Time to cross your fingers that your man doesn't decide to go all noble on you and follow* *through on his promise to not touch. You want him to shoot his load into Ann so you can* *emotionally blackmail him into letting you have some cock. * 

As Ann climbs on him lie on your back with your eyes closed and pretend you're not noticing that he's inside her. Play with your pussy and finger yourself groaning about how good Ann was. When you hear him come inside Ann open your eyes and look at your man. If his eyes don't meet yours make a sound so he looks across at you. As soon as he's seen that you've seen what he's doing give a bit of a buck and close your eyes again and moan. 

*He will take this as you, not only accepting he's just come in your friend, but are actually* *turned on by it \(you may well be, but he's not to know, at this stage\). * 

Once Ann has got him tonguing her clean sit up as if you've just noticed what they're doing and protest "What's going on here? I thought you," point at your husband, "were going to just watch\! Get off the bed and stand right there\!" 

Point to a spot on the floor about the middle of the bed. Turn to Ann. If she tries to say anything stop her with a "Hush\! Like having your pussy licked do you? Then let me show you how it's supposed to be done\!" 

Push her back, wrap your arms around her legs at the knees, drag her back so she is fully reclined, push her knees apart and go down on her. Give her pussy a thorough tongue lashing. Play with her nipples, finger her bottom, and tongue her taint and even her rosebud, if you can get at it. 

*In other words use all the fabulous techniques on her that you've taught your man to use on* *you\! * 

Bring Ann to as big an orgasm as you can and see if she's able to immediately go again. 

As soon as you're sure she's fully satisfied ask her to get dressed and leave because "I have to have words with my man\!" 

Turn to your man and say firmly "You wait there until I'm back\!" 

Escort Ann to the door, give her a huge hug and a kiss, and say "Thank you so much\! Sorry about that but I need to teach him a lesson, you know how it is? I'll call you soon, okay?" 

## **28d. Breaking him 1. **

Build up some righteous rage as you cross back to your man \(pick up his cock cage along the way\). Make sure that he can feel your anger as soon as you enter the room. March back into the bedroom and say something like "I can't believe you fucked her. I fucking don't believe it\! 

Page 87 

You promised me the world to get me to do this for you and 2 seconds after I've done it and I no sooner closed my eyes, and you're fucking her\! I knew it\! I fucking knew you would do it\! 

That's why I kept refusing\!" 

Hand him his cock cage firmly \(close to violently\) and say "Here's your fucking cock cage, may as well shove it up your arse for all the fucking good it's done me\!" 

If he doesn't put it on don't say a word, if he goes to put it on say with as much sarcasm as you can summon "Bit too fucking late now, don't you think?' and sneer. 

Whether he has or hasn't put on his cage he will, of course, protest that it wasn't really his fault. That Ann just kind of jumped him and he didn't mean to do it. Plus he'll say "And you looked at me when she was on me and groaned\! I thought you liked it, or at least, approved\!" 

Sneer again and say "What? When I was coming down from my orgasm and I looked to see if you had enjoyed the show? When I was at my most vulnerable because, for the first time in my life, I let a woman even touch me sexually, let alone, lick my pussy, that was when you thought it'd be a good idea to come in her? Fuck me\! I suppose me ordering you off her was foreplay as well, was it?" 

*If he's going to break it will be here so you're going to really need to ramp your outrage up. *

*Don't get hysterical and don't start to screech. Your anger must be the deeply offended,* *physical shaking kind that causes you to seethe not screech. * 

"You're sleeping in the spare room tonight. I need to think about this. Take what you need and get out\!" 

As he goes keep muttering things like "I don't fucking believe it\! 2 seconds after I let her give me an orgasm he's fucking her, I don't fucking believe it\! Why the fuck I've let this asshole play all these sex games with me is fucking beyond me. Well he can try fucking himself now, see if that fucking works for him\!" 

*Don't let him argue any further. If he tries put your hand up and say 'No\! If I say anything more* *now I may finish up saying things that are irrevocable and I want time to cool down and think. *

*Go sleep in the spare room and we'll talk in the morning when, hopefully, I don't feel like* *ripping your dick off\!" * 

Leave him to suffer until at least mid-morning on Sunday then ask him to sit at the table opposite you so "we can discuss this". Tell him "You know you fucked up, I know you fucked up so how do we get past this? I told you that you were to only watch, I even had you in your cage so you could only watch\! And what do you do? The moment I let you out of your cage you're on your back letting Ann ride you like you were a rodeo horse\!" And burst into tears. 

If he gets up to come around and comfort you put your hand up and say "No\! You don't get to touch me yet\!" Sob some more like your heart really is breaking. 

Page 88 

Take a deep breath and pretend to steel yourself. Ask him "Well? How do you suggest we get through this? Or do you even want to get through it? I suppose you just want to go off and fuck sluts? Do you even care about me at all?" And burst back into tears. 

*Still don't let him touch you\! * 

He will try to reassure you that he does still love you and that he is really sorry for 

'accidentally' fucking Ann. Interrupt him by saying sarcastically "How exactly does one 

'accidentally' fuck someone else, Brian? Was she walking along the bed, trip, fall and land with her cunt somehow wrapped around your penis? And if it was an 'accident' why were you eating out her pussy when I sat up?" 

He will say something like "I was only cleaning her up as you've taught me to do\!" Sneer at him "Sure, sure, so that was just an accident too?" Hiccup and give a couple of hitches as if you're stifling back tears. 

Demand of him again "So how do you suggest we get past this?" 

Hopefully he will offer to let you have sex with another man so that you're even. Pounce on this and say "So now you want me to act like a slut too? How the fuck does me cheating on you for fucking some bitch make us even? Two wrongs don't make a right, Brian\!" 

Say "I've got to get out of the house so I'm going out. Don't wait up as I'll be home late, I think." Sneer at him "Maybe I'll come home with a pussy full of come for you to eat out, would that make us even, Brian?" 

*You need to stay out until at least your normal bed time. Do not answer the phone or reply to* *any texts. * 

*Feel free to call Ann and go over and have sex with her. * 

*This is part of realising that you're allowed to have sex when and with whom you like. It's just* *not time for your man to find that out yet\! * 

When you get home he'll probably come out to see if you'll let him talk to you yet. Just say 

"Come to check if I have a pussy full of come, Brian?" Pull up your skirt and pull the top of your knickers down. "Well? Do you want to check?" Sneer at him again "No I haven't, one slut in this house is more than enough\! Now leave me alone I need to sleep, I've got work tomorrow." 

Page 89 

**28e. Driving his guilt home. ** 

Do not contact him and do not respond to any texts from him. If he tries to call, don't answer. 

That evening when you're both at home he will probably try and talk to you. Just put your hand up and say "I'm not ready to talk yet, Leave it be." 

If he tries to insist round on him say forcefully "I find myself finding reasons to stay, do you want to piss me off so I start finding reasons to leave?" 

Make him stew until at least Wednesday. 

*No later though. You don't want him to give up and move out\! This is all just an act,* *remember? It's just so that he'll agree to Abby visiting again and you can get him to fuck her* *so you can get his transformation moving more quickly. * 

When it's time to sit him down look at him seriously and say "You know I love you, right? 

That's why it hurts so much that you didn't keep your promise to just watch. I would like us to continue, but you, my dear, are going to have to work hard to prove that you're worthy of my love and forgiveness, do you hear? I don't want to hear you whine when I want you to try and do things anymore\! You'll merely say 'Yes Mistress' or 'Yes my Queen', do you understand? 

I'm going to invite Abby over again and you and she are going to play\! Maybe if I see you two playing together it won't seem so bad\! Agreed?" 

*This is to completely break him. If he doesn't break here it's done and your marriage is* *probably done as well. * 

*I did tell you it led to complications\! * 

*But, if you want a completely submissive, cock sucking sissyboi this is the risk you take\! * 

*At the end of the day, what choice has he got? There's little chance he's going to find* *someone like you that 1\) likes sex. 2\) Loves playing sex games as much as you do and 3\)* *Lets him have so many delicious orgasms? * 

The below assumes he folds and agrees that you're in charge. 

## **28f. Breaking him 2. **

Take him to bed, hand him his cage \(if he isn't already wearing it\), and make him use his tongue to bring you orgasm. Once you've come instruct him to put on his baby doll nightie, stockings and highest heels and meet you in the lounge. When he comes out to you make him lie at your feet then put your feet on him. Say "There's a good little slut, be mama's foot rest." 

Page 90 

*You're making him conform to his new role as your submissive. * 

Keep pushing him over the next few weeks to force him to accept his new role. You will no longer be 'winding him up' you'll be using him to get yourself off. Make him use his tongue every day to bring you to an orgasm. Once or twice a week have him put on the strapon and lie on his back, not moving, then ride that 'dick' to as many orgasms as you can stand. 

*If he starts to show any kind of resistance you need to crush it brutally immediately. Remind* *him it was inability to keep his dick out of Ann that has brought him to this place. But hint that* *you're liking him in this new role and you think that, eventually, you might want him to be your* *husband and be your equal again. * 

*You do. Ideally he will be your sissyboi when you're entertaining bulls and your husband,* *Brian, the rest of the time. * 

Once you're certain he has accepted his new role tell him, matter-of-factly, that you've invited Abby around on Saturday and that three things were going to happen. 1\) He was going to allow Abby was going to suck his cock openly. 2\) He was going to suck Abby's cock and enjoy it and 3\) Abby was going to fuck him. Explain that the thought of him doing these things actually has you quite turned on and you think it will help you to get past the fact he'd fucked Ann. 

Here is where this scenario joins in with 25v from the first scenario. You're now at the same place. 25v to 25y will be a little different as the 2 scenarios require slightly different things in the lead up to getting your man to not only fuck Abby in the ass but to allow her to fuck his. 

On the day Abby is to arrive dress as sexily as you can and have your strapon and a prostate massager for him somewhere handy, but out of sight, in the lounge. 

*At this point of his conversion your man is very close to being what you want. A submissive* *cock sucker that only lives for your pleasure but he's not quite there yet so let's push him right* *over the edge\! * 

*Be aware, though, there is a big difference, for a man, between 'coming in a cross dressed* *male's mouth or ass to relieve his sexual tension and 'allowing that same male to use his* *mouth or ass to reciprocate that pleasure'. It's an ever bigger step for him to actually enjoy* *being used for a male's pleasure. * 

The below follows directly on from 25y. Read 25v to 25y to make the following make sense. 

## **29. Merging the two scenarios. **

Once you have your man bubbling along again keep a firm grip on his dick and say to him 

"Well, I've had some, you've had plenty, what about poor Abby? I bet she would love to come too. I think we should help her out, don't you?" 

Page 91 

Don't give him any choice. Lead him by his cock up the couch to where Abby is and make him kneel with you at her knees. Pull Abby's briefs all the way off and tell her to undo her cock cage. As her cock springs out take it in your hand and stroke it. Turn to your man and kiss him. Then, with your other hand behind his head, bend over and take Abby's cock in your mouth, drag his head down so it's against yours as you do this. Deep throat Abby then lift up so her cock slips back out of your mouth, swirl your tongue around the head then kiss your man again. Repeat this action twice more, on the third time back to the head of Abby's cock tilt your head so your lips are now along her shaft and press her cock against your husband's cheek. Lean back and whisper "Suck it, baby. You know you want to\! Your dick is rock hard and leaking pre-cum so go for it\!" 

*You're at one of those critical moments here. If he's gone soft he's obviously not into it but* *you're still going to have to make him suck on that cock. If he's going to lose it it will probably* *be now so be prepared\! If he does it willingly or even eagerly you've won\! So let's hope he is* *rock hard, right? * 

If he refuses to take Abby's cock in his mouth you need to go total Dominant Mistress on him. 

Demand "You will suck that dick, my little Becky Cockslut\! This is what you agreed to so I didn't kick you out on your ass." 

Assuming that is the scenario you are in or... 

"You will take it in your mouth, Becky. Mama wants you to be a good girl\! Fuck it's going to be so hot. I'm going to rim your ass as soon as you've swallowed her\!" 

If you're in the first scenario. 

Once he's sucking on Abby's dick you want him to get so hooked up on his own impending orgasm he \(kind of\) forgets what he's doing and starts to get into it. Start by wetting your index finger and rimming his rosebud. As soon as he starts to either moan at you rimming him or is pushing his ass back at you, grab the prostate massager you had secreted earlier and slip it into his ass. Take hold of his dick and tell him to "Hump my fist, you little slut\! Mama knows what her Becky girl needs\!" 

Don't let him come\! He'll lose all interest in sucking Abby's dick\! 

Page 92 

Talk to Abby "You're not to come yet, bitch\! You wait until I say you can\! 

As soon as can tell your hubby is about to come remove the probe pull him back off of Abby's dick, grab his cock, sit on the couch and pull him down so that he's kneeling on the couch between your legs. Instruct him to "Lower your ass, my little Becky Cockslut, Abby's going to have some use of your man cunt\! Now lick my nipples and prepare to receive\!" 

If he tries to resist hiss at him "You'll fucking do it or you're done\! Besides you love me fucking you with my strapon and this is no different\!" 

Say to Abby firmly "Fuck this slut's man cunt, Miss Abby, teach him how good it feels to be used like a slut\!" 

Keep making your man adjust his position until Abby's dick hits his prostate then grab his cock and tug on it with a firm grip and gently pull back and forth on it so you're stretching the skin, not sliding along the shaft, and make him come just as hard and as quickly as you can. 

When you're sure he's at the point of no return yell at Abby "Come in her ass, Abbs\! Fill this slut's ass up with come\!" 

As soon as they've both come order them both up on their knees on the couch with their asses lowered because you're going to "Fuck both of my sexy girly boys' cunts\!" Put on your strapon and peg them both, back and forth \(about 4 -6 thrusts into each alternatively\), instruct them "When I'm in your man cunt you're to move so my 'cock' hits your prostate\!" Fuck your man to another orgasm. 

If the 'cock' is scraping across his prostate he'll come again no matter how empty his balls are. 

Page 93 

Once your hubby has shot his load again tell Abby to lie on her back on the floor, get her hard if you need to, and straddle her and guide her 'boy clit' into your pussy. Then ride her until you have come and she has shot her load into your pussy. Roll off onto your back, spread your legs, and tell your man to "Hurry up and clean me up, you come eating slut\!" 

As he licks you clean try and 'push' Abby's come out of your pussy \(similar to what you had to do when pushing your children out\) and see if you can't give him a nice juicy load of 'cream pie' to clean up. 

When you're cleaned up forcefully tell them "You two are sleeping together in our bed tonight. 

Becky, take Abby into the shower and help her clean herself up then let her clean you up. 

Once you're totally clean, your men's pussies had better be spotless so clean each other's, Becky give Abby one of your nighties. Put your cock cages on the bed side table, pull the quilt and top sheet back and jump up on the bed. No arguments\! Off you go." 

Once they start towards the shower say "Oh, and girls?" When they look back at you say 

"You may play with each other as much as you want in the shower and when you're in your nighties on the bed." And smile lasciviously. 

Making him accept 'Abby' as his lover. 

If you have a separate shower go and make use of it, otherwise, when you see them heading for the bedroom go make yourself and your pussy as clean as you can make it then join the 

'girls' in bed. Make sure you also clean and sanitise then lube your strapon \(you're going to be using it again, soon\). 

You're hoping your man has gotten over is same sex aversion and that, at the very least, they're either kissing and being 'lesbian lovers' or are fondling each other's cock. 

Whatever they're doing you're going to want Abby to fuck your man in the ass again to confirm for him that he is now a willing cock slut for real and not just in name. 

Page 94 

Cross your fingers and hope they're giving each other a blowjob in a 69 position\! 

If they're 'playing' together when you get in the room go "Ahem\! Is this a private party or can this girl get some of that action as well?" 

If they're just lying there get up on the bed between them quickly because you want your man horny and wanting to come again asap\! So do as below. 

Give them both a big smile then jump up on the bed with them. Make them move so you can lie between them, stretch your arms out and encourage them both to cuddle into you. If they both don't immediately start to play with your breasts and/or pussy. 

WTF is matter with them? 

Look down at your breasts and say "They're not going to kiss and fondle themselves, girls\!" 

As soon as they start to get into kissing, nibbling on and fondling your breasts raise your knees and spread your legs and ask "Who's going to finger my pussy and who's going to rim my ass?" 

Let them work it out. 

Once they've got you humming guide your husband's head between your legs and instruct him to "Eat my pussy as only you can, my Becky girl\!" 

Page 95 

Move up the bed so your man can basically lie on his stomach and eat your pussy \(it's okay if he hangs off the edge from about the knees down\), and so that Abby can kneel beside you and feed her boy clitty into your mouth. Instruct Becky to place a pillow under her hips. Once Abby is hard tell her to "Go and warm up Becky's cum hole and get it ready because I want you to fuck her, okay?" 

Hold your man by the back of his head and grind your pussy into him. Press your thighs firmly around his ears and give yourself up to the pleasure he is giving you. 

FFS\! Remember that if you're squeezing your thighs together in this position he can't breathe\! 

So make sure you only squeeze for a few brief moments. You will want to grab his head firmly and squeeze your thighs for a bit longer at these two points. 1\) When Abby first puts her tongue around his rosebud and 2\) When he feels Abby's cock at the entrance to his ass. Both times say simply but firmly "Relax, baby, you know you like this and so do I\!" 

Once Abby is in your man's ass start to give him lots of both verbal and physical encouragement. Moan and say "Fuck that's hot\! You love having your man pussy filled don't you, Becky girl? Tell Mama how much you love to be fucked my little slut\!" 

Move so you can stroke his back, kiss his neck, and, if you can slip your hand under his body, lightly stroke his cock head. As soon as you can see that your man is starting to enjoy being ass fucked get off the bed, put your strapon on and get up behind Abby. Apply a generous amount of lube onto Abby's rosebud, smear it around her entrance and a little inside and make sure your 'cock' is well lubricated. Tell Abby to hold still and slide the strapon into her ass. Slowly start to fuck her and instruct her to start fucking Becky again. Build up a rhythm where you pretty much hold still as she thrusts into Becky and push into her ass as she pulls out. 

Ideally you want your man to come 'hands free' here \(where he comes from nothing else other than being fucked in the ass\). So, once you and Abby have established a good rhythm, start to 'dirty talk' to both of them again. Say things like: "Fuck you have a tight man pussy, Abby\! How tight is Becky's fuck hole? Does your boy clitty feel good in her hole?" and "Fuck Page 96 

you look so hot with a girl cock in your ass, Becky\! Tell Mama how good it feels, baby girl\! I bet you'd like to come on Abby's nice stiff clit wouldn't you, my little slut?" 

If your man doesn't quite get there before Abby comes in his ass push Abby off, make him turn onto his back, lift his knees up and spread his legs "Just like a good slut does\!" Then fuck him with your strapon until he comes. 

Pleasuring you together. 

They've now had an orgasm each so they owe you, right? Get into a classic 69 position with your husband with you on top. Take his cock in your hand and start to stroke him to hardness again. 

You're not going to blow him though, but do what you need to get him hard and wanting to come again. 

As soon as you feel his dick start to 'revive' instruct Abby to tongue your rosebud. Tell her to slip a finger into your pussy and make you come. Tell your man "Service me with your tongue, you little pussy licker, Mama needs to come\!" 

Revel in the sensation of having both your clitoris and ass tongued at the same time and let yourself build towards an epic orgasm. Keep working on getting your husband wanting to come again as you delight in the sensations you're experiencing for the first time. As you get near the crescendo turn your head back toward Abby and say "Fuck me in the ass, Abby girl\!" 

This, pretty much, should be the last 'critical/crisis' point. If he offers no complaint or resistance it's all over except for the details. If he does try to move you, or get out from between your legs, or voices some complaint hiss at him "Stay there you fucking slut\! You're not out of the woods yet\! Keep eating my pussy like a good boy should\! \(If you're in that scenario\)." Or say "Hold still, baby girl, Mama's going to make use of all the ass training you've given her\! \(If you're in the other\)." 

Page 97 

Look back at Abby again and say "You're not to come until I say I'm satisfied, do you hear?" 

After you hear her acquiesce say "When you're ready to come pull out of my ass and come all over this sluts face\! Then rub your come covered boy clit across his face and lips." 

Hiss at your man "You will clean both her clitty and me up after we've come, my dirty little Becky Cum Slut\! Mama is going to spank you if you don't\!" 

Let yourself have at least one huge orgasm, then as many more as you can stand until either Abby loses control and comes, or, you're almost completely satiated \(you'll need to be able to have or fake one more before this session is over\). 

After Abby has come and your man has completed his clean up duties pounce on him and use all of your now exceptional skills to get 'his motor running again'. When he's hard and wanting to go indicate Abby and say "You may fuck her in her boy pussy, my love\! I'm going to use my vibrator and come watching you fuck her." 

Don't give him a choice, make him fuck Abby in the ass until he come inside her, then make him clean her up, as he does for you. Use your vibrator while he is doing her to give yourself one more orgasm \(real or faked\) as if watching him fuck someone in the ass really does make you 'pop'. 

If he's still not totally converted he may go completely soft. If he does you're going to give him a really hard push here and totally break him to the bit you've had primed and ready for him since you started this journey. 

Point and laugh. "What's the matter, my poor little Becky Cockslut? Can't get it hard enough to keep up with me anymore? Maybe you're not quite the stud you thought you were? Don't worry, baby girl, Mama can take a lover or two to satisfy her needs if you're not up to it?" and laugh maliciously. 

Page 98 

One of two things will happen 1\) he'll totally collapse and say "Yes, Mistress." Or 2\) He'll snap, probably get up, pack some things and leave. 

Either way it's now done. If he stays the only thing left to do is to get your first bull over and start to instruct him how to prepare you for the huge cock you're going to be taking and how to present himself in such away so the bull can use one or both of his holes to warm up in if the bull desires. 

If he leaves, well, you have a readymade replacement right in front of you\! 

There's those damned complications I kept warning you about\! 

The below assumes that he has fucked Abby in the ass until he came. If he had gone soft and needed to be pushed you'll be able to skip over the next part. If he got up and left, why are you still reading? 

Showing him he doesn't need to be cross-dressed to enjoy sucking cock. 

Once your man has finished coming in Abby's ass tell them both to go clean there 'boy clits and pussies', put their cock cages on and come back to bed. As they walk out say, with a big smile on your face, "Or you can clean each other's if you like?" 

Lie in the middle of the bed and when your 'girls' return have Becky lie on the side she normally does and Abby on the other side. Tell your man to lie on his back, lay your head on his chest, take his hand and wrap his arm around you, take his cock cage in your hand and say "You did good today, my love. Sleep well because I'm going to want you again in the morning." 

Page 99 

Turn your head toward Abby and say to her "You sleep well, too, Miss. No groping or feeling me tonight or you're banished to the spare room\!" 

Get as good a night's sleep as you can. 

When you wake in the morning take Brian's cock cage off immediately, tell Mark to take his off as well, then use your skills to make your man hard again. As soon as he's ready to go again instruct him to form a 'daisy chain' with Abby. Him sucking Abby's cock, Abby tonguing your pussy, and you sucking his cock. Come if you can, but it doesn't really matter, you do need to make sure Abby comes in your man's mouth though \(and he swallows it all\). Do what you need to ensure that happens \(of course your man will come in yours, you're very good, aren't you? \). 

You're doing this so a little later you can point out to 'Brian' that, except for the nighty, he had just blown Mark \(or whatever Abby's real name is\) and swallowed his come. 

Getting rid of Becky and making your man admit he's a submissive cock sucking slut that loves dick in his ass and swallowing come. 

Once you've all finished coming instruct them to both get dressed in their male clothes, leave their cock cages off, and wait for you in the kitchen. Go and shower and make yourself up as sexily as you dare for a morning trip out for some breakfast and coffee. 

Ask your man to drive and tell 'Mark' to sit in the backseat behind you. As your man drives try to distract him by flashing him your breasts and lifting your knees up so he can see up your skirt to your thong. Touch your pussy and smile at him. Keep reaching over to play with his nipples and grope his dick on the drive. Encourage Mark to reach around and play with your nipples when you're sitting back. During your breakfast flirt outrageously with both of them \(not too loud and/or too obviously, cos, PDA's\! Yuck, right?\). Try to get them both as horny as you can again. Encourage them both, when there's only the three of you, to kiss you and stroke your erogenous zones. When there's no one to see let them have a feel of your breasts and allow them both to slide their hands up your thigh, under your skirt and play with your pussy \(really fun to do if the café you're at has low table cloths\!\). 

Page 100 

Enjoy the sensations and allow yourself to get really turned on. 

After breakfast find somewhere you can all go for a bit of a walk that is, relatively, quite \(it's a weekend so nothing will be totally empty\). Whenever there is a lull in the foot traffic throw your arms around them both and make them both kiss you passionately. Casually grope their cocks and see how close to coming you can make them. Walk a little away ahead of them and bend over and flash them your knicker covered ass. If there's no one about you can even pull their dicks out and give them both a both of a lick. When no one is looking bend over again and back into your man and let him dry hump you. Repeat with Mark, if possible. 

After you've got them to the stage that they're about to stick their dicks in you, and damn the consequences, tell them it's time for them to take you home and fuck you again. 

Yeah, yeah, that word. But 'fuck' is what it's going to be, right? 

Repeat the driving to breakfast experience for them both. 

Start making out with both of them as soon as you're in the door. Encourage them to strip your clothes off and to hurry up and get out of theirs. Climb up on your bed and guide your Mark's mouth onto your pussy and your man's cock into your mouth. 

Don't let him come\! Instruct him not to, if you need to. 

When you have your man fairly close to blowing push Mark off your pussy and take your man's dick out of your mouth. Say "You two get yourself into 69 and start to blow each other. 

The last one to come gets to fuck me\!" Then give a sultry laugh and say "First\!" 

Page 101 

You want your man to be the one to come first, and you've been giving him lots of edging practice, so you're going to cheat. Once you can see that your man is getting close, and before Mark loses his load, slide up behind your man, wet the first two fingers of your hand, rim his hole with the index finger then slide your middle finger into his ass and moan in his ear. Hopefully his love of having his ass played with wins over his edging practice and he blows in Mark's mouth. 

Clap your hands delightedly once your man has 'lost' and instruct Mark to lie on his back in the middle of the bed. Climb on him and guide his cock into your pussy. As he slips into you grab your man behind the head, pull his head down so you meet forehead to forehead, look at him, kiss his forehead and put yours back on his, groan and say "Fuck Mark's cock feels so good in my cunt\! Lick my tits, baby, Mama needs to come \(don't though\). 

Yes, use those exact words. Mark is not Becky and this is driving home to 'Brian' that you're going to 'slut' for other men anytime you feel like it\! And he needs to not only accept it, but eventually, learn to like it and to even actively recruit big dicked bulls for your pleasure. 

When you can tell Mark is getting close to coming, climb off him, and tell him wait there for a sec. Turn to your man and instruct him to use his tongue to prepare your ass. Once he has it well lubed tell Mark to hold his cock so it points straight up. Turn around and lower yourself down and tell Mark to guide it into your ass. Once you're all the way down with Mark's dick buried deep in your ass, lie back on Mark and spread your legs. 

Instruct Mark to keep his legs closed. Sit up a little so you can reach and spread your pussy lips. 

Just like one of those crunches you were supposed to do between gym visits\! 

Tell your man to tongue your clit for a bit and then to slip his cock in your pussy. 

Page 102 

If he's still soft, at this point, push him hard again. Say this "What's the matter, Brian? Can't get it up without someone playing with your ass anymore? Doesn't matter, Mama can still get what she needs right here\!" Indicate Mark and groan as if he's really fucking you well. 

If he hasn't already he will break at this point and either of the things described above \(in italics\) in part 31 will happen here. If he says "No, Mistress", or something similar, say that he may lie there and watch but that is all he's now allowed to do until you say different. Fuck Mark until either you're satisfied and/or he's blown inside your ass and send him home. You need to have a chat with your man. 

The below assumes he was into it and hard. 

Once he's inside you lean back and let yourself totally enjoy the well-deserved fucking you're getting. For comfort's sake you will probably want to change positions so that your man is lying on his back with his legs closed, you're straddling him with your hands on his chest, and Mark is kneeling with his thighs either side of your man's and is fucking your ass. 

Look at you go, you dirty little slut\! A dick in your ass and pussy at the same time\! Question: Would you like one for your mouth, too? 

Instruct your boys that they are not to come until you say you're ready for them to and ride them both until you can't possibly go anymore. Let them both come in you and make your man clean up your pussy and ass as well as Mark's cock. Remind him to put his cock cage on. 

Send Mark home, you need to have a chat with your man. 

The chat you have will be the same here as the one above where your man was soft. 

Page 103 

Defining his new role. 

Tell your man to wait for you at the dining room table and go shower and wash the remnants of your love making off, change into something comfortable but quite severe \(as opposed to sexy. You're going to be very much Mistress \(your name\) for this\). Take your time so he has to stew for a while. 

When you come out sit opposite your hubby and remain quiet for a bit. He will, more than likely, make one last ditch effort to regain some of the control he has seemingly all given up to you. Let him whine for a time, then forcefully interrupt him. Say "Let's lay all the cards on the table here, Brian. You're nowhere near as 'straight' as you thought you were, are you?" 

He will try to interject with a "Yes I am\! I was only playing with Abby because you wanted me to\!" 

Override him hard. "Not this morning, or indeed, last night in our bed\! It was 100% Mark you were sucking, fucking and getting sucked and fucked by\! Argue last night all you want but today it was definitely Mark that you were having sex with\! You can't argue this with me because I know, I was there\! You sucked his dick and let him suck yours so let's cut the bullshit, ok?" 

He will probably still try and argue so hold your hand up and say "The thing is I don't care\! 

Before we started on this journey our sex life was boring\! Now it's fucking awesome\! We've done and experienced so many things that have been fantastic\! And, we're going to continue. 

Actually, I'm going to continue, you can continue with me, or not, but, if you choose to stay, there's no more selfish, uncaring, only gets what he wants, Brian\! There is only what you have been for the last \(however long it's been\) my caring, looking after me first, sometime 'Becky' 

husband who puts my needs before his 100% of the time\! 

This needs to be said, Brian so here goes. Before we started all of this I really wondered if you actually liked sex with me, or any woman. You just seemed to want to hurry up and shoot your load so you could get it over and done with. I wondered if you weren't, at the very least, bisexual, if not actually gay\!" 

Page 104 

He will definitely protest here. 

Say "FFS Brian\! How many times do I have to reassure you that you're obviously not gay? No gay guy could have done me as well and/or as often as you have over this journey\! But it's time to admit to yourself, as well as to me, that the only way you can have a truly good orgasm is when someone is in your ass\! How many 'straight' guys need a tongue or finger or cock in their ass to achieve a proper orgasm, Brian?" 

He will whine "You did this to me\! You made me a cock sucker\!" 

Reply "Did I Brian? You could have stepped out of this anytime you wanted to. Think back, my man, I offered to let you out of it any number of times\! No, my love, you were a more than willing convert to all of this because you were finally getting what you needed to orgasm totally and exquisitely. Let's face the facts here... Know any of your married friends or workmates whose wife not only lets them have sex as often as I do you but loves it and joins in as wholeheartedly as I do?" 

If he's honest he has to shake his head here. 

Follow up with: "I need you to tell me you want to stay and that you want to continue with these games. I want you to say 'I accept that you're my Mistress and that I live only to serve you'. If you're not prepared to accept these demands, and make this promise, you can pack your bags and go\! I'm not fucking around here, Brian. I need my man but I need to be 100% 

certain that you're never going to backslide into the 'old Brian' ever again\!" 

The previous hard pushes you have given him should have crushed him into a place where he can't refuse you. 

Page 105 

As soon as he has made the vow walk around to him, sit on his lap, kiss him and say "Thank you, my love. Mama will look after you, I promise\!" 

Congratulations\! You've taken a 'strong independent alpha male' and turned him into a cock sucking sissy\! 

And last. Taking your first bull. 

After he has made the vow say to him "To show you how much this means to me, babe. 

Follow me." 

Tell him to grab a rubbish bag and follow you into the spare room. Start to dump all of his 

'Becky' clothes into the bag \(keep a couple of your, and his, favourite outfits including a pair of heels, just in case he'd like to dress up again for 'old times'' sake in the future\) then go into your bedroom and remove all of his women's undergarments except for a collection of about 3 

-- 5 of his sexiest and smallest thongs \(these are what he'll wear when you're entertaining a bull\) and get his old men's undies out. 

Once everything is in the bag have him sit beside you on the bed, hold his hand and say forcefully "Two things, Brain: 1\) you will remain clean shaven from the eyebrows down. 2\) The cock cage stays on except for when we're having sex\!" 

Say it with absolute conviction you will be obeyed. 

Make him repeat what his two ultimatums are and agree to them. Once he has, say "Good boy\! Mama, and you, are going to have so much fun\!" 

Take him out for the day and do the usual mundane things, do a bit of shopping, get some lunch. There's going to be a small difference though. If you see a hot looking girl nudge him and say "There's one to perve on, babe, wonder if she's got knickers on?" 

Page 106 

When you spot a guy that you think is hot also nudge your man and say "He's hot, don't you think? Wonder if he's gay or bisexual and would like to come and play with us? Do you think he has a big cock? Should we ask him?" And laugh. 

This is confirming to him that things have changed. You're going to open about your sexuality and, if you find a man \(or even a woman, if you enjoyed 'playing' with Ann\) attractive, you're going to consider them potential sexual partners. 

Throw all of his Becky clothing into good will while you're out. 

When you get home take him straight to bed, let him remove his cock cage then make him service all of your sexual needs before putting the strapon on and fucking him to orgasm. 

Yes, I know I said to 'never make him come' but you've won so the 'rules for conversion' no longer apply. You may even let him make love to you between bulls occasionally, but keep an eagle-eyed look out for any backsliding, and jump on it immediately. 

Earlier I made mention of finding out which of his mates and work colleagues found you hot but you should be very wary of selecting someone from either of these categories as a lover. 

Cuckolds can very quickly become the object of ridicule and scorn if their predilections become common knowledge. 

So unless you're sure of their discretion and/or you know for sure they're bisexual and will also use your man \(so you have the threat of dropping them in it as well if they want to blab\) avoid playing with anyone from either of these categories. 

Give it a couple of weeks until he settles into his new role and accepts you in yours and then login to your 'kink site'. Instruct him to come and look with you. You're going to look for Page 107 

someone, with as big a cock as you think you can handle, to start the next part of your sexual journey. 

There will be no shortage of guys with 'dick pics' as there profile pic on their shell profile \(shell profile: little in the way of real information or content filled in\) ignore all of these. They're going to be about 99% fakes who only want to wank to the fantasy and will never commit to a meet. 

What you're looking for is someone with the confidence \(and smarts\) to put a face pic up. 

Somebody who has taken the time to write a decent introduction and has listed what they're looking for clearly. He needs to be 100% bisexual \(no room for 'curious' or 'wanting to try'\) contact him and initiate a chat. 

Trust me he'll be so shocked that a woman is contacting him that he'll probably doubt you exist. He'll be sure that there's a 'sissy' but will doubt there's a Mistress\! 

Use the same process as described above where you 'recruited' Ann into your scheme. 

Exchange some basic texts, Exchange phone numbers, and chat. If it feels right try some 

'flirtatious chat' then, if that goes well, invite him over for nothing more than a drink and a chat. 

Emphasise it will be for nothing more than that the first time. 

You want someone who is in control of themselves and their lusts and libido. If they're not, they may be fun later if you want to be well and truly 'fucked', but they're no use to you now. 

For the meet you want to dress yourself as sexily as possible, full make up, etc. Your man is to be present when you meet \(let's call him\) Phil. Make sure there is a definite attraction between you and Phil. 

In blunt terms, you not only want to fuck him but he wants to fuck you. 

Page 108 

If the attraction is there arrange for Phil to get an STI check and email you the results. 

You're going to bareback with him so you want to know he's clean. It's a bit blunt, I know, but this is 2023, babe, you can't be too careful\! 

As soon as you have the results arrange for Phil to come and see you to 'play' on a Saturday night. 

In preparation for Phil's visit you'll need to purchase an 'O' ring for your man and a douche kit \(also for him\). On the Saturday afternoon, about an hour before Phil is to arrive, have your new sissyboi prep you to take Phil's bigger cock. Start by making him use his tongue and fingers to 'warm you up'. Once you're buzzing along have him lube the butt plug that approximates Phil's dick size then have him tongue your clit as he inserts one, two, and then three fingers into your pussy. Once you're ready have him slowly insert the plug into your pussy. Make sure he is tonguing your clit as he stretches you. 

Repeat the process with your ass. 

Once your sissy can slip the plug into both your ass and pussy without any discomfort send your sissy to the bathroom to shower, shave down and douche his anal passage. Have him lube and stretch his ass with the same plug that he used on you. Then instruct him to put on his thong \(he should have put his cage on as soon as he got out of the shower\) and to come wait with you for your bull to arrive. 

Phil is going to have his dick in your man's ass and then in your pussy so you need to make sure your man's ass is clean \(for obvious reasons\). 

When he comes out from the shower bind the 'O' ring into your sissy's mouth. 

Page 109 

On Phil's arrival send you sissy to kneel toward the head of the bed, on your side, with his head up, eyes down and his hands clasped behind his back. 

Greet Phil with a big hug and a kiss and set about using all of your finely honed skills to make him as turned on and desperate as you can as quickly as possible. 

He's here to fuck you, not engage in small talk. 

Tell Phil that your sissy is kneeling in the bedroom and that he is to use your sissy's mouth and/or ass to 'warm up' in because you want to feel his come splashing in you as soon as possible. 

Lead him to the bedroom and climb up on the bed. Instruct Phil to "'Face fuck' this sissy slut\! 

He's only new so feel free to gag him with your cock and make him choke. Use his ass if you want\!" 

Lie back and enjoy the show. Phil won't want to come in your sissy so he won't use him for very long. 

When Phil climbs onto the bed spread your legs, encourage him to get between them, and guide him into you. Revel in the feeling of being even fuller than the strapon your man used to fuck you with. Give both Phil lots of verbal encouragement to fuck you as hard as he can. Try to have at least two extremely loud orgasms then, before Phil blows, get him to lie on his back, straddle him, take his cock in your hand, lean forward so you can watch and lower yourself onto his dick. Exult as you see and feel that big, ramrod stiff, dick slide into your nether regions. Ride him to another orgasm. Then encourage Phil to "Come inside this hot pussy, stud. Fill me full of your man juice\!" 

As soon as Phil has finished blowing climb of the bed, straddle your sissy's face and hiss at him "Clean Mama's pussy, you fucking slut\!" 

Page 110 

He'll have difficulty complying because the 'O' ring will be in the way. So, when your sissy has cleaned as much of Phil's come up as he can, get back on the bed and see if you can't get Phil hard again. If he can, tell your sissy to hand you the lube from off your dresser, grease Phil's pole up, lie on your stomach, with a pillow under your hips and tell him to fuck your ass. 

Instruct him to be gentle until he's all the way in and you tell him to go. Once you've gotten used to Phil's extra length and girth tell him to 'give it to you hard'. Ride his cock to another orgasm and get him to blow in your ass. 

As soon as Phil has blown a second time send him home. Take the 'O' ring out of your sissy's mouth and release him from his cage. Make him use his tongue to clean Phil's come out of your pussy and ass. Once you're clean put your strapon on and fuck your man to an orgasm. 

As he moulds to his new role releasing him from his cage long enough to have a wank will be is as far as you will go. 

Epilogue: The obvious question is "Will the above work?" 

The short answer is "No, probably not\!" 

Now don't get me wrong here the above is a very good starting point for you to use to sissify your man. But to follow it step by step and word for word? No, there's too many variables at play here and I've made too many nested assumptions that your man will react a certain way. 

I have no idea whether he will or not as I haven't met him\! The excuse to get him to wear women's clothes is weak and the reason for making him become more and more feminine needs to be stronger, you'll need to work on and adjust these parts to something you think your man would buy into. A tactic that may work is to simply state that having him dressed enfemme turns you on and the more femme he gets the more turned on you become \(hard not justify not taking a woman lover on this track though\). 

Page 111 

If you want to try to turn your man into a sissy, using this, or some other method, the key parts are getting him permanently locked into a cock cage and to then keep him perpetually horny and frustrated with the only relief he gets is when he's taken another step towards being your sissy \(you must never let on this is your goal until the deed is done\). 

The longer answer is "Maybe." 

Page 112 

****

**The Sissy **

**Ownership **

## **Guide **

****

\[play safe, sane and consensual\] 

*January 2023 – Ver. 1.1* 

****

****

****

****

This is a fantastic piece of writing about the psychology of sissies and what motivates, excites them and how they can be effectively managed. It’s complicated subject and this article sums it up so well. A must-read for any sissy male and their partners looking \(and indeed submissive males turned on by feminisation and humiliation\) to understand why sissies tick the way they do, and how they can be trained to be the best that they can be. 

## **1. Introduction **

While this guide will hopefully be useful to anyone interested in the idea of owning a sissy, a primary goal in writing this is to introduce the idea of sissy ownership to people who are relatively unfamiliar with the concept. Chances are, almost regardless of where you are, there is a potential slave near you who would love nothing more than to be allowed to serve you. And while the seemingly crazy psychology of these extremely submissive \(fe\)males might feel complex initially, there really are some basic guidelines that will make bringing one \(or three\) into your life very enjoyable. 

If you’re sitting at your computer right now, a bit bored, a little horny, but not feeling like going out…a sissy could be perfect for you. In most situations, a sissy won’t replace your primary companion, but they can be a great addition. If you’re a guy, chances are you’re considering whether or not to get a quick fap in tonight before bed. Instead, have a sissy on call. She could be under your desk softly sucking your cock right now as you read. 

Ladies, you might love the same kind of attention, or opt instead for a long massage. 

No one is more obedient and eager to serve than a sissy, and there are generally no strings attached whatsoever. Have her rub your feet and make you dinner, then tell her to do your dishes and clean up the kitchen before sending her home. 

Sound perfect? It’s pretty close. 

Page 2 

**2. Finding the Right “Girl.” **

Sissies are everywhere\!\! If they weren’t such pansies they would have taken over the world by now. If you already have one in your life you can skip this section, or maybe you want to add a few more to your stable… 

While there are a handful of personals sites geared towards this scene, chances are you will have even better luck putting a post on Craigslist or Fetlife. Generally, sissies aren’t the boldest bunch, so post your own ad instead of waiting for one of them to create a listing. 

Be detailed about what you’re looking for. How often do you want them to be at your house? 

What services are required? What kind of appearance would you like? 

From the very first communication, be direct and confident. You’re in charge. If that bothers them they can get lost. You’re looking for a gurl who will be obedient and responds well to your authority. 

Appearance is, of course, important, but focus initially on attitude. An obedient gurl with a strong desire to please will work hard to look how you want her to if you give her a little time and practice. A lazy sissy who is just looking for a quick thrill will only waste your time. 

Your first meeting can be in public if she’s uncomfortable coming directly to your house, but regardless, you should be confident and in charge from the moment you meet. At no point are you equals. How you want her to greet you is up to you, but something along the lines of a polite bow and curtsey \(or kneeling if in the privacy of your home\) are a good idea to set the correct tone immediately. 

If you establish from the very beginning that you are in charge, you will also avoid the awkwardness that often occurs when someone makes the mistake of initially greeting someone as an equal and then having to make the transition into dominant/submissive mode with them. 

Page 3 

**3. Inside Your Sissy’s Mind **

At the heart of every sissy’s psyche is a need for sexual humiliation. They are most aroused by acts, words, and situations that are unpleasant and degrading. One part of them is irresistibly drawn to things that another part of them finds very distasteful. 

It’s a counterintuitive paradox that can be a bit challenging to get your head around at first, so I’ll give a few examples. 

Most sissies would consider themselves at least mostly heterosexual, and in general are less attracted to men than to women. However, the very fact that they find sexual acts with men undesirable or possibly degrading also makes those acts very arousing because of the humiliation they entail. 

Another example is physical discipline. The sting of a paddle itself is in reality unpleasant, and it’s only because of its unpleasantness and humiliating nature that so many sissies are drawn to it. 

Confusing, right? 

Don’t worry, you don’t need to fully understand or try to relate in order to have a great time with your sissy and give her exactly the treatment she craves. 

For most people, the biggest initial hurdle to overcome is a sense of guilt as you learn to interact with her. It’s hard not to feel a little bad as you relax on the couch while she works diligently at scrubbing your bathroom; especially since she gets no tangible reward whatsoever for her efforts. 

But the key here to remember is that while she is not receiving any payment or physical reward, you are giving her something infinitely greater; something that she could never obtain on her own. 

This leads into a key question…what exactly does she want? 

And here lies a problem. For most sissies, explicitly telling you exactly how they would like to be treated will make the relationship feel as if they are in control; that they are calling the shots. They need you to be in control at all times. 

Page 4 

If they have a blog or other journal, this can be a backdoor way to see the kind of relationship that most appeals to them. Or have them write out what their ideal situation would look like. 

But in all this, don’t bend too far to try and appease their fantasies. Fundamentally, this is about you and what you enjoy. Their entire role is to be relegated to being a servant whose sole function is to attend to you and make your life pleasant. 

## **4. Setting the Ground Rules **

Owning a sissy doesn’t need be complicated or require a huge amount of preparation, but having a few basic principles in place will set a great foundation for a rewarding experience for both of you. 

If you only remember one thing in this chapter, make it this one: as soon as a sissy cums, she instantly becomes almost entirely useless. As bizarre as it seems, your sissy is a completely different person ten seconds after an orgasm than she was ten seconds before it. She will no longer be genuinely interested in serving you, and will obey only out of a sense of duty. 

You need to control her orgasms. This may not sound especially exciting, depending on your personality, but this small bit of effort on your part is absolutely critical to a having a useful sissy. 

At first she may be obedient and abstain from touching herself, but in the long run the only real solution is a chastity device. These can be a bit of a hassle, but make that her problem. Have her research and buy her own device. There’s a fairly good chance she’s already interested in the concept, and she may already have a few devices available. 

The security of these devices vary. The more casual ones are sufficient at first, but if your relationship with her shows signs of lasting, you may eventually want to have her graduate to a device that utilizes a piercing or urethral rod. With these she will be completely at your command and unable to escape. 

Again, don’t let a sense of guilt alter your behaviour towards her. She will be desperate to cum much of the time, but will gradually adjust to living in a constant state of sexual frustration; Page 5 

excited to be your sissy and eager to please. Orgasms should be very special treats - only permitted in special circumstances, and only when you know you will not be requiring her services for a day or two as her submissiveness returns. 

Be clear about your desires in regard to appearance, and don’t be afraid to discipline if she fails to comply. Most owners prefer a sissy shaved smooth from her neck down. Many also want their gurl slender, so weight goals and consequences for failure to meet them can be effective. We’ll cover some of the easiest ways to discipline your sissy in a future chapter. 

If you want her as feminine as possible, make that clear from the beginning and don’t be afraid to punish if you deem her efforts insufficient. Keep in mind that there are limits, and sissies are rarely exceptionally attractive as either males or females. Just make sure she knows what you like and dislike, and that she’s making every effort to meet your tastes. 

Sissies will often have a particular attire they are attached to. It’s a good idea to be somewhat accommodating to their fantasies in this regard, but be sure it’s something you also find at least somewhat appealing. Clothing tends to reflect extreme femininity because of it’s emasculating nature, increasing the humiliation of their situation. Have her try french maid costumes, lingerie, pleated skirts and stockings…anything overtly feminine that you would enjoy seeing her in. 

## **5. Making Her Useful **

Modern society has evolved to stigmatize creating overt luxury for one person at the expense of another, but sissies are one of the few groups of people who seek to live outside that norm. As their owner, you are merely granting their wish to be taken advantage of. 

First off…sex\! 

You don’t ever need to have any feeling of self-consciousness or fear of rejection. With a sissy you are free to be fully yourself, telling her exactly how you want to be treated. Be selfish. Be lavishly, unimaginably selfish. 

Page 6 

Ever wondered what it would feel like to have your asshole softly licked? Ever had the desire to fuck someone’s throat and watch the mascara run down their cheeks as they gag? How about having your pussy worshipped while you watch tv? 

Be honest with yourself as you experiment. Your sissy will thrive on your genuine enjoyment and satisfaction. 

Don’t ever feel a sense of pressure though. If all you want is a foot rub, all she gets to do is give you a foot rub. Sex should never be work for you. 

And even though this has already been covered, I’ll say it again: don’t let her cum. Her satisfaction comes from being allowed to pleasure you. We’ll cover a little later some ways that you can occasionally allow her a sexual reward, but for the most part you are the only one who gets to have orgasms. Lots and lots of orgasms. 

The other most common use for sissies is domestic chores. 

Never politely ask a sissy if she would like to complete a task for you. This makes her feel as if she is your equal and is doing your housework of her own volition, making it drudgery. 

But if you firmly command her to do something, she will tingle with submissive excitement as she works - especially if she knows there will be consequences if she fails to do the task correctly. 

The more humiliating the tasks the better, and whenever possible point out to her that a real man would never obediently do these demeaning tasks. Depending on your situation, a sissy may eventually be able to handle the majority of your domestic tasks…laundry, cooking, dishes, cleaning. 

If you have her perform a task that has a “masculine” perception, such as mowing the yard, be sure she does it in very feminine attire. Of course, whether or not you want the neighbors seeing a ballerina mowing your grass is up to you. 

Page 7 

**6. Discipline **

There are two kinds of discipline when punishing your sissy, with a bit of grey area in between. 

The first is largely symbolic; meant primarily as a means of reminding her of her place. The second is meant to be more purely unpleasant and is used to alter her behaviour directly. 

Let’s start with the first kind. 

The symbolism of obediently lowering her panties and bending over is psychologically powerful. 

It’s a physical sign of deference, and as she looks at the floor with her bare ass in the air, her submissive sissy psyche is fully engaged. 

For this reason, it can be a good idea to perform “maintenance” discipline very regularly - even if not merited by any specific behaviour. There are few more effective ways to click her into a submissive mental state. 

Implements to be used in this case should be only moderately painful: hairbrush, light crops, belts. 

The pain level should be adequate to make her squeal a little, but stop short of bringing tears. 

Allow some space for creativity. Anything you can think of that sounds humiliating will be perfect for this type of discipline. Make her stand in the corner with her nose to the wall for twenty minutes. \(This feels like forever, trust me.\) Have her kneel and give one of your doorknobs a richly-deserved blowjob. Gag her and lock her in a dog kennel. Have fun, and be sure to document with photos so she can relive her humiliation later. 

The second kind of discipline is meant for genuine behaviour modification, and if done correctly shouldn’t need to be carried out very often. The threat of this kind of punishment if she fails to be on her best behaviour should be looming in the back of her mind at all times. With the correct incentives in place, a sissy will be remarkably perfect in her obedience. 

More severe spankings can work for these kinds of discipline, depending on their pain tolerance. 

Opt for more painful implements, such as a cane or paddle with holes. She should have tears running down her cheeks by the time you’re through with her. If you have nearby neighbors, a gag is probably a good idea. 

Page 8 

A method requiring less effort is to have her tuck her little testicles back between her legs as she bends over, and then swatting them with a ruler. You will be impressed by how little it takes to get a sissy squealing and promising to change her ways with this method. 

But the easiest punishment by far is simply adding time until her next release from her chastity device. Tell her you’re about to add a week to her time in chastity and her attitude will immediately adjust dramatically. Remember, she’s desperate to cum, and will do almost anything to avoid lengthening the time until her next release. 

If the idea of having to discipline someone sounds tiring to you, stick to using just this method. It’s extremely effective and requires minimal effort on your part. 

There is a myriad of other potential means of punishment to keep your sissy on her best behaviour, and her personality and tastes will largely dictate what will be most effective. 

Experiment, watch how she responds, and enjoy making her squirm and whimper. 

You’re the boss\! 

## **7. Rewards **

A sissy’s life shouldn’t be entirely without little selfish pleasures, although they should be very rare compared to yours. Although they do require a small amount of effort on your part, properly spaced rewards will keep your sissy incentivized and even more eager to please. 

Her single biggest treat will more than likely be the occasions she is allowed out of chastity. Make sure her next release date is on the calendar, and keep up with moving it later or earlier based on her behaviour. This date will be etched in her mind at all times, as her frustrated little penis squirms inside its prison. 

The last thing you want to do though is to just allow her to run off and privately masturbate as soon as she is free. While some sissies can handle this, many will have waves of guilt and echoes of masculinity surge immediately after masturbating. For their own good, you must ignore their pleas to be allowed to touch themselves freely. 

Page 9 

Her only orgasms should be “ruined”. A ruined orgasm is essentially one in which pleasant stroking contact is not present, allowing the cum to ooze out without the intense sensations and emotions of an orgasm with full stimulation. This will leave her feeling somewhat relieved, but if done correctly she will still be slightly horny and unsatisfied. Her sissy psychology will hopefully remain at least partially intact. 

Give her the key to her chastity device and allow her to unlock herself. Make sure she knows the consequences will be extreme if she is in the least bit disobedient during this process. 

Once unlocked, restrict her hands with cuffs or cable tie behind her back. 

From here there are a few different options. 

The easiest is to use a vibrator and hold it against the underside of her penis, right where the head meets the shaft. Verbally humiliate her while you hold it there. Tell her this is the only kind of orgasm a sissy like her gets to have, and tell her to hurry up and shoot her little load. The more you can get inside her head with your insults, the quicker this will go. Of course, if you’re enjoying yourself, take your time and even pull the vibrator off when you think she’s getting close to cumming. If you’re feeling especially cruel you can put a time limit on the “treat”, and she goes back in chastity once times expires regardless of whether she has been able to cum. 

If she cums from this method, simply pull the vibrator away as soon as her orgasm begins. The cum will still ooze out, but you will have successfully ruined it. 

The more “hands on” approach is to give her a traditional handjob and pull away as soon as she starts to cum. This technique isn’t nearly as foolproof though. It’s very easy to stroke just a little too long, giving her a few seconds of “thrusting” orgasm. Even if you let go halfway through this kind of orgasm, she will still have felt the hormone surge and will likely not remain in her sissy mental state. 

Whether or not a sissy should ever be allowed a satisfying orgasm is a matter of debate. I personally like the idea of sissies being allowed one full orgasm annually on their birthday or allowing them one un-ruined orgasm for every one hundred orgasms they give you. This has the added bonus of keeping her extremely excited for opportunities to pleasure you. 

Page 10 

333 Sissy Rules 

- The Comprehensive List of Rules for Sissies – 

\[play safe, sane and consensual\] 

*January 2023 – Ver. 1.2 *

1. 

A sissy does not have a dick you have a clitty 

2. 

A sissy should always wear lingerie 

3. 

Sissies belongs on their knees with their mouth open 

4. 

A sissy will always swallow and say thank you 

5. 

A sissy worship all Alpha males 

6. 

A sissy clean up – this their your duty 

7. 

Sissies love cum and adore their own cum 

8. 

A sissy is always ready to be used 

9. 

A sissy mouth is for sucking, not talking or singing 

10. 

A sissy hole should always be on display 

11. 

A sissy must always please 

12. 

A sissy will always wear easy-access panties so they can be plugged 13. 

A sissy does not have a cock. A sissy has a clitty 

14. 

A sissy wears a bra and panties 

15. 

A sissy loves cock 

16. 

A sissy loves cum 

17. 

A sissy takes it in the ass 

18. 

A sissy loves pink 

19. 

A sissy loves her toys 

20. 

A sissy dresses like a slut 

21. 

A sissy shares 

22. 

Sissies love facials 

23. 

A sissy must have a tight ass 

24. 

A sissy must have perfect bimbo makeup 

Page 2 

25. 

A sissy grows big fake tits 

26. 

A sissy is a pro cock sucker 

27. 

One is not enough 

28. 

A sissy belongs on her knees 

29. 

A sissy doesn’t forget to practice 

30. 

Sissies swallow 

31. 

A sissy begs for it 

32. 

A sissy will fuck anywhere 

33. 

Sissies loves to plug 

34. 

Every sissy dreams of being a bimbo 

35. 

Cum is your reward 

36. 

You are a tool used to please cock. Every cock. 

37. 

You prefer Big Black Dick 

38. 

Sissies loves garters and stockings 

39. 

Sissies loves a good gloryhole 

40. 

A sissy loves the taste is own cum 

41. 

Woman is superior to sissy 

42. 

A sissy doesn’t have a boyfriend, a sissy has a master\(Daddy\) 43. 

A sissy doesn’t have a girlfriend, a sissy has a mistress 

44. 

Sissies bend over 

45. 

Sissies love heels 

46. 

Sissies can’t forget to tuck their clitty 

47. 

A sissy’s ass is always on display 

48. 

Cute panties are essential 

49. 

Sissies wear tight leggings to attract men to their ass 

Page 3 

50. 

A sissy doesn’t neglect the balls 

51. 

A sissy has no butthole, a sissy has a pussy 

52. 

A sissy does not jerk her cock. A sissy cums only from getting her ass fucked 53. 

A sissy has two holes, both should be put to use 

54. 

Paint your face to look like a whore 

55. 

Work out to keep your sexy sissy bod fit 

56. 

Expose your thong so that they know that it’s on 

57. 

A sissy’s body is smooth and shaven all over 

58. 

A sissy’s body is always for sale 

59. 

Cum is not to be wasted 

60. 

Sissies don’t think. Sissies do as they’re told 

61. 

A sissy’s 👄 is not made for talking 

62. 

Sissies loves to be degraded 

63. 

Big black cock is a delicacy and should be treated as such 64. 

Sissies loves playtime 

65. 

Sissies take every inch 

66. 

Sissies always dress slutty when they go out. So they always get fucked 67. 

Panties are only removed for cock 

68. 

No skirt is too short 

69. 

Sissies wear bikinis 

70. 

The only use a sissy has for a condom, is slurping up Daddy’s cum 71. 

Wear a black bra, so they know you’re naughty 

72. 

Sissies fuck outdoors 

73. 

Pink is to be worn as a badge of sissy pride 

74. 

Never say no to cock 

Page 4 

75. 

You’re not a person; you’re a sissy fuck toy 

76. 

A sissy doesn’t jerk her clitty. She fucks both her holes while rubbing her clitty like a dirty girl 77. 

Send pics of yourself to cute boys; let them know you’re a dirty slut 78. 

Sissies sit when they pee 

79. 

Sissies love a nice gang bang 

80. 

Pink panties alone will not make you a sissy. You must have the body and mind of a true sissy slut 

81. 

Sissies play with each other 

82. 

Cum is essential in a sissy’s daily diet 

83. 

Sissies are whores that don’t earn a thing. Sissies give everything to their Daddy or Mistress 84. 

Sissies are property that can be bought or sold 

85. 

Wear stockings and stilettos 

86. 

Sissies tuck their clitty into pantyhose 

87. 

Paint your lips; make them a bright red target for cock 

88. 

Sissies loves Bukkake 

89. 

Every sissy has a little black dress 

90. 

Your sissy ass was made to take big dicks 

91. 

Sissies wear make up to look like perfect little Bimbo Fuck Dolls 92. 

Sissies wear sexy lingerie to 🛏️ 

93. 

Sissies loves giving road-head 

94. 

Sissies eat ass 

95. 

Sissies loves to feel the bulge of a hard cock 

96. 

Sissies always say yes 

97. 

Always keep eye contact 

98. 

Grow your hair long so men have something to grab while they pound your ass Page 5 

99. 

Sissies are punished when they misbehave 

100. 

Sissies don’t mind getting kinky 

101. 

Strap-on should always be treated as if they were real cocks 102. 

A sissy’s legs are always open 

103. 

A sissy always showers with her daddy 

104. 

Sissies don’t try to hide their panties; they proudly present them for all to see 105. 

A dildo is a sissy’s best friend 

106. 

A sissy’s pants should always be skin tight 

107. 

Work your sissy ass, so it can handle being fucked on a daily basis 108. 

Sissies wear yoga pants because they know how good their ass looks 109. 

Find some sissy friends. Go out and get fucked together 

110. 

Real women don’t enjoy being groped, but sissies don’t mind at all 111. 

All a sissy needs to know is how to please a cock 

112. 

Be a good girl 

113. 

A sissy can never have enough shoes 

114. 

A sissy’s breath always smells like cock 

115. 

Sissies proudly buy their lingerie in the store 

116. 

Sissies find a way to dress sexy even when it’s cold 

117. 

Sissies eat their own cum to remind themselves that they are no longer a man 118. 

Sissies loves eating pussy only when they get to lap up the Alpha cum dripping from inside 119. 

Sissies bounce up and down on real men’s long hard cocks 

120. 

Sissies loves to finger their own asshole 

121. 

Sissies wear panties when they run their clitty 

122. 

A sissy always says please and thank you 

123. 

Sissies read girly magazines 

Page 6 

124. 

If cum isn’t leaking from your gaping asshole, you’re not done yet 125. 

Look cute when you look for cock 

126. 

Sissies loves wearing crotch less panties 

127. 

Every sissy wants a black daddy 

128. 

Sissies don’t fuck women, women fuck sissies 

129. 

Sissies don’t want to be normal girls; sissies want to be bimbo fuck dolls 130. 

A sissy needs no help putting on a bra 

131. 

Wear a tight thong when you plug your boy pussy 

132. 

Never be afraid of a huge cock, you must worship it as you do every cock 133. 

Forget about boxers, sissies wear pretty pink panties 

134. 

Sissies like it rough 

135. 

Drop those panties when Daddy says so 

136. 

Every sissy needs someone to teach them to suck cock 

137. 

A sissy should never run out of her bras and panties 

138. 

Wear a crop top, make all the boys stare 

139. 

Sissies loves the feeling of a tight corset hugging their body 140. 

Sissies always go out with the intention of getting fucked 141. 

A sissy’s ass needs to be trained to take big cocks 

142. 

Cum dumpster is not an insult it’s your occupation 

143. 

Sissies get fake tits so they can be fucked in a whole new way 144. 

Transform yourself into a perfect bimbo pin-up girl 

145. 

Desperate for a good fucking? Pick your phone up Sissy, make a booty call 146. 

Always treat the balls with extra care, after all, that’s wear your treat is made 147. 

Sissies don’t wear lingerie to seduce men; sissies wear lingerie because it makes them feel feminine 

Page 7 

148. 

Sissies loves to feel their big fake tits supported by a tight bra 149. 

You can always find a way to practice sucking cock 

150. 

A sissy is content with the size of her clitty; its small size reminds her that she is not a man 151. 

Study real women, take notes 

152. 

Cum is not to be wiped away and disposed of, it is to be worn with pride 153. 

Always look as cute as can be when you go out shopping 

154. 

When you see cute boys make that booty pop 

155. 

No cock is too big for a sissy like you 

156. 

Always be ready for Daddy when he comes home 

157. 

Your job is to help him with his real job 

158. 

Every sissy wants to be owned by a big black man with a big black cock 159. 

Sissies loves to wear matching lingerie 

160. 

Keep your clitty and boy pussy clean and shaven 

161. 

A sissy works out like a girl 

162. 

Sissies don’t get to fuck anyone, sissies get fucked by everyone 163. 

A Blowjob is your opportunity to show Daddy what you’re worth. 

164. 

When he cums on you, he’s marking his territory 

165. 

You don’t even need to take your panties off to get fucked in the ass 166. 

A Sissy must be perfectly submissive, on her knees with her mouth open is not only where she belongs, it’s where she lives 

167. 

A Sissy does not need love, she will do anything to quench her lust for cock 168. 

A Sissy uses makeup to look as feminine on the outside as she feels on the inside 169. 

A Sissy’s Shorts Can Never Be Too Short 

170. 

Before you pleasure a man’s cock, take a moment to admire its beautiful size and shape. 

Take it all in with your eyes, before taking it all in your mouth Page 8 

171. 

You should always want to be the very best Sissy, like no one ever was 172. 

Just because you’re a real girl doesn’t mean you can’t get fucked like one… 

173. 

A Sissy doesn’t do all the things her daddy wants just because he told her to. She does it because she likes it 

174. 

A Sissy is not embarrassed by the size of her clitty… 

175. 

Every sissy has to have a set of sexy tan lines 

176. 

The only time a girl will ever ask you to take her panties off, will be when you’re the one wearing them 

177. 

Real girls get rings and diamonds, all a sissy gets is a pearl necklace. 

178. 

A Sissy must never have their clitty removed. Once Full Feminization has been achieved, the clitty must remain to signify they are still just a sissy not a real woman 179. 

A sissy is not truly a fully feminized Bimbo until she has a pair of fake tits 180. 

A Sissy has no safe word 

181. 

A Sissy knows her place. She is her Daddy’s whore and is to be used however he sees fit 182. 

You don’t even need to take your panties off to get fucked in the ass 183. 

Show off your Sissy Ass. Use it to attract men with big cocks 184. 

A Sissy’s makeup is never truly done until her face is covered in cum 185. 

A Sissy is always ready on her knees before his cock is even out 186. 

Always remember to worship the cock, even after your reward 187. 

Sissies take cum Selfies\! 

188. 

A Sissy is not told she is a Sissy. She discovers who she really is based on the size of her clitty and her desire to serve real men and their Alpha Cock 

189. 

A Sissy drinks cum without any hesitation. There is no shame only pride. A Sissy must accept that she is a worthless Cum Slut 

Page 9 

190. 

Sissies don’t hide who they are inside. They are proud to show the world just how girly and sexy they feel to dress and live as a girl 

191. 

Bimbofication is not just a faze, it is your destiny 

192. 

The Gangbang isn’t over until everybody cums on your slutty face 193. 

A Sissy is always ready with a smile when it’s time to suck a cock 194. 

A Sissy must learn to not just love cock, but to worship cock 195. 

When he cums on you, he’s marking his territory 

196. 

A Sissy feels no shame for who she is or what she does 

197. 

Sissies worship black cock because black men are the true alpha males. Sissies live to serve their massive cocks 

198. 

Sissies play fetch with a nice long double sided dildo 

199. 

No matter how big or small, always put your sissy titties on display 200. 

Once a Sissy has her panties around her ankles, she’s ready for a cock to pound her pussy 201. 

Sissies love to play with their food 

202. 

A Sissy must be perfectly submissive. On her knees with her mouth open is not only where she belongs, it’s where she lives. 

203. 

Every Sissy wants to grow up to be a Brainless Bimbo. A Dumb Cum slut who desires nothing but to be used by men as a worthless Fuck Toy 

204. 

A Sissy’s favorite fruit is of course the banana 

205. 

You’re not a sissy because you used to be man. You’re a sissy because you never were 206. 

Sissies give free lap dances 

207. 

Show Daddy his cum before you swallow it 

208. 

A sissy wears a bra, even if she has no breasts 

209. 

A Sissy’s shorts can never be too short 

210. 

Eat so much cum, that you become addicted 

Page 10 

211. 

A sissy does not want to be free. A sissy wants to be used 212. 

Use anal beads to train your sissy boi pussy 

213. 

Always treat the balls with extra special care. For they carry your sweet reward 214. 

Sissies love fucking while wearing heels 

215. 

A Sissy’s clitty must be caged. This is a very important , a sissy needs to learn that her clitty is useless and nowhere near the size of a real men’s cock. To learn this, a sissy is locked in chastity by their Daddy or Mistress until they truly learn what there pathetic excuse for a cock really is. 

216. 

Start growing hair long 

217. 

Only watch trans/hypno porn. No girl porn allowed. 

218. 

Wear panties & training bra 

219. 

Paint toe nails 

220. 

Wear earrings 

221. 

Change phone wallpaper to a male porn star. 

222. 

Have a Mantra to follow. \(Mine is "Cock is my God & Cum is my salvation" I repeat this in the morning and before going to bed\) 

223. 

Loose muscles/weight. Get slim. 

224. 

Play Bambi sleep & Mistress Stella track in loop when goes to bed 225. 

Always swallow Cum. If it's on floor then lick it up. Wastage of cum is unacceptable. 

226. 

Always seat with legs crossed. 

227. 

When walking on street check out men's bulges & ass. 

228. 

When meet a woman or cross by a woman on street notice what she is wearing. Her dress, heels, hairstyle etc. 

229. 

Owning and actually wearing women's clothing, be it full outfits or lingerie. 

230. 

Giving yourself a sissified name. 

Page 11 

231. 

Learning to love oral and anal penetration. Playing with your asshole and masturbating anally with phallic objects. Sucking and gagging on dildos because it's fun practice and because it turns you on to have your wet mouth stuffed with cock. 

232. 

Expressing your sissy persona online / interacting with other people online. All you sissies are doing that right here, right now. It creates validation and acceptance that being a sissy is really part of who you are. 

233. 

Owning a wig. 

234. 

Feminizing your body. Shaving your legs, crotch, ass, arms, chest, etc. Moisturizing your skin, going on a diet, doing cardio, plucking your eyebrows, growing out your hair. Anything that physically alters your body for the purpose of sissification\! 

235. 

Appling makeup to your face. Eyeliner, mascara, eye shadow, foundation, concealer, lipstick, and the like. It's hard to think of something more visually feminizing and ritualistic as a sissy sitting in front of a mirror for 20, 30, 45 minutes putting on her face. 

236. 

Hooking up as a sissy. The single most dramatic turning point for any sissy, actually getting into the same room as a stranger and presenting yourself as a sissy. Crossdressed, vulnerable and entirely sexual. 

237. 

Giving a blowjob. Crossing the emotionally tumultuous hurdle of actually meeting a local man for sex play. Tasting, smelling, feeling, and pleasuring another man's cock. Swallowing cum or having it shot across your face/body. Making a man orgasm using your body, hands, mouth, whatever. 

238. 

Getting fucked. Losing your anal virginity to a man. Letting a man fuck you in the ass. Has to be one the huge turning points for any sissy, anal sex changes you. 

239. 

No body hair at all at any time. 

240. 

Wear sluttier panties at least 1 thong day per week 

241. 

Wear stockings /tights /pantyhoes at least 1 day a week 

Page 12 

242. 

Wear a butt plug for at least 1 hr per week 

243. 

Can only cum by sissy-gasm in September \(cruel due to the enforced locktober making us desperate to cum\) 

244. 

Voice Control: no speaking unless spoken to. No complaining or making statements about what sissy will or will not do or what sissy likes or does not like unless directly asked for this information by Mistress. 

245. 

If Owner/Mistress has started a conversation with slave/maid while the maid is neither completing a chore nor in her corner, she is to kneel near but out of the way of Mistress’s movements. 

246. 

Eating and drinking is to be done standing at the kitchen sink unless Mistress gives other instructions. 

247. 

Sissy Duties: Vacuuming, dusting, sorting things out as instructed, changing beds, mopping floors, cleaning windows, laundry, sorting Mistress’s lingerie \(only if specifically instructed\) tidying the play room, sorting out kitchen cupboards and drawers. Cooking meals as instructed, and serving those meals to Mistress and pet. Making tea and coffee and serving those to Mistress and guests. Massaging guests as required. Body and foot massages for Mistress. Footstool for Mistress. 

248. 

Available for Mistress and guests to use in any way whatever at any time. \(safeword applies\) 249. 

Time when Mistress has given no instructions is to be spent making sissy as pretty and presentable as possible to Mistress. Studying massage. Studying makeup application. Nail polish application and decoration. Sissy may sit near Mistress’s feet on a low stool while studying. 

250. 

Sissy must be in panties and a bra minimum. Unless commanded otherwise. 

251. 

Sissy must keep shaved clean under her panties at all times. 

Page 13 

252. 

Sissy must curtsey when called, when owner enters the room, and upon returning from a chore. 

253. 

Unless sissy is told otherwise, sissy is to stand quietly in a designated corner upon returning from a chore. Or kneel near Mistress for further instructions. 

254. 

Sissy is to NEVER watch the news or tv, and may only use Internet to look at sissy stuff, or to study massage or cleaning methods. 

255. 

Sissy is not allowed to make decisions, or have any opinions except to agree with hir owner. 

256. 

Sissy Maid is to never leave house without permission. 

257. 

Sissy must be in full uniform including tights and headband, shoes and light makeup when serving. 

258. 

Sissy Maid is to not to speak without permission while in uniform. 

259. 

Maid is to bend over immediately and drop panties to be whipped, be it for punishment or your pleasure. 

260. 

Sissy must never talk back, argue or disagree with owner. 

261. 

Sissy owns nothing and has no rights. 

262. 

Sissy is forbidden from any non sissy related activities. 

263. 

Remove your body hair. At the very least shave your legs, pubic area and your bottom. Really the only hair you should have should be on your head \(just as a real girl\). This means shaving everything including your arms, armpits, chest and back. For a totally feminine feeling nothing beats feeling bare and smooth everywhere. This takes some maintaining but being a girl is hard work\! Personally I use hair removal creams to make the process easier 264. 

This goes without saying, wear panties everyday 24/7. Begin replacing your male underwear with pretty panties until the only underwear you own is female. Throw out your male underwear except for maybe one pair of boxers for extreme emergencies. Very serious sissy girls will wear panties for every situation including doctor visits Have fun experimenting with Page 14 

different styles, patterns and materials. When you are wearing panties full time then you can also then consider adding a bra to the mix. Real Girls wear both panties and a bra every day which means you should too as a sissy girl. 

265. 

Clip, shape and file your toenails. This should be done on a regular basis. Then paint your toenails in your favorite girly color. Sissy girls in my opinion should always have their toenails painted and they should be repainted every few days. Experiment with different colors and patterns. Nail art is so much fun and so girly If you really want to be extra feminine then make sure your finger nails are painted to match 

266. 

Above all else a sissy maid must be obedient. She must strive for perfect obedience in all that she does. It is not enough to just do as she told but she must do her duties to the best of her ability and gives her all in every task. She is passionate about obedience and respects the smallest rules as much as the more important rules. She is willing to move mountains, step out of her comfort zone and do what ever it takes to be obedient. 

267. 

A sissy maid must be respectful. This manifests in a myriad of ways. Primarily the sissy maid must always be respectful to her superior. She must never talk back, never use bad language and greet her superior in the way her Superior wants e.g. curtsey. She must also show respect by never talking badly about her Superior behind their back and never touching anything of their Superiors without permission. She must open doors for her superior, pull chairs out and never sit down if her Mistress is standing. 

268. 

The sissy maid also shows respect in her grooming and dress. Being clean and well groomed is a sure sign of respect. Making sure she is cleanly shaven, washes regularly, her uniform is clean and straight, her stocking tops level, shoes polished and wig brushed are all outward signs of respect to her Superior. The ideal sissy maid is checking her appearance regularly to ensure she maintains the correct standards. The sissy maid also shows respect by having Page 15 

impeccable manners towards not only her Superior but any of her Superiors guests and the public in general. 

269. 

A sissy maid should ideally be chaste. The control of her sexuality is in the hands of her Superior. She should have learnt to control her carnal thoughts and transfer her sexual energy into serving her Superior. She should never touch her ‘little clitty’ without permission, ogle her Mistress or any other woman or look at any images that may cause sexual arousal. 

Through chastity the sissy maid becomes more compliant and subservient and her standard of her work improves markedly. 

270. 

A sissy maid must be feminine and demure. She must embrace her feminine side completely. 

She must endeavor to talk, walk, dress and think like a woman. An interest in things like make up, sewing and knitting are to be encouraged. She must excel in all manner of housework and cooking. Learning to give a massage or a manicure are skills a good sissy maid should strive to master. 

271. 

The ideal sissy maid should be humble. She must always put the needs of her superior before her own. Humility means listening to her Mistress and taking correction in a spirit of gratitude. Humility means never making assumptions and making sure she asks permission for any changes to her schedule or if she is unsure if something is allowed or not. A humble sissy maid never back chats and only expresses opinions if asked. 

272. 

273. 

The sissy maid must be dutiful. She must be focused on performing all her duties to the best of her ability and on time. She must rise early and work hard all day. The only time she should relax is in her allocated free time if she has any. Otherwise she must keep herself busy and productive in the service of her Superior. The desire to complete all her duties to her Superior’s satisfaction burns strongly in the diligent sissy maid. 

Page 16 

274. 

Panties. Women wear panties every day. Now you do. Toss every last single pair of mens underwear you have. End of story. If you want to keep a pair for going to the doctor: Don't. 

He's a professional and bound by medical ethics and Federal law to not tell anyone \(and I've got a cousin who is a Nurse in a Hospital ER, she can't name-names because of those rules, but said that way more males come into the ER in panties than you'd think, around 5% to 8%, so the doctor WILL have seen it before\). Go to the store and buy at least two weeks supply of panties. In my experience, briefs and hi-cuts are best for the male anatomy. While you can definitely get some nylon, satin and microfiber panties, be sure to get some plain cotton ones. If you're having to do anything strenuous \(yardwork, exercise, ect.\) you'll want cotton undies too. Women know this lesson well, learn it yourself too. I avoid lace panties personally, because the lace usually doesn't react well with the male anatomy in my experience. "Boyshort" panties are also out, in my experience they are actually rather uncomfortable to be worn by a boy, just the way they are cut and your anatomy will fit into them. 

275. 

Diapers. You wear diapers to bed now. Sorry, but can't risk you wetting the bed :-\) Go out and buy a pack of "briefs", those adult diapers that are basically sized-up baby diapers. I've found that the CVS store brand is a good combination of easily available, affordable, and suitable quality. Avoid pull-ups unless the whole toddler-in-potty-training thing is your specific kink. Every night from now on, when you get dressed for bed, you WILL put on a diaper and make sure it's taped tight. For 8 hours you are diapered, and if you need to relieve yourself, you're doing it into the diaper. For me it's from 10:30 until 6:30. If I wake up in the night and have to go, it's the diaper for me. If I wake up in the morning and need to go, it's the diaper for me. 

276. 

Nighties. The only thing you're wearing over that diaper at night is a very girly nightie. I prefer a satin chemise, but any sleepwear that is extremely feminine and totally Page 17 

emasculating will do. You should be able to look in the mirror and see a total sissy girl. If your nightie doesn't cover your entire diaper, so much the better \(but it's not required\). 

277. 

Periods. You've got one now. Part of the whole "girl" thing, you're about to have your first period. Get a calendar, plot it out, you're on a 28 day cycle and for 5 of those days you're 

"riding the cotton pony" as they put it. There are plenty of online planners/tools to help you. 

Go buy some pads. I do NOT recommend tampons, as the health risks of anal insertion are way too high. Once you are in your period days, when you change out of your overnight diaper, put a pad into your panties. Change it every 4 hours. If you're at work, that means discretely keeping a pad or two around for changes. I'd recommend thin pads. Being discrete with hiding your pads and changing them is another part of the whole girly experience. So is the inconvenience of having to change them. At least you don't have to wear an overnight pad, you've got a diaper for your period at night. As I write this, I know I start my period tomorrow, and I went to the pharmacy to buy some Always Infinity \(my preferred brand\). Having a preferred pad is VERY femme. Guys don't know anything about pad brands and styles, girls do. 

278. 

Pee sitting down. Should go without saying, but your days of standing up to pee are long gone. No pulling down the front of your panties to pee at the urinal or into a toilet. Take a seat, little lady\! I haven't peed standing up since 1999, it's even to the point that on a camping trip, I squat in the bushes like the girls do. 

279. 

Shave your legs. Another part of the whole "girl" deal, you're shaving your legs and keeping them bare. If for some reason you don't feel comfortable with exposing your shaved-bare legs with shorts in the summer, shave them for the first time on Labor Day, and stop shaving just after Valentine's Day to let your leg hairs grow back so nobody will know better during the spring and summer. 

Page 18 

280. 

Paint your toenails. What co-worker or friend is ever going to see your toenails? Those little tootsies should always be regularly pedicured and kept in a very girly shade. Pinks, reds, and light blues and greens are good. 

281. 

Bras, sometimes at least. Yes, I know you can't easily hide a bra under many clothes. 

However, at least one day a week you should wear a bra. During the winter it's much easier to do under heavy clothes, so it's easier to hide during a workday. Otherwise it's a weekend day. If you want the "little girl" effect, a bralette is pretty dang close to a training bra, and the Justice chain for tween girls carries actual training bras in up to a 38 band \(but you usually have to order them online\). 

282. 

Be a girl online. Social media is your friend. You can be whoever you want. Set up a Facebook and Twitter account in the name of a femme alter ego, join girly groups, play girly facebook games. The minimum age in Facebook's Terms of Service is 13. So, on Facebook and Twitter I have an alter ego that's a 13 year old girl. She's a homeschooled girly-girl who is into all the various teen idols and still loves Disney Princesses. I have to actually mentally get into a different mindset to type like like a 13 year old girl instead of a thirtysomething male, definitely helps with the sissy thinking. 

283. 

Work out like a girl. A girl has to stay in shape. Yoga, pilates and various aerobics are your friends. Buy some workout DVD's. At least one girly exercise outfit is good too, unless you're planning on working out in just your panties and a sports bra. Work on toning those legs, you want toned and shapely, not ripped and muscular. If you're a little oversized, this will help get you in a girly shape over time. Personally, I wear a white sports bra and cotton panties, a pair of pink women's running shorts, and a pink T-shirt to exercise in. 

284. 

Own his orgasms fully and completely. 

285. 

He may not masturbate unless he asks permission, and must ask as follows: "Because sissies aren't allowed pussy, may I rub my clitty?" 

Page 19 

286. 

He must remain shaved regularly, to include legs, chest and underarms. 

287. 

He is to keep his toenails polished and touch them up as needed. 

288. 

He is to wear panties every day. 

289. 

He is to wear a nightie to bed each night. We have an assortment from which he is free to choose. 

290. 

He must sit down to pee, just like a girl. 

291. 

He must regularly make love to his stuffed bear, rubbing his sissy stick against it. 

292. 

When he makes love to his bear, he must first apply lipstick. 

293. 

His bear is the only sexual outlet he can use without asking permission first, and he must always apply lipstick. Therefore, if I see him wearing lipstick in the morning, I know he will have given in. 

294. 

No orgasms unless completely feminized, in full sissy attire, including wig and makeup. 

295. 

If you ever wonder if you’re really a true sissy slut, just have Daddy fuck you in front of a mirror. Then you’ll see just how much of a cock whore you really are 296. 

Don’t think of begging on your knees as degrading… 

297. 

When you wear a butt plug, don’t think of it as a toy 

298. 

You should treat servicing cock as an art form. He is the artist and his cock is the brush. You are the blank canvas. Let him paint you with his cum 

299. 

Turn around and look Daddy in the eye when he’s fucking you from behind. Push your ass back on his big cock, show him what a dirty whore you are 

300. 

Wear a short skirt so Daddy has easy access to your tight little ass 301. 

Throw out your baggy jeans and cargo shorts and replace them with leggings 302. 

Do not make Daddy wait. 

303. 

Never stop fucking to pick up the phone 

304. 

A Dildo is a Sissy’s best friend 

Page 20 

305. 

Don’t feel the need to pretend you don’t love being punished. Just say thank you and beg Daddy for more 

306. 

A sissy does not wear panties simply because they are girly. A sissy wears panties because that’s where her pathetic little clitty belongs. Boxers are for real mean with real cocks not sissies 

307. 

A sissy’s make up is never truly done until her face is covered in cum 308. 

When you get a dick pic, make sure you return the favor 

309. 

When a sissy receives a dick pic she is not disgusted by it. Every cock is a gift. Save them all and look at them while you rub your clitty, dream of sucking every single one 310. 

Once you slip that first pair of panties on there’s no going back. You’ll realize as soon as the material touches your pathetic clitty that it has always belonged in panties 311. 

Anytime you aren’t getting fucked in the ass, you better have a big butt plug in that tight little sissy hole 

312. 

A Sissy’s favorite dessert is a creampie in her tight little sissy boi pussy 313. 

Bimbofication is not just a faze, it’s your future 

314. 

A Sissy never says no, or says she isn’t in the mood. She is well aware of the fact that she is just a toy. She is a fuck toy whose only use is to be fucked. Her only focus is to please her daddy’s cock 

315. 

A sissy must learn to not just love cock but to worship cock 316. 

Sissies bounce up and down on real men’s long hard cocks 

317. 

Drop those panties when Daddy says so 

318. 

You don’t need freedom… 

319. 

One is not enough 

320. 

Pink Panties alone will not make you a sissy. You must have the body and mind of a true sissy slut 

Page 21 

321. 

A Blowjob should always be wet and sloppy… 

322. 

A sissy drinks cum without any hesitation. There is no shame only pride. A sissy must accept that she is a worthless cumslut 

323. 

Always remember to worship the cock after your reward 

324. 

Daddy always knows best 

325. 

The word “Bimbo” should not be heard as an insult, it is a title you earn after years of feminization 

326. 

A Sissy should rarely have the need to speak, let your panties do all the talking for you. And what are the two most important words in a Sissy’s vocabulary? Yes, Daddy 327. 

Every sissy wants a Black Daddy 

328. 

Always make sure your plug is tight and secure before you pull your panties up 329. 

Show Daddy his cum before you swallow it 

330. 

Take a selfie every time you suck a new cock so you can always remember what a little slut you are 

331. 

A sissy must learn to not just love cock but to worship cock 332. 

A Sissy must always suck and please a woman’s strap on as she would a man’s real cock. 

Sissies must always be submissive to both men and women and so they must always do what is commanded by a dominant including chicks with dicks 

333. 

Cum Dumpster is not an insult, it’s your occupation 

Page 22 

****

## **10 Ways To Test **

### **If You’re a Sissy **

\[play safe, sane and consensual\] 

*February 2023 – Ver. 1.1* 

If you’ve ever wondered if you really are a sissy, or contemplated on how much sissyness is trapped inside of you, you’re not alone darling. It’s completely normal for questions such as these to pop up into your pretty little head. 

Some would say that if you have to ask, then the answer is apparent. But just in case you are experiencing some gender identity confusion, the following 10 questions may help to clear things up for you. 

**1. When you were a little boy \(or maybe even a teenager\) did you ever feel compelled to try on** **your mother’s, sister’s or cousin’s clothes? **

This question will take you back to the roots of your sissyness. Trying to figure out why you had this overwhelming desire to enjoy the feel of soft, silky, feminine garments next to your skin is an exercise in futility. It might have something to do with the way you were raised. Or… **maybe you were just** **born that way. ** 

The only thing that really matters is to not place any judgements on nor have feelings of guilt about your dress-up-desires. Society may say otherwise, but our narrow-minded culture can be kind of fucked-up in this area. 

The important thing is that if you did feel inspired to put on something feminine, you get sissy bonus points for actually following through and trying on that cute little dress\! 

**2. Have you ever gone down on a girl immediately afterwards so that you can actually taste your** **cum? **

Sweetie, this is a seriously submissive act, and we both know that sissies are submissive by default. 

A true sissy loves to perform oral servitude on women—and sometimes, even men. 

Page 2 

Sissies also fantasize about eating their own cum, so if you’ve answered the above question in the affirmative, you’re corroborating your aptitude for sissiness. In addition, if you enjoy eating out a girl more than actually fucking her, then I believe you can take this to mean that your inner-sissy quotient is pretty damn fucking high. C’mon, any delusional claims you may have as to being in any-way-shape-or-form an alpha male would be seriously offensive to a real man. 

**3. When you see an extremely attractive woman, what do you notice most; her tits and ass or her** **nails and heels? **

A sissy’s focus would obviously be on her nails and heels… along with her makeup, hair, fashionable clothes and jewelry. Although a real man would be peripherally aware of these feminine attributes, his main interest would be on her body. He would want to rip all those beautiful clothes off her and fuck the shit out of this gorgeous woman. 

A sissy, on the other hand, legitimately holds a high amount of admiration for how this feminine creature has artfully put herself together. There’s even a bit of envy on the sissy’s part of how captivating this girl looks. 

Sure, a sissy would maybe like to fuck her, if she \(the sissy\) could get it up, but she would probably get more enjoyment out of being fabulously dressed-up herself and getting fucked. Following along with that same sissified mindset… 

**4. Have you ever avoided approaching a woman even when the situation is perfect and it’s obvious** **that she wants to be approached? **

This scenario is most often attributed to approach anxiety and being generally unconfident around women. But why are you fearful and anxious when it comes to women? Is this a *problem* that needs to be overcome, or is it just that you’re a spineless sissy by nature? It’s a valid question that you need Page 3 

to be honestly asking yourself. It’s quite possible that your less-than-large dick \(or sissy clitty\) is frightened of pussy. If, as a sissy, you don’t feel worthy enough to fuck this girl, then you will subconsciously self-sabotage any attempt to approach her, the gorgeous goddess that she is. Maybe you would be more content to be her sissy slave instead? Just asking. 

**5. Do you sometimes wear lingerie, high heels and dresses? **

If you do, that means that you’re a crossdresser, but not necessarily a sissy. Sissies are submissive and subservient. Their role in life is not only to look pretty, but to be obedient and have a penchant for providing pleasure. 

But, if you have already started putting together your feminine wardrobe—lingerie, pretty dresses and high heels—then these other questions will help you to ascertain whether you possess the aptitude required for taking things to a different place… and become a full-fledged sissy. 

**6. What do you fantasize about while masturbating? **

Since sissies are crossdressers that have a decidedly submissive nature to them, then this question will be an acid-like test to determine how docile and subservient you really are. If you get off by having someone giving out orders as to what they want you to do, then you have the submissive qualities necessary for being a serious sissy. If you gain even greater enjoyment by obeying these orders, then that is further proof of your meekness. 

Does being a sissy slave to a dominate woman do it for you? Would you like her to fuck you up the ass with a strap-on while you moan in ecstasy? How about being kept in chastity 24/7 and serving as her cuckold slut—your primary role being to fluff up her lover? 

Does being dressed up in something girly while all of this is happening make your little sissy dick twitch? We can stop right here sweetie… you’re definitely a sissy. 

Page 4 

**7. Do you wonder what it would be like to suck on a real cock while dressed as sissy? **

Since I broached the subject of you serving as a ‘fluffer’ for your mistress, we might as well take this matter a bit further. Yeah, since most crossdressers are straight the thought of sucking on a cock might not do it for them. But as a sissy, well that’s a different story. When sissies are all dolled-up, a psychological shift takes place. In the quest to validate her femininity, she suddenly becomes a submissive fuck toy to be used by either a woman or a man. A sissy slut is pretty much required to become a capable cocksucker. 

I suggest you get out your dildo—hopefully you have one—apply some lipstick and begin a regular practice schedule. Soon enough you’ll have the opportunity to have your pretty lips wrapped around the real thing… and you won’t want to disappoint. 

**8. Do you prefer to sit down to pee, even when it is not absolutely necessary? **

You don’t need me to tell you this but that is boda fide, ladylike behavior. The more important question is, why do you do feel the urge to do it? You most likely already know—it’s one relatively small, seemingly insignificant form of behavior that makes you feel like a girl. But is it really that trivial of an act? If you haven’t yet begun to flush-out your feminine feelings, maybe it’s time you do so. 

**9. Do you shave any parts of your body that men typically don’t shave? **

I realize that many men shave their legs for sports and stuff like that. They may even shave their underarms for hygienic reasons. But if you do shave, it’s time to be totally transparent with yourself—

what’s your underlying motivation? Might there be some subtle, secondary benefits you are receiving? 

Page 5 

Do you enjoy the feel of pulling on a pair of nylon stockings over your freshly shaved legs? Or perhaps it’s the smooth, silky feeling you experience when sliding between the sheets at night. 

Let’s face it, being hairless feels oh-so feminine. Maybe it’s time to go all the way and keep your entire body shaved? 

Now-a-days it’s not all that uncommon. You could get away with it if you really wanted to. Plus, every time you shave yourself smooth, it has the effect of affirming your sissyness. 

**10. Do you paint your toenails? **

If you do, then you already have effeminately embraced being a sissy. If you don’t, I think it’s time to start. Not too many things will make you feel more feminine than keeping your toenails painted. If you’re not quite ready to show them off to the world, then it’s easy enough to keep them covered-up in the winter. During the summer months, you can paint them a neutral color. There are other creative strategies—for example, I wear special yoga socks when I attend yoga classes. 

Hopefully, the question “Are You a Sissy?” is now as straight forward for you to answer as it is for me. 

Something can be said for surrendering to who you truly are sweetie. It’s an intoxicating feeling to wake up in the morning, climb out of bed and look down. The first thing I see is a view of a flat, feminine front—a pair of panties covering up my tucked-back sissy clitty. As my gaze moves further down, my eyes are directed to a pair of smoothly shaven legs followed up with my prettily polished toenails. What a way to start of the day\! Am I a sissy? It sure does look like it. The more important question is… are you? 

**Becoming the sissy of your dreams doesn’t happen overnight\! **

Sissification is a process. It’s a matter of taking consistent, dainty, high-heel-like-steps in order to arrive in Sissyville \(maybe that could be a real place someday\). 

Page 6 

****

****

****

**How to Sissify **

## **Your Boyfriend**

- 8 steps to Sissify him – 

\[play safe, sane and consensual\] 

*January 2023 – Ver. 1.1 *

The sooner we start the training the better will be the results. 

## **STEP 1**

To sissify a man, the first thing to do is to change his physical appearance. 

Start by saying him that you would like him to shave his legs and penis. Argue that you’ve come to be not very comfortable with hairs. To make your point explain him that you too are doing some sacrifices for him. 

Wait a few weeks until it is a normal thing for him. Insist on the fact that he has beautiful legs, that you love him and that it doesn’t make him any less sexier. 

## **STEP 2**

Say him that it would be fun that he tries one of your panties, just for fun. Then say him that it turns you on and make him love like never. Make him keep them during sex. He will associate him wearing panties to the pleasure you gave him. Try this again one time every 3 or 4 days. Every time he want to have sex insist on the fact that you would like him to wear them because it please you and that you would do the same kind of thing for him. 

## **STEP 3**

Because it turns you on so much ask him to wear them every day. 

## **STEP 4**

Make him paint your nails as a game. 

Say him that he is very good at it and that it would be fun to try on him\! If he resists tell him that it is just a game and that it doesn’t mean anything. When it’s done make love to him. Please him. 

Then ask him if he would keep them a while for you. Like for the rest of the week, make it more and more frequent until he even start to make him by himself. When you’re there insist on the fact that he keeps his toes painted every day. 

Page 2 

**STEP 5** 

While you’re making love, or giving him pleasure, lick one of yours finger in a kinky way and gently insert it in his anus. Get him used to it. A few weeks later make him surprise you while you’re playing with a dildo. Be shy but keep going in front of him. Make him do it to you, and then put his head between your legs. 

Ask him if he would do anything for you then say him that you would like to try your dildo on him. 

Argue that you have read that a lot of men love it. 

During the whole thing encourage him by saying how you are grateful, how he is brave to try it for you and how much you love him. If it is painful, stop and try again a few days later. He will get used to it and even start to have some pleasure doing it. 

## **STEP 6**

Now that your boyfriend has shaved legs, painted nails, wear panties and is used to be penetrated, it is time to put him into chastity. 

Tell him about chastity and how some of your friends have tried it and how it had made their relationship stronger and happier. Argue that reducing the number of orgasm, make sex better. 

Ask him if he would like to try with you. After a week without sex of any kind make love to him, please him in every way he likes. 

After another week of abstinence, say him that you think that he is not respecting your agreement. Tell him that you would like to try something that some of your friends have tried on their boyfriends. Tell him about chastity cages and ask him if he would be ready to try the thing for you. Insist on the fact that a lot of your friends boyfriends are wearing it and that it is just a proof of love. When he's convinced, buy one. HolyTrainer is a good choice. 

Make him wear it during a few days then release it and make love to him but don't let him cum and then lock it again. Doing this a few times will make him think that he is still in control, which is a good thing. 

Progressively, make the space between releases longer and make him give you pleasure by licking you. Then after a few cycles, do your make up while he is in the room and try as a game on him. 

Say to him that he looks beautiful and ask him if he would try some of your clothes for you and give him the wig that you’ve bought for next Halloween. Convince him and take some pictures because he makes you so horny. Then make him love to him and remove all his make-up. Don’t talk about it for two weeks. 

Page 3 

**STEP 7** 

After two weeks of chastity say him that you have decided that his cock isn’t enough anymore. Tell him that the dildo, which, by the way, is bigger than his cock, satisfy you better. Talk with him as a teacher to a student. Make him admit that things are better this way and that he should thank you for making this possible. Say him that you took the decision of keeping him in chastity. He will protest but be confident. If he wants to be happy he needs to accept the situation. You are now in charge. He is no longer a man. 

In fact, say to him that now that he has shaved legs, pretty painted nails, panties and his cock locked, he is closer to a woman than to a man. Discuss with him the fact that he is a lot better since you started his feminization and that you are decided to help him become more feminine. 

Insist on the fact that it doesn’t change anything for you and that you will always love him. You just think things are better this way for both of you. He now need a girl name. Encourage him to choose it. It will reinforce the fact that he accept his new life. 

If he protests too much, show him the pictures you take of him. Ask him what he sees. It should put an end to the discussion. 

You shouldn’t say that you are going to show the pictures to his/your friends. The change has to come from him. 

## **STEP 8**

The real training starts. You have control over his orgasms, now you have to extend it to everything. Once again, like a teacher to a student, make him admit that you make better choices and that having you in control of the relationship is for the best. You should decide everything for him and he should always obey. Everything you do is for his own good. Beside if he loves you, he should only think about your happiness. 

Remind him that he won’t be ever a real woman but that he could become a fine sissy. 

Make him wear woman clothes, make up, a wig and high-heeled shoes at all time while at home. 

Explain him that being a sissy is not only about being feminized and chastised. He needs to understand that as a sissy his only goal is your pleasure which mean serving you at all times and by every possible ways. 

Be firm and confident. When you ask, even if it is said in a kind manner, it is an order. 

Page 4 

Because he is no longer a man he needs to train his pussy every day. Make sure that he practices at least 30 minutes a day with a dildo and wear a plug when his pussy is not in use. The only sexual pleasure he will get will come from there. 

After a week of training, take his boy-pussy every day. Tell him that as a good girl he needs to get used to it. 

Make him sucks dildos every day because a real girl needs to know how to pleasure and make him practice deepthroat techniques. 

When you decide your sissy has earned an orgasm, bound her arms, remove her cage and make her ejaculate directly in her mouth. It will be the only way she will be allowed to cum. Then lock it again. 

After a few other weeks of training, if it suits you, you can offer a friend or two to fuck your former boyfriend. Your sissy will fully integrate her new role by being used as a whore. Help her while she is performing. Make her spread her chicks. Push/cuddle her head while she is giving her first blowjob. Make her show her mouth full of cum. She needs to wait until your friend say she can swallow. Make her thanks your friend. 

During the whole act, speak to your sissy. Tell her how proud you are of her. Don’t hesitate to speak to your friend about how you would never have imagined that your boyfriend would become such a fine slut while she is getting fucked or giving a blowjob. You can make fun of your former boyfriend: After all he never was a real man. Have you seen his little clitty? Are you enjoying stretching her ass? Is the blowjob fine? 

When your sissy disobeys or protests, be strict but always explain why you have to punish her. It is for her own good. To make her better and happier in her new life. 

Some ways of punishing your bad sissy: 

– mouth soap-washing 

– bigger butt-plug 

– barefoot spanking, panties down then 30 min in the corner hands on her head 

– barefoot spanking, panties down then an enema with cold water 

– pegging during x days will be without lubricant 

– barefoot spanking, panties down then an enema with cold water and bondage for x hour 

– x days more before release 

Page 5 

– only after at least one month of training 

– if you have a friend whom you have said the truth about your former boyfriend/sissy invite her so she punish your sissy for you. It will be even more humiliating 

– if you have a friend whom you have said the truth about your former boyfriend/sissy, lend your sissy to her for a day or two 

– if you have some friends whom you have said the truth about your former boyfriend/sissy, invite your friends to see how you punish your sissy. Spank/cane her in front of them. Make your sissy explain to your friends how her life is. 

When your sissy behaves well, always compliment her. It will reinforce her implication in the process. You can pet her head/cuddle her and use such expression as : 

– Good girl\! 

– I’m proud of you 

– Very nice\! 

– Good job\! 

– You’re the best\! 

– You’re so cute\! 

If you are very satisfied by your sissy you can buy her small gifts as lingerie, wigs, make up. 

Every day, make her say that she is a sissy and that she loves it. 

Never forget to say your sissy how beautiful she is, how proud you are of her and how much you love her\! 

What happens next is up to you\! 

After a few weeks of training, your boyfriend will learn to love being a sissy. At least he will accept it. 

Page 6 

****

**7 Ideas **

## **to Feel Girly **

\[play safe, sane and consensual\] 

*February 2023 – Ver. 1.2* 

****

****

****

Many of you know what it’s like. You are expected to be a man. You ARE a man. At least, you’re male. But you want to be girly. You want to wear dresses, skirts, lingerie, heels, cute outfits, etc. You want pretty hair, smooth skin, a softer walk and gentler mannerisms. You also want to be accepted as your girly self, but that’s not going to happen–at least not publicly and maybe not in your lifetime. You have family or friends, work, school, and social activities where you’d like to feel girly, but you know you must portray “man.” 

That’s tough, isn’t it? But is all lost? I don’t think so and I want to share with you seven ideas that can help you feel girly when you must be “boy.” 

Before I post, I want to give a quick nod of gratitude to the many fabulous girly boys who chimed in and shared their thoughts. This list is a combined effort and not one i could have come up with on my own. It’s also not an exhaustive list. Also, I would encourage you not to try and implement everything. Just try a few of these ideas, even if it is one at a time. 

## **1. Smooth Out Your Image**

Get smooth and fine. I personally enjoy shaving my upper legs and trimming my lower legs. I wish I could shave the entire bit. I keep my chest, topside of hands, and armpits shaven and even shave the underside of my forearms. Shave your groin too and keep the hair above that area short and groomed. Additionally, you could try your hand at plucking eyebrows to a thin, but subtle arch. I used to do this without any question. Just make sure you pluck eyebrows at a time when no one will see you with temporary reddish plump from the plucking. It goes without saying that man-hair problems should be taken care of anyway. Keep the nose trimmed and the ears plucked. Ear hair is gross. Other options include, but are not limited to body lotions and conditioners, bleaching what hair you keep, and being conscientious about all areas of hygiene. Mostly, when it’s said and done, simply clean yourself up. Your outer boy will benefit just as much as your inner girl–it just feels great and feels clean. 

Page 2 

**2. Spoil Your Girly Self **

Learn to enjoy the spa treatment. Take scented bubble baths, do facemasks, and moisturize with girly lotions. Paint your toenails feminine colors and use clear polish on your fingernails. Don’t forget to clean your cuticles, having them softly tapered back. You could also try some slight growth that you could file to a more oval shape. Use a little foundation on your face or maybe a bit of eyeliner or eye shadow. Try lip gloss instead of chap stick and keep it on you to use at any point during a day. Fruity flavors and perhaps some glittery gloss can add some excitement. If you’re feeling it, be a little more risky with some subtle mascara, blush, or lipstick. Get a pedicure or manicure. Get yourself some perfumes to spray on religiously. The point is, treat your inner girl like a princess. You she deserves it\! 

## **3. Be Girly Under There **

If you want to feel girly, there may not be any better option than panties. You can go as fem as you wish and as small as you can handle. No one will ever see, unless you show them. Learn to enjoy a good Tuck. Keeping the little boy in check and his friends up and out of the way might be a bit of a pain at times, but it’s so worth it not to have a bulge. A step up would be stockings or pantyhose. What a rush when you opt out of socks\! And then, there is the bomb: the bra. It’s not always going to work out as an option because of whatever kind of shirt you choose to wear. Some other secret options are things like girly temporary tattoos, garters, feminine socks, chemises, panty liners, or maybe a choker underneath a collar and tie. 

## **4. Embrace Androgyny **

This might be my favorite. Girls clothes that can pass as men’s clothes. Women’s jeans are a great go-to. I have a few pair of womens jeans in boot cut and skinny. There are some options that won’t work, but there are plenty of options that can. Do your research. Also, although women’s shorts are generally short, there are long shorts made for women. I almost got a pair of women’s Page 3 

cargo shorts once. I own a women’s swim short that passes. Like jeans, you can find cute shirts, and unless someone can tell that the buttons are on the opposite side, you’re golden. And alas, my absolute favorite. I’ll admit, I’m quite stricken by women’s sneakers. What I love about shoes is that people don’t normally look down at feet, and if they do, they’ll either not care or not pay attention. Trust me, there is no one going around checking to see if you have on narrow shoes or to see if your shoes have pink highlights. I’ve walked through streets, malls, shops, parks, ballparks, etc. etc. in Keds, cheer shoes, or flats without even the slightest second look \(even though i kind of wished for it\). I have a whole collection of women’s sneakers and wear them frequently to various public spaces. Never once have I been questioned for it–even in the cutest pairs. If you wear something larger than a 12 in women’s shoes, companies like New Balance and Skechers make size 13 now and many companies are finally making 12′s as a regular. Thank goodness\! But it’s not just tennis shoes. There are several casual flat options that are simply narrower versions of men’s styles. Obviously, if you’re trying to maintain a guy profile, you can’t wear heels, but you can try subtle platforms. Androgyny may not be as sexy as “all out” but it’s great to have the option. even if it does look semi-manly, at least you know. I could continue to write more, but I must move on. 

## **5. Accesorize **

I’ve not done much with this one myself, but I can see where it would be awesome. Rings, earrings, belly button rings, toerings, necklaces, bracelets, ankle bracelets, or watches. I’d love to have a girl-size apple watch and band. It’s your choice in how much you’d like to glam it up. Purses might be an option too if it could pass as a man-bag. What about a girlish backpack or sling? What about a semi-girlish phone case, computer bag, or a women’s wallet? Here’s an idea\! Care to try a hair band? Or if your hair is long enough, a scrunchie. Another option might be ladies’ eyewear frames or sunglasses. In cold weather, ladies gloves, scarves, or toboggans. How about cute hats or visors? When you’re at the beach or pool, use girlish towels. When working out, girls’ lifting gloves. The idea here is to add a little something girly that makes you feel special. 

Page 4 

**6. Practice Feminine Posture and Gestures** So, you want to feel girly? Start acting like it. Talk softer, move more gracefully, sit more precisely. Cross your legs like a woman when you sit. Get into a car as if you have on a dress. Walk narrow as if on a thin line. Limp your wrists and point your toes. Act like you have hips. Twirl your hair if you’ve got it. You may not want to camp it up too much, but you can certainly improve your mannerisms subtly over time. I definitely could use some help in this area. I’d say that the hardest part is developing the habit. 

## **7. Do Girly Things **

The options here are perhaps endless, but I’ll try to give a few. I like the idea of keeping a diary and writing in girlish strokes with pink or purple pens. Put little hearts for dots on your i’s. Doodle flowers. Watch chick-flicks \(I know, that sounds sexist\). Window shop often. Go to women’s shops frequently and take in every opportunity to go into those special places with your girlfriend or wife. With your significant other, cuddle like a girl would and be tender with your kisses. And, of course, it wouldn’t be a Gym Bunny Candie post if I didn’t say it: “Dress girly for a workout.” Even if it is in the sanctity of your home, wear a sports bra and yoga pants, cute tops, maybe even a tennis skirt. It’s not about having a sissy workout. It’s about transforming your body while luxuriating in the feminine garments. And don’t forget your girly sneakers\! LOL One thing you could always try is early morning or late night walk or runs in your girly gear. I live on a golf course and so I will sometimes get girly and run the course at night on the golf cart path. It’s such a rush\! There are just too many options. 

Page 5 

8 Steps In Your 

Sissification Project 

\[play safe, sane and consensual\] 

*February 2023 – Ver. 1.2 *

* *

* *

* *

Transforming yourself into the sissy of your dreams can be one of the more exciting and erotic adventures you will ever embark upon. It can also seem overwhelming at times. I mean, here’s just a partial list of things that go into the making of a sissy: 1. Hair removal 

2. Weight loss 

3. Makeup, hair & nails 

4. Walking in heels 

5. Acquiring a wardrobe 

6. Developing feminine mannerisms & voice 

7. Moving beyond male orgasms 

8. Learning to cum like a real girl 

All this can make a pretty girl’s mind become blurry behind a cloud of disarray. 

And of course, we want all of those sissy things right NOW\! 

At some point though, your sissy fantasies will come face-to-face with bare-knuckled reality. 

The truth of the matter is that your sissification will be a process. A sometimes intense, frequently challenging, but extremely satisfying journey that isn’t going to happen overnight. 

Becoming a serious sissy will give you a healthy appreciation as to how much work is involved for a genetic girl to look as good as she does. As a sissy, since your starting off with a boy’s body, you’re gonna have to work even harder than your female counterparts. 

The proper sissy perspective is to learn to accept and enjoy the entire sissification process. 

Page 2 

When you see a photo of a drop-dead gorgeous crossdresser, it can be illuminative to view her as an iceberg. You are only seeing the top 10% of her, the part that shows. 

What isn’t readily apparent is the time she’s spent dieting, exercising, applying make-up, enduring laser hair removal treatments or how many cocks she’s had to suck in order to afford the expensive lingerie and high heels that she’s wearing. 

It’s the same with you. Snapping your fingers \(with their prettily polished nails I hope\), and magically transforming yourself into the perfect sissy would take all the fun and excitement out of things. 

It would be like showing up before the start of a football game and have the PA announcer proclaim that instead of playing the game, the final score will be 24-20… everyone can go home now. Both the players and the fans would exit the stadium feeling frustrated and cheated out of experiencing the excitement and drama of how that final score came about. 

So, in the spirit of appreciating and enjoying your sissification, let’s take a brief look of how the process might play out, for each of the above checked items. 

## **1. Sissy Hair Removal **

Keeping your body smooth and sexy typically starts with shaving your legs. Many male athletes shave their legs on a regular basis so this will not draw any unusual attention to yourself. It only takes about five minutes… once you get good at it. 

The next logical progression would be to shave your entire body. This is becoming much more widely accepted now-a-days so any hang-ups you have about it are in your head and no one else’s. 

We’re talking anywhere from ten to fifteen minutes to shave all over but as your sissification process intensifies, it’s a commitment you’re more than happy to submit to. Once every week or so will be often enough, but going longer in-between shaves can definitely turn it into a chore—as well as increase the time it takes. 

I eventually began to shave two or three times per week. The shorter the hair, the quicker and easier shaving becomes. By shaving more often you can enjoy having a silky smooth body most all of the time. 

Many sissies will stop at shaving but the next step in the process would be to remove the hairs from their follicles by either waxing or epilating. I have personally moved on to the epilator. 

Page 3 

Epilating will take some getting used to, especially for the chest area. Hair grows in cycles, so when you’re shaving, all of the hairs are front-and-present at the surface of the skin. Once you begin to epilate though, you will only be dealing with around one-third of them at any one time. 

That’s the reason that in between epilating sessions, the hair that grows back will be less dense. Also, since you’re no longer blunt cutting the hairs off with a razor, the hairs will be and feel finer since the virgin, un-cut tips will be pointier and thus narrower. 

If you choose to epilate, the first time is the worst as you will be pulling all of the hair from their follicles at once. Subsequently, things get much easier as you’re only dealing with one hair growing cycle at a time. Plus, your skin \(and follicles\) will adjust appropriately, making the procedure much more bearable. 

Don’t believe in the myth that using an epilator will leave your skin hair free for two to three weeks at a time. In my experience, that’s not the case. I have settled into a routine of epilating once per week and then shaving afterwards. 

Epilation doesn’t get every single hair, plus you won’t want to let that devious device come anywhere near your private parts, so shaving is still a necessity. Still, my once every week epilating/shaving ritual pretty much leaves my skin smooth and silky for the whole week. 

The final step in the sissy hair removal process would be, of course, undergoing a more permanent procedure—either laser treatment or electrolysis. If you’ve got the money, that may be the best way to go. 

## **2. Weight Loss For Sissies **

Other than makeup, nothing will make you look more beautiful and convincing as a sissy than a slim, trim and sexy body. Like everything else about becoming the best sissy you can be, losing weight is definitely a process. 

A really great way to begin that process is to start eating in an extremely effective way to shed unwanted pounds. 

Page 4 

Look, just about any sissy \(or anyone else for that matter\) can lose 20-25 pounds in two or three months buy eliminating all crummy carbs from their diet. 99% of the time however that weight WILL 

eventually come back on. Why? Because to keep the weight off permanently, the image you have of your ideal sissy weight must match \(be in vibrational alignment\) with what you really think is possible for you. 

It can be incongruent for your inner-self to bridge the reality gap between a 185 pound macho man and a 135 pound svelte sissy. It’s problematic to reconcile that large of a discrepancy between your current weight and what you would like to tip the scales at in a more feminine form. The psychological term for this is ‘cognitive dissonance’. 

Instead of trying to radically change your inner-most held beliefs about your body weight \(which closely coincides with what you weigh right now\), it’s much wiser to make it a long term—are you ready for this?—process. 

Numerous studies have shown that if you can manage to stabilize your weight for a year, that weight will become your new norm and will likely stay off permanently. It works because you now hold a justifiable inner-belief that this is what you’re supposed to weigh… because that’s what you actually have weighed for an entire year\! 

Being able to compartmentalize your weight in 10 pound ‘stages of stability’ seems to work well. 

Allow me to use myself as an example… again. In 2017 my scale showed me in the 150 pound range. 

Most of 2018 saw my weight in the 140’s. 2019 arrived and I now weigh-in at 135. For my 5’7″ height, I think I’m looking pretty damn good\! By the time the end of 2019 rolls around, I’ll hopefully be a perfect \(for me\) 127 pounds. 

If you want to be a slim and sexy sissy, you may want to adopt the mentality of Kate Moss: 

*“Nothing tastes as good as skinny feels” *

Sissies and super models have something in common. They’re both willing to starve themselves down to achieve the desired—and required—look. 

Page 5 

**3. Sissy Makeup, Hair and Nails **

## **Makeup **

If there’s one thing that can make-or-break a sissy it’s her makeup. 

If there’s one thing about sissification that screams ‘process’, it’s makeup. If you’re not working on perfecting your makeup skills on a consistent basis, then your results in that department will be marginal at best. 

Think of it like this… if genetic girls are practicing putting on makeup everyday for years, how are you going to get really good with a once-a-month routine? 

Start regularly watching makeup videos on YouTube. Take notes. Buy more makeup. Decide on the sissy image you want your face to project. Promise yourself that you will practice getting that sissy face of yours all dolled up once a week for a year. Do this and you will be amazed by how hot you will become\! 

## **Hair **

Most sissies start off with a cheap, costume type wig. They then graduate to a more expensive, synthetic—maybe already styled—hairpiece. It’s fine to stop here as there are a multitude of moderately priced synthetic wigs now available that are truly stunning. 

The next step up with the hair process would be a human hair wig. I recently bought a Remy Hair wig on eBay and didn’t realize that many wigs that don’t come pre-styled will need to be ‘cut-in’. The bangs may be too long for your liking or there may just be too much hair, especially in the front, that makes styling it impossible or at the very least, unmanageable. 

If you don’t know what you’re doing, please don’t try to cut your new wig yourself\! Make an appointment with a hairstylist, preferably one that has some experience with cutting wigs, and let them take care of you. I had to climb out of my comfort zone to make an appointment with a stylist to cut-in my wig-with-too-much-hair… but it turned out to be no big deal. Allowing yourself to be uncomfortable at times is just part of the process of being a sissy. 

Page 6 

**Nails **

If you want to feel ultra-feminine on a daily basis, upgrading your nails will add an extra—and necessary—touch of class. Push the cuticles back and then let them grow out a little longer. Then file the sides so they look narrower and more lady-like. Finally, shape the tips to your liking. 

Having a bit of white showing beyond the tips of your fingers—french style—looks oh-so feminine. If your daring, put a coat of clear-matte polish on them and… dare someone to say something. 

**4. High Heels and The Sissy **

As a sissy, one of the most important requirements you should have for yourself is to foster an addiction for high heels. Ideally, you should become so comfortable wearing them when standing, sitting and walking, that you feel weird not wearing them. 

There is no article of feminine attire that is more gorgeous than a sexy pair of high heels. But then you gotta be able to stand up and walk in them. 

Many women advise a process of starting off small, with a 2 inch heel. Then gradually working up to 3 

inches. Finally, when you’re ready, graduate up to 4 inch heels. But remember, these are real girls doling out this advice. 

To begin with, no sissy worth her shapely shaved legs should ever put her pretty little feet into a pair of heels anything less than 4 inches tall—and I’m not talking platforms sweetie\! 

Also, I’m going to turn conventional high heel wisdom on its heel. I recommend starting off with 5″ 

heels, and then practice walking in them like there’s no fucking tomorrow. Your ‘stiletto skills’ will improve faster than you would think, if you strut around in them on a regular basis. 

Concentrate on perfect high heel posture: 

 shoulders back 

 tilt the pelvis—to a neutral position 

 activate the core—tuck your tummy in 

Page 7 

 elbows should be lightly touching sides—palms turned slightly forward 

 land with a slight heel-to-toe 

 keep legs straight—front knee locked on landing 

 take small, mincing, sissy-like steps 

 walk in a perfectly straight line with one foot directly in front of the other Once you’ve mastered a 5 inch heel, wearing 4 inch pump will be like taking a stroll in the park—

which you will be able to do—if you follow this process. For an exemplary example of impeccable high heel form, watch Claire Underwood \(Robin Wright\) in Netflix’s “The House of Cards” confidently strut about the oval office in her heels. 

Your goal is to learn to walk better in high heels than 90% of genetic girls. To be blatantly blunt, that won’t be too difficult for you to accomplish. 

**5. Dressing Like a Sissy — All Those Beautiful Clothes **

Dressing the sissy part is mostly a process of consistently adding to your girly wardrobe. Buying bras, panties, nylons, heels and dresses; not to mention accessories such as jewelry, purses and what-not is an expensive proposition, if you haven’t already noticed. 

The fun part about acquiring feminine articles of clothing is that the more you buy, the more you want. One pair of panties leads to a pair for every day of the week. Bras beg for breastforms—one of my most cherished purchases ever, BTW. A pair of high heels can, and should, lead to at least a dozen more. Pretty dresses are to die for and you will want several in your closet. 

Speaking of which… the inside of your closet will take on a process of metamorphosis. At first your male clothes may outnumber your girly stuff by 10 to 1. But that’s gonna change sweetie. That ratio should constantly be tilting toward the feminine. Begin by getting rid of all male clothing that you haven’t worn in a year. You won’t miss it. 

Now you have plenty of room for your new sissy wardrobe. That ratio—male-to-female— will even-out at 50/50 before too long. Eventually your closet will be 90% filled with with ultra-feminine sissy things. Your panty-encased clitty should be twitching at that thought. 

Page 8 

I hate to bring this up, but along the way—unfortunately—you will most likely go through a ‘purging process’ where, in disgust, you hide/put away and maybe even throw out or give away your girly clothes. 

Don’t you dare do it sweetie\! Purging is a normal part of the sissification process. It will pass. The overwhelming urge to be the sissy you were born to be isn’t going anywhere for long—it will return—

usually with a vengeance. 

Try to maintain a sense of maturity about the matter, and be ready to resume the process of buying even more gorgeous clothes when your sissy desires return… as they always do. 

**6. The Way They Walk — The Way They Talk **

Sounding and acting like a girl is a process all of its own. Girls stand, sit, walk, cross their legs and eat differently than boys. As a sissy you’ve got some catching up to do. Perfecting a girly posture and adopting feminine mannerisms will take some time. Moving and acting as a male for most of your life will take some informed education and conscious re-wiring on your part… but it’s definitely doable. 

Talking like a lady will probably be more challenging, but just like everything else about becoming a sissy, if you’re serious, you’ll find time to watch some of the awesome vocal feminization videos on YouTube. 

**7. Intensifying The Sissification Process With Orgasm Denial** If you really desire to stay in the ‘sissy fast lane’ you will want to start limiting your male masturbation/orgasm habit. After a male orgasm, your sissy desires will typically wane… and that’s not a good thing, not if you aspire to be a serious sissy. 

One way to proceed with this process is to start limiting your orgasms to once per week, and then allow yourself to cum only like a real girl. It’s called nubbing. Here’s how you do it: Put on a pair of panties and tuck your limp sissy clitty down between your legs. I always buy panties where the crotch lining is open at the top, forming a pouch of sorts. I can then tuck my sissy clit down inside that pouch. It’s a tight fit, which is what you want. Then put on a bra and insert your breast forms. Finally, slip into a pair of sexy heels and lie down on your back. 

Page 9 

Now that you’re properly prepped, began to lightly rub/nub the head of your panty encased clitty with one manicured finger—either the index or middle—only. This will take awhile, anywhere from 15 

to 30 minutes, but eventually you will experience an extremely satisfying orgasm… kind of like a real girl would have. 

It will build slowly, culminating in a very intense, long lasting climax. Your sissy juice will be deposited inside the pouch of the panties. Your sissy clit will most likely stiffen up a bit during the nubbing, but eventually you will train it to stay limp all the way to the end \(aka limp clitty training\). 

By becoming a sissy, you are voluntarily forfeiting your right to manly ways of orgasm. Consequently, this will be your default way to achieve orgasm; cumming just like a girl does. No more fucking girls. 

Sissies don’t fuck… they get fucked\! No more jerking off. That’s NOT what sissies do\! 

This is how you will cum from now on… once per week at the very most. Over time, extend the interval to two weeks, then three and finally, stay chaste for an entire month. 

If you’re weak, a chastity device—coupled with a dominate keyholder—will ensure that you don’t cheat. You want to maintain a constant state of low-level horniness which is the normal and preferred psychological place that you, as a sissy, should become extremely comfortable with. Having sex on your mind 24/7 will only enhance your sissy experience. Being denied for a month will also properly prepare you for the next step in the sissification process. 

**8. Sissygasms — Learning To Cum Like a Lady **

All sissies should aspire to reach this advanced level of sissification, which is training/programming yourself to cum by stimulation of the prostate gland only. What this means is that you will be moving past the point of needing any direct stimulation of your sissy clitty to cum… ever again\! 

This is gonna take some time princess, so be patient with yourself. To achieve this lady-like level of femininity, you will need a dildo or a prostate massager. I have a Nexus Revo—like the one pictured below—but it is a bit pricey. 

Although I have yet to cum this way, I’ve heard that prostate orgasms are of the toe-curling/pure-ecstasy variety. Sissies that have experienced these girly-girly-cums say they would never go back to their manly ways of getting off, as those types of O’s pale in comparison. 

Page 10 

The ultimate sissy orgasmic experience might be to cum this way with a man inside of you, if that happens to be your thing. 

As you’ve figured out by now, there’s quite a lot involved in becoming a sissy. Each area can make for an intensive study on its very own. Becoming sissified requires patiently following a sometimes scary—but always adventurous—path. 

Page 11 

****

**113 Things to do **

## **With Your Sissy**

\[play safe, sane and consensual\] 

*February 2023 – Ver. 1.1* 

1 

Dress your sissy up as Barbie and play like she is your doll \(fix her hair, make her pose in odd positions, etc.\) 

2 

Dress your sissy up as a French maid and her her clean your \(fill in preferable object/place/bodypart here\) 

3 

Place your sissy in front of you, on her knees, and tell her to kiss your feet and your legs. 

Tell your sissy to kiss your thighs, and tempt her with the smell of your pussy, that she cannot touch without your permission. Continue as Mistress knows best. 

4 

Dress your sissy almost but not quite as a passable woman, and bring her out in public. Let her walk behind you with her eyes down, or in front of you so you can watch your sissy walk in her high heels. Tell her that boys are looking at her. Tell her that she enjoys it, and she must enjoy it. If she does not comply with everything you may say, give her a spank on the ass, right out there in public. 

5 

Snap your sissy's panties/bra/garter belt 

6 

Have a party, inviting people with care, of course, and have your sissy dress up and serve you and your guests. This is especially wonderful if more than one sissy is involved, and more than one Mistress is present. 

7 

Have your sissy shave your legs 

8 

Lay your sissy down on a bed. Make sure your sissy is dressed appropriately for the following storytime. Sit in between your sissy's knees and keep them spread apart as you Page 2 

tell an erotic story, one that your sissy is the main character. Watch your sissy's arousal and delight in it. Continue as Mistress knows best. 

9 

Embarrass your sissy by insisting on watching her urinate while sitting down, like a little sissy should. 

10 

Dress your sissy up as a convincing woman, in a very slutty outfit, and go out somewhere public. Invite some male friends along who don't know of the true nature of your sissy. 

Make your sissy into a little slutwhore. At the end of the evening, remove your sissy's wig or lift up her skirt at the moment of arousal, to reveal your sissy's true nature to all those around. 

11 

Dress your sissy up as a little slavewhore and have her do 'disgusting' sexual things with another man/crossdresser while you watch and/or videotape, for later entertainment and/or embarrassment to your sissy. Works best when both your sissy and the other party are submissive to Mistress. 

12 

Tie up your sissy, place a large mirror in front of your sissy, then spank your sissy. 

13 

Dress your sissy as a sexy schoolgirl/intern and make her serve you. Threaten to fail/fire your sissy if your demands are not carried out. 

14 

Wave a pair of your recently used and wet sexy panties in front of your sissy's face, while she is kneeling before you. Tempt her with it and make her sniff it and lick it and rub it against her, amd make her tell you just how much she enjoys it. 

Page 3 

15 

Put your sissy into a pair of crotchless pantyhose, but do not have her wear panties. Let the part that betrays her as a woman be fully exposed. Other articles of clothing used at Mistress's discretion. 

16 

Being forced to walk nude all the time, hands restrained at neck level or to the ankles and behind the back. 

17 

you can dress him in a french maids outfit and make him serve you and Mabel friends drinks ,or make him buy tights and knicks for you or even take him out dressed 18 

Having a butt plug inserted immediately after having a large enema, then made to keep it in for an extended period. 

19 

How about completely undressing your Sissy, bring him into the bathroom and bend him over and give him a warm water enema. Then place him in a diaper and a pasifier in his mouth. Then place him in a corner on his knees where he can think about what is going to happen to him. Explain that he has to hold his water and cannot soil his diaper. If he does he will have to stay that way until it’s time to wash and thoroughly SPANK his naughty bottom\! 

20 

The biggest thing to remember is that a punishment should be something that they do not want, like or enjoy. As most sissies do actually like or want to some extent things such as public humiliation, anything sexual etc. So the best punishments go the opposite direction. 

21 

No sissy clothes for x amount of days. 

22 

No make-up or nail polish. 

23 

Only heterosexual intercourse in missionary position. 

Page 4 

24 

Masturbate through only hand on sissy clit whole watching Hetero or lesbian porn. 

25 

Treats her like a sissy, just another girlfriend to you, no sex with you, no stroking it and then there’s her new guy friend that has been staying over quite a bit. Insist that he’s in full girl mode when he comes over and he knows he’s you sissy. Very humiliating when a man is having sex with you as he’s in a cute dress, make you guy friend stay naked after he’s done and letting you sissy see his big dick while his clit is tucked in a tight pair of panties. 

26 

Add photos of what he’s wearing during the day on your Sissy blog. 

27 

Try gripping the base of his clit using 2 fingers shake it so the head slaps. 

28 

Make the sissy write out how they should be punished. 

29 

After a long oral session let him rub against your ass as reward. 

30 

Make sissy do a full body shave until completely smooth…NO HAIR NOWHERE \! 

31 

Give sissy multiple Large Douches using hot and soapy solutions to start, then rinses with clear cold water and finally with a lubricant infusion before it's sissy pussy gets deep seeded by a BBC using it like the gurl, the sissy is. 

32 

Treat them as they want to be treated like a child. They will let you know what turns them on. If humiliation is what they want give it to them. If it is pain then again punish them with a paddle or cane. I am sure they will let you know how to deal with them. 

33 

If your sissy is permanently feminized then consider getting her hair dyed a pastel shade \(pink, lilac, seafoam\) and then taking the sissy to an old style beauty salon where they will Page 5 

put her into rollers. Either for a perm or a style the sissy will gave to roller every night to maintain. 

34 

Having heavy weights hung from his balls and be forced to do chores. 

35 

Make him wear shorts exposing his thighs and pink satin panties as he does house chores. 

36 

He has to wear womens socks, anklets. You can find some androgynous looking womens jeans and gym shoes he can wear too. Some womens joggers are similar enough to mens to not look too obvious. 

37 

Take him to shopping, dressed up in her clothes like stockings, panties, bras etc. 

38 

His package should be tied up tight with a satin or silk squares. Insists that he’ll wear a cage also. 

39 

Invite your friends for a party and make him do the job of a maid, serving everyone, as the naughty ones will spank his exposed butt and squeeze his balls and silicon boobs. 

40 

When your friends come for a visit, he should serve them with a buttplug that has a vibrator which could be controlled remotely. Along with that, his mouth should be stuffed with your panty, wet with your on piss or juices and securely masked with a gag. 

41 

Make him go naked with only a chastity device and a dildo in his mouth or ass and order him do the house chores. 

42 

Lead him around on a leash with a pink collar. 

43 

Correction spankings for instance when your sissy is learning a new task and is learning these spankings are to correct poor behavior or lack of perfection, i.e the tea was not served correctly. Everything a sissy does reflects on her owner, if the Sissy identifies her Page 6 

mistake she may ask for a correction spanking - this sometimes prevents Miss from having to administer a punishment canning. 

44 

Punishment canning - intended to reinforce learning and leave a lasting impression\! When sissy has really stuffed up and generally embarrassed herself and or Miss or Misses friends 

- worst possible situation where you Embarrass Miss in front of her women friends\! 

Punishment spankings are to create a lasting impression, if Sissy is lucky she may be able to sit down in a couple of days after her canning, her bottom will be severely bruised\! 

45 

Correction Spankings - weekly canning to remind Sissy who is in charge, generally attended my Misses friends, boyfriends, other Sissys etc. 

46 

Corner time follows a Caning where sissy is put into a corner, nose on the wall, sometimes a coin is placed on the wall that sissy must hold there. Sissy holds her skirt up to display her red bottom and considers her Mistakes, this may last for an hour or so. 

47 

Forced to get fitted for a wedding dress. 

48 

Make him wear lipbalm - cherry flavor. 

49 

Make him wear clear nail polish in public. 

50 

Make him wear toe nail polish. 

51 

Make him throw out boy undies for only panties. 

52 

Make him wear a chastity cage in his panties 

53 

Make him volunteer in LGBT events. 

54 

Make him wear a extremely sissy Halloween dress . 

55 

Let your sissy “use” the back seat in the car. 

Page 7 

56 

Before he goes to work you create a smoothie for him, Apples, Banana's, Peaches etc, and a helping of cum either his own or preferably cum from a hookup, imagine the absolute sissy glee everytime he sip his smoothie at work knowing he’s drinking cum. 

57 

Wearing his normal guy clothes, jeans and a jacket etc, but underneath going overboard with feminine things, e.g. toenails painted, legs shaved, stockings on attached to a garter, a feminine frilly thong and a bra, and of course his sissy clit tucked and taped between his legs. 

58 

Make him say that he’s gay to Women. 

59 

If a hot woman is flirting with him, make him say something like 'oh me and my boyfriend went to this fabulous restaurant last week you should check it out'. Then watching as she will either show disappointment or she will try and overly praise, e.g. 'omg i knew you were gay\!' 

60 

Make him sit to pee and he has to wipe. 

61 

He has to order salads when eating out. 

62 

He has to get a fruity drink instead of a beer. 

63 

He has to keep Grindr open while walking around town. 

64 

Make him arrange hookups, flirt with nearby men, send nudes, and generally keep himself in the sissy mindset via aroused male attention. 

65 

Make him wear a butt plug while out in public. Because it makes his asshole wet and feel like a pussy. It keeps him primed to be fucked. 

66 

Make him wear a "purse" that he can take with him whenever he goes out. 

Page 8 

67 

He should always these items with him: lipstick, wet wipes, lube, condoms, weed, thong, eyeliner, lip gloss, bubblegum, lollipop. 

68 

Write dirty text on his body cumdump, slut, cock sleeve and so on. 

69 

Make him cum on his face and then go out in public after it have dried out. Knowing he has got cum on his face while people watch him go by. 

70 

Slap him across the face. Relatively minor for some people. But it could be an emotional trigger for him in a way that a whipping is not. 

71 

Having him wear a chastity belt for much of the day and only getting to cum when you let him. 

72 

Stuff your used panties in his mouth as a gag. 

73 

You could have him wear a remote control plug while you're out and about. Give him a buzz in a public place. 

74 

Require him to be over the top chivalrous and differential to you in public settings. 

75 

Decide what he is to wear for the day. Decide what he is to eat for the day. 

76 

You could dress him as a maid and have him clean your living space with a large plug in. 

When he's bent over scrubbing something you pull his skirt up, pull the plug, and drill his ass with a strap on. 

77 

Have him lick your pussy clean after you've peed. Don't wipe. 

78 

Bind him and have him perform fellatio on a dildo you've stuck to a wall while you fuck him from behind. You can make this a game. If he makes it all the way to the bottom he gets to cum. 

Page 9 

79 

Write or have him write dirty things all over his body with sharpie. Some could be his other tasks for the day or punishments yet to come. Some could be marking off spots to hit later if you do impact. Then have him spend the day out and about while secretly covered in filth. 

80 

Setting a nail salon appointment for your sissy partner can be humiliatingly fun. Picture his reaction when you tell him to be at a specific nail salon for his mani/pedi appointment you booked. Be sure to let him know that he doesn’t need to worry his pretty little head, because you took care of all of the specifics. For my husband, I always request clear nail polish, rather than a color. I don’t want him to be humiliated in an unappreciated manner, but my friends have made their husband get pink toenail polish as a punishment. Similarly, you can also schedule waxing and tanning appointments for your sissy. 

81 

The Strapon is one of the best tools to clearly establish who is the superior in the relationship. Unfortunately, many wives draw the line here and refuse to peg their spouse. 

They are really missing out. Wonderful things can happen with pegging your lingerie clad husband. First, it will break down some of the mental barriers he may have been desperately holding onto in the relationship. When he is screaming like a sissy bitch the first few times and be squeamishly embarrassed afterwards due to mixed emotions, he will love you even more after definitively taking control of him. 

82 

Make him take a bike ride with a plug in. 

83 

Make him Use sanitary napkins or tampons that women usually use during menstruation, it can be enormously exciting for some males. They see this is the ultimate humiliation, Page 10 

and the turn on is in the submission. Others are aroused by menstruation and playing at it for themselves is arousing because it takes them close to the mystery. For many men, it is both of these factors that make wearing a pad against their cock exciting. 

84 

Ask the sissy to do the housework wearing nothing but a slave pink collar. Within this relationship, the sissy relishes in the sensation of being controlled. Accessories such as nipple and genital clamps, whipping, spanking, wax, or ice cube play very often form part of such relationships. Services often include fetching drinks and cleaning. Make him dress up in a maid or nurse outfit to bring a more realistic sensation to service-oriented submission. 

85 

Include Sissy maid training, which is a common subset of sissy training. During sissy maid training, the submissive generally dons a frilly, skimpy maid’s uniform and performs a range of duties, from household chores to sexual acts. At all times, the maid must behave in a submissive fashion.
Sissy training is a process. It requires a commitment and trust by the submissive.
pretending to be a school girl, a boundary that could not be crossed in real life. Acting it out provides in session is a safe and legal way of acting out this fantasy. 

Costumes and props are used in role play to enhance the experience. 

86 

Try Petticoating which is a type of fantasy role play involving a submissive man being coerced into dressing in female clothing. This practice originated as a form of punishment in Victorian times, or even earlier. Petticoating helps to achieve sexual arousal with a dominant female figure humiliating them. This term is also used to describe a subgenre of Page 11 

erotic literature that involves this practice. A man is typically petticoated as a punishment for bad behavior. 

87 

Force him to wear an article of feminine clothing, such as bra or panties during the role play. Some disciplinarians go beyond clothing, forcing men to carry dolls, purses, to wear make-up. While petticoating is intended to modify the behavior deemed unacceptable, men can find they enjoy this punishment and receive sexual thrills from engaging in it. 

Their pleasure is enhanced by the element of humiliation petticoating brings. This humiliation may come from the actual humiliation resulting from their submission, or the potential humiliation that may come if their secret enjoyment of this practice is dicovered. 

While the aim is to be humiliated, many men find a love of the physical sensation of wearing women’s clothes, clothes are typically made from soft, sensuous fabrics. Much more arousing than traditionally masculine attire.
 Petticoating themes include acting like a little girl, and/or playing the role of an ultra-feminine "Sissy" French maid. 

88 

Try Ejaculation Reflex Sensation on him. The prostate can never be touched directly. 

Indirectly it can be accessed via the rectal wall, with a membrane dividing them. This membrane is a bit like the thickness and flexibility of a latex glove. The lobes of the prostrate, under these circumstances, are highly sensitive to pressure with a selection of sensations produced by pressing, rubbing and/or stroking the gland through the rectal wall. At its ultimate these feelings touch on the sensation which occurs during ejaculation, as the prostate gland starts pumping up sperm. 

Page 12 

89 

At least one third of his penis is buried inside his body. With some men it is a little more, with others a little less. It is at the base of this penis, the part that is hidden, which may be manipulated in the same manner as the prostate. The effect this can have, of stimulating all three, if done at the same time as genital stimulation, is out of this world. There is just not the physiological effects, but also the psychological aspect in regards to a G-Spot massage to experience. 

90 

The physiological stimulation is nothing compared to greater psychological and/or mental elation. The act of him placing himself into such a submissive, vulnerable position, induces a powerful mental high, for both of you. A man who may be ‘in charge out there, in the world’ is able to grant himself a vulnerable, in some cases new role… now as a submissive. 

This is something that many women get emotionally touched by. 

91 

Include external prostate massage with your Lingam massage. This is accessed outwardly and will appeal to all men, but especially those who do not like to receive contact with the prostrate internally, via the anus. A Lingam massage, combined with the Sacred Spot \(prostate\) massage, helps to improve and control a man’s sexual energy. It is highly recommended for men who have premature ejaculation and/or erectile dysfunction. A massage combined with a Lingam and Sacred Spot massage is referred to as a 'happy ending' massage. This is because of its ability to deliver relaxation and deep sexual pleasure in one package. 

92 

It is the little feminine gestures during sissy play – the arch of a wrist, the brush of a slip, the twirl of a lock of hair – that really heighten his position as a sissy during play. One of Page 13 

my favorite little gestures throughout the day is to make him pretend his chapstick is lipstick. When you want him tap into sissy mode, make him go to the restroom. When no one else is in there, make him stand in front of the mirror, and envision himself in his favorite sissy outfit, and then he carefully apply his chapstick as though he’s applying lipstick. A careful swipe on the left half of his upper lip, then an equally careful swipe on the right, a gentle pass on the bottom lip, then he blot and pucker. If anyone walks in on him he pretend he was washing his hands. 

93 

Rather than stand in front of a gross urinal, whenever nature calls, make him sit his adorable sissy behind down like a lady. After years of standing and going with a quick zipper drop, it is oddly feminizing to suddenly be sitting down to tinkle. 

94 

You have to be careful to not overdo it on this one, but where you can, opt for pink office supplies for him. A pink highlighter. Pink post it notes \(buy a pack of pastels for the office and just happen to grab the pink ones\). A purple ball point pen. No one is going to notice, but he can say to himself every time he picks up those femininely colored items, he can think to himself, “I’m choosing pink like a good sissy boy.” 

95 

Buy some “manties” for him. One of the most common suggestions for bringing his sissy side to work is wearing panties under his clothes. That’s fine in a lot of cases, but it can be too much for some sissys. You should love manties. That’s a fancy way of saying man panties. Normally he wears boxer briefs, but make him buy some pairs of very fancy men’s underwear. Nylon or silk, mainly in girly colors like purple or pink. They should be snug briefs or even thongs. Make him wear those cuties to the office, under his jeans. If anyone Page 14 

sees the waistband, they look just like men’s underwear \(although maybe a little eccentric\). No risk of getting caught. But every time he moves or go to the bathroom, he gets a subtle reminder that he’s sissy and have to wear special, delicate panties like a good girl. It can be a major rush. 

96 

Make a video of him doing the mini walk of shame to the bathroom after being fucked hard by your strap-on dildo while in his sissy female attire. 

97 

Make him remove all his male underwear and cut them up in front of you. Have him pick out his own clothes when you go shopping make comments on how sexy he would be in it. 

Start with panties and move forward this will allow you to see him in a submissive state and also allow you to see his progress. 

98 

Make him sleep in a dog cage in a diaper in case he has to pee with a padlock on the cage so he doesn't bother you. Dress him in his cute little nighty with a medium butt plug and his little tits. This promotes dreams of submission. Sometimes allow him to sleep in the bed but he is tied face down in a dipper so he can have access to his pussy if you want to fuck it. 

99 

I guess you have extremely limited experience applying makeup to a person. Great\! The less skilled the better for this part. The goal here is not to make her look beautiful – it’s to make her look like a cheap hooker. So start with some foundation. Then the lipstick. Make sure to choose something extra bright and garish, and once she gets her lips nice and taught for you, smear it liberally on. 

Page 15 

100 

Make him look into the mirror and ask questions. What do you see? A manly guy? Tell the mirror that you are not a man. Tell it out with your normal voice that your mirror can hear it and he can say it to you. Repeat it 3-5 times. Now tell the mirror that you are a sissy. A weak little sissy girl. Same volume. Repeat it till you feel fine with telling it. Okay now go online and order yes order your first nice girly panties. Why order? I know you are to afraid of buying it by yourself so order it. Did it? Good girl. Now tell yourself that you deserve the nice soft feeling of a girls panty on your butt and clitty and that’s it. Tell me if you have done it\!\!\! It is important to know how you feel now for further tasks. 

101 

When you’re in a bar, cafe, or restaurant, discreetly go into the toilet and remove your panties. Upon your return, pass him the panties and order him to go into the bathroom and put them on. Of course, you ensure the panties are fairly soaked with your pussy juices. Knowing he’s walking around with your messy panties wrapped around his chastity caged cock is an enormous turn on for both of you. 

102 

Make him go to the beauty salon and have his hair set on perm rods and styled in a cute feminine style. 

103 

Have his makeup done appropriate for evening occasion. 

104 

Make him vacuum the house wearing negligee \(windows open\!\). 

105 

Make him pick weeds from front flower garden \(maid uniform\). 

106 

Make him serve dinner to you naked wearing only a pink collar. 

107 

Make him shop rummage sales for panties, slips, and bras. 

108 

Make him go to hardware store in a girly dress and shop for kitchen faucet. 

Page 16 

109 

Make him serve Mistress and her friends in maid uniform. 

110 

Make him lower his tone. This is quite possibly the most difficult thing to address and overcome. This is something he has to keep reminding himself and practicing every day. 

To be more feminine, he should speak softer and calmly. This should also be reflected in his text messages, speaking on social media etc. 

111 

Book a manicure appointment for him. Having groomed hands and nails is an instant step to becoming and feeling more feminine. Let’s face it, dry hands with not looked after nails look like they belong to a manual labourer, rather than a chic and elegant lady. And who doesn’t feel amazing after having their nails painted and properly looked after? To truly embrace his feminine side, he should opt for a soft pink or a pastel color and keep his nails on the shorter side. 

112 

We are looking for him to become her and have soft, smooth and glowing skin, you can make him do this feminine body care routine: 

- Hair mask 

- Face mask 

- Body hair removal – Veet 

- Body wash 

- Exfoliate 

- Shave 

- Moisturise 

- Skincare 

Page 17 

113 

Make him set a Sissy Password. Cyber security experts say a great trick for creating a computer password that is very difficult to crack is to make an acronym from a distinct phrase. For example: Immbfit3g. Which is short for “I Met My Best Friend In The 3rd Grade.” Building on this logic, you make him a little sissy phrases and affirmations for his passwords. For example: 

Yaavplg – You Are A Very Pretty Little Girl 

Ywt1piabp – You Would Take 1st Place In A Beauty Pageant 

Iaabsg\*c\* – I Am A Beautiful Sissy Girl \*curtsey\* 

Have fun with it and build something unique to him. And then, every time he logs into his work computer or his email, he gets a subtle reminder of what a sweet little thing he is. 

Page 18 

**What makes a good sissy? **

1 

Passiveness 

2 

Femininity 

3 

A hairless body \(from the eyebrows down\) 

4 

Extremely small 

5 

Always soft penis and small testicles 

6 

Love giving \(sex\) without expecting reciprocation 

7 

Girlish figure 

8 

Loves wearing slutty feminine clothing 

9 

Calm demeanor 

10 

Soft voice 

11 

Willingness and desire to do household chores 

12 

Always horny and available for literally anything a man \(or woman\) wants 13 

Loves to give oral sex 

14 

Desire to be disciplined, controlled and continuously trained to be ever more feminine and unreserved sexually. 

Page 19 

**What makes sissies so appealing? **

1 

A sissy really wants you to enjoy having sex with her. 

2 

You can satisfy your fantasy of sexual domination. 

3 

She is not going to complain or ask you to respect her. 

4 

She's not going to make a drama for anything. 

5 

A sissy is not offended if you tell her that she is your whore because she wants to be your whore. 

6 

She loves your masculinity, your cock and your balls. 

7 

You can spank her butt when she walks past you and she will be happy. 

8 

You can ask her to dress the way you like and she will try to please you. 

9 

You can put a cage on her sissy clit without problem. 

10 

You can ask her to wear a tail with a butt plug and she will do it. 

11 

You can ask her to suck your cock while you watch TV and she will be happy. 

12 

Your sissy loves to get your cum and swallow it. 

13 

You can end up on her ass, on her face, in her mouth or anywhere on her body and she will be happy. 

14 

You can cum in the sissies 'pussy’ as much as you want. When a guy with a big dick and full set of balls is neglected for long enough, his sissy friend will becum his favorite hole. 

15 

A sissy really wants you to enjoy having sex with her. 

16 

You can satisfy your fantasy of sexual domination. 

Page 20 

17 

She is not going to complain or ask you to respect her. 

18 

She's not going to make a drama for anything. 

19 

A sissy is not offended if you tell her that she is your whore because she wants to be your whore. 

20 

She loves your masculinity, your cock and your balls. 

21 

You can spank her butt when she walks past you and she will be happy. 

22 

You can ask her to dress the way you like and she will try to please you. 

23 

You can put a cage on her sissy clit without problem. 

24 

You can ask her to wear a tail with a butt plug and she will do it. 

25 

You can ask her to suck your cock while you watch TV and she will be happy. 

26 

Your sissy loves to get your cum and swallow it. 

27 

You can end up on her ass, on her face, in her mouth or anywhere on her body and she will be happy. 

28 

A sissy cannot get pregnant. 

Page 21 

199 Sissy Tasks 

\[play safe, sane and consensual\] 

* *

*March 2024 – Ver. 2.0* 

1. 

One humiliating term written on body until it naturally washes off. 

2. 

Wear Panties for 24 hours. 

3. 

Shave your from your neck and down. 

4. 

Make a text post online \(Blog, Reddit, X etc.\) describing a task you have completed. 

5. 

Post a dressed selfie to \(Blog, Reddit, X etc.\) \(bra, panties, makeup and wig\). 

6. 

Wear nipple clamps out in public. 

7. 

Wear a wig in public 

8. 

Swallow two loads of own cum at the same time. 

9. 

Edge once every five minutes for 1 hour. 

10. 

Drink a glass of soy milk. 

11. 

Create a Chaturbate account \(or similar\), and show some of your body. 

12. 

Jerk off a Real Cock. 

13. 

Suck off a suction cup dildo on your knees. 

14. 

Leave a complimentary comment on a dick picture online. 

15. 

Paint your toenails. 

16. 

Give yourself a face full of cum \(in yoga plow position\). 

17. 

Download Grindr \(use a photo of yourself as a profile picture\). 

18. 

Squat once per 10 seconds for 5 minute \(naked\). 

19. 

Wear a bra in public \(under your shirt\). 

20. 

Vibrate yourself to orgasm with a Magic Wand. 

Page 2 

21. 

Make a Pornhub account, and make a public list of preferred Sissy videos. 

22. 

Watch Sissy Hypno for at least 10 minutes 3 days in a row . 

23. 

Wear Heels. 

24. 

Swallow one load of your own cum 

25. 

Create a sissy caption and post online. 

26. 

Wear a Chastity Cage for 24 hours. 

27. 

Make a Fetlife Account. 

28. 

Paint your fingernails. 

29. 

Do Yoga in tights. 

30. 

Cum on a food item and eat it. 

31. 

Suck a dildo, constantly pushing your limit \(train your gag relex\). 

32. 

Complete an Achievement on Pornhub. 

33. 

Practice Talking in a girly voice. 

34. 

Wear a collar. 

35. 

Put a buttplug in your ass. 

36. 

Finger your ass, and lick your finger clean. 

37. 

Wear light makeup in public. 

38. 

Fuck a dildo, use a sucktion cup dildo. 

39. 

Cam on Chaturbate or similar \(panties, bra, and wig minimum\). 

40. 

Make a Reddit Account 

41. 

Get a Facial from a Real Cock. 

Page 3 

42. 

Post a picture using a sex toy to a Blog, Fetlife, Reddit, X etc. 

43. 

Shave pubic area. 

44. 

Apply three squirts of Female Perfume. 

45. 

Shave your legs. 

46. 

Have a girl tell you that you have a small cock. 

47. 

Perform an enema. 

48. 

Put on girly deodorant, before you are going to the gym or other sport. 

49. 

Spank your ass 30 times each cheek 

50. 

Buy breast implants. 

51. 

Get gangbanged by three or more men. 

52. 

Get a sissy tattoo and wear it for 48 hours. 

53. 

Shoot Professional Porn. 

54. 

Perform a sexual act with a Real Cock over 7in 

55. 

Get three or more facials at same time from Real Cocks. 

56. 

Photos or video of you being Gangbanged by three men. 

57. 

Tell a friend or family member you are a Sissy. 

58. 

Eat cum from a pussy creampied by a Real Cock. 

59. 

Suck yourself until you cum. 

60. 

Eat a pussy while it is being fucked by a Real Cock. 

61. 

Let a fuck machine pound your ass \(60bpm minimum\). 

62. 

Go ass to mouth 25 times with a dildo 

Page 4 

63. 

Go 24 hours without an erection \(no chastity allowed\). 

64. 

Facefuck a dildo \(80 bpm minimum\) 

65. 

Swallow more than three loads of own cum at same time. 

66. 

Watch a Real Cock fuck a woman while in chastity. 

67. 

Tell a colleague you are a sissy. 

68. 

Earn more than $50 camming on Chaturbate or similar in one session. 

69. 

Get Pegged. 

70. 

Perform a blowjob on a Real Cock with another sissy or woman. 

71. 

Get Spitroasted by Two Real Cocks 

72. 

Wear heavy makeup. 

73. 

Go outside fully dressed \(girly top, girly bottom, panties, bra, and wig minimum\). 

74. 

Deepthroat dildo every ten seconds for 3 minutes. 

75. 

Tan with a bikini on. 

76. 

Fuck a Real Cock. 

77. 

Grow hair to shoulder length. 

78. 

Tell a female friend you are a sissy 

79. 

Suck a Real Cock. 

80. 

Suck a Strap-on. 

81. 

Post a Video on PornHub \(1 minute minimum\). 

82. 

Swallow a load from a Real Cock. 

83. 

Verify your Chaturbate \(or similar\) Account. 

Page 5 

84. 

Verify your Pornhub Account. 

85. 

Create a sissy hypno video and post on Pornhub \(1 minutes minimum\) 86. 

Take a supplement made for a woman \(ex. butt enhancing, estrogen promoting, etc\) 87. 

Pluck Eyebrows. 

88. 

Have a Sissygasm. 

89. 

Give a blowjob to a stranger at a glory hole \(use condom\) 

90. 

Drip fake cum on your face to make it look like you got a facial. Let it dry and don’t clean it off for at least 3 hours \(or until someone has seen you—whichever comes first\). 

91. 

Dress as slutty as you can \(full makeup\) and talk with at least 3 people. 

92. 

Line up your dildos and plugs from small to Bad Dragon. Starting with the smallest and working up, use each item to fuck your ass for at least 2 minutes each. Finish with the Dragon and record how deep you get it into your ass. 

93. 

Each time you need to pee, use a different room and receptacle. Some suggestions: on all fours onto a towel, in the shower, into a glass, outside or on a balcony into a bowl… 

94. 

Spend the evening on all fours like a good piggy. If you have a suction cup dildo, attach it to a wall and fuck it every hour on the hour for 5 minutes. That’s the only time you’re allowed to cum. In between it’s edging and if you need to pee it’s on all fours. 

95. 

When you’re ready to cum, open the window and cum loudly near it. Make sure the curtains are open. 

96. 

See what you can trade sex for \(anything but money\). 

Page 6 

97. 

Open the curtains wide and crack the window. Get on all fours fairing away from the window \(so your ass is facing it\). Cum loudly at least once there \(more the better\). 

98. 

Free Use - put yourself out there and don’t say no to anything \(safety first\!\) 99. 

Extreme hookups - try to hook up with guys with the biggest and smallest cocks, shortest and tallest guys, super vanilla and super kinky 

100. Go full femme: hair, makeup, clothing, underwear then make and post a video of yourself doing a sexy striptease \(wearing a lace mask\). 

101. Send some non-face nudes to a random person. 

102. Try these for a week each: no touch, edges only, anal only, cum only away from home 103. Get a remote control vibe and let someone else control it while you’re in public 104. Only allowed to touch yourself with pictures of feet / feet porn. If you watch other porn, you must stop touching yourself immediately and switch to something that repulses you. 

105. Drink two large glasses of water, then edge. 

106. Wearing jeans, wet yourself away from your home. 

107. Wear blue jeans or grey track suit bottoms \(light colours will show more btw\). Then drink a large glass of water/liquid. Wait 30 minutes and go somewhere public and wet yourself. 

Then walk back to your car/house. 

108. Not use the toilet to pee for a full day. Pee in the shower, sink, a bowl, outside, etc. instead. 

109. Give yourself an orgasm in your car or a changing room. 

110. Pee in a sink in a public restroom. 

Page 7 

111. Buy something in a drive thru and have your lower body exposed; cum in a cinema; play with yourself under the table at a restaurant or bar. 

112. See how much of the 16” dildo you can get inside you. Do your best at the start and end of the week to see if you improved after a week of depravity. 

113. Wear the shock buttplug whenever you’re outside the house \(apart from work\). Give yourself a shock anytime you hear a number spoken. 

114. Get naked in a wilderness area. 

115. Cum in a cinema. 

116. Go through a drive through with no pants 

117. Put something massive into one of your holes—larger than you’ve ever done before. 

118. Each time you go shopping, you need to buy at least one thing you could use in a sexy way \(to masturbate, use with a partner or wear\). Post pics or descriptions of your purchases. 

119. Make an audio recording telling what a whore you are. Cum on the recording. 

120. Spill yogurt on your clothes. Wipe it off with a dry towel, then go somewhere in public. It’ll look a lot like dried cum. 

121. Purchase at least 5 items of various sizes that could be used for insertions—one of each veg/fruit only. Carry them with you for your whole shop ideally in a clear bag or in plain view as much as possible. 

122. Wear a diaper all day without changing it. Go somewhere in public with it on before bed. 

123. Get on Tinder and set it for all ages and genders. Meet up with the first person who you match with and \(safely\!\) make them cum. Nothing else, just an orgasm and go home. 

Page 8 

124. Get 5 vegetables of increasing size: carrot, cucumber, zucchini, etc. Use them in your ass from small to large later. As a bonus, eat at least one afterwards. 

125. Wear your collar. Each time you cum, write something on your skin. Start with “cumslut” 

and “Sissy whore.” 

126. Whenever you touch your small clit, make sure you have something in your ass or on your nipples. 

127. Dress in tight clothes and go for a run/walk. Drench your top with water before you go out—no bra. 

128. Fuck yourself with a banana, then eat it afterwards. 

129. Make a salad and dip each piece of it in your ass before you eat it. 

130. Piss yourself first thing in the morning and wear those clothes the rest of the day. 

131. Lick all toys and fingers clean after use. 

132. Dress provocatively when you leave the house with no bra/underwear when possible. 

133. Always wear a day collar outside the house. 

134. Offer men to give them a hand job. For humiliation, the price is $5. 

135. Make a list of 10 little household jobs \(wash dishes, vacuum, etc\). Strip and complete each job, pausing to tease yourself between each job. Don’t do anything else until those 10 jobs are done. If you want more, play porn in the background or a Sissy hypnosis video while you work. 

136. Spend an hour on all fours—staying off the furniture. Place bowls of food \(cereal is good\) and water on the floor. Put something on your neck as a collar. Be sure to put some doggy Page 9 

toys on the floor. You can’t use your hands, but may grind to edge. If you’re really up for it, pee at least once like a bitch on some papers or towels on the floor. 

137. Attend your online class nude from the waist down. 

138. Study for 6 x one hour blocks of time wearing a plug \(take a 5-10 min break between blocks\). If you don’t put in a whole hour, edge wearing your clamps and apply tiger balm before the next session. 

139. Write 10 degrading names on your legs. I’ll give you a few to start: cumslut, pain whore, fucktoy, cocksucker… 

140. Wear a buttplug out somewhere in public under a skirt or dress \(no panties\). 

141. Edge in each room of the house in a day. 

142. Wear and use only diapers for 24 hours. 

143. Body writing. Add one item on your body each hour from morning to bedtime. 

144. Make a slutty audio recording, and post it online. 

145. While working you must have WHORE, SLUT, or FREEUSE written on areas of your body the laptop camera can see. If you are to have a zoom call that day, the writing still exists but under your clothes. However some small amount of the letters must still be visible. 

146. Wear a buttplug \(size XL\) for 4 hours. Then fuck your ass with a dildo \(size XL\) for 20 

minutes. Keep going even if you cum. 

147. Wear a buttplug \(size L\) for 1 day. 

148. Cum from anal 2 times in 1 days. Use a dildo or prostate massager \(size XL\). 

Page 10 

149. Spend 14 days in chastity while wearing kinky underwear. You can cum only from anal and you may not touch you penis \(only when cleaning\). 

150. Spend 7 days in chastity while wearing kinky underwear. Wear at least one piece of clothing \(skirt/dress/pantyhose/stockings/heels etc\) during the day for at least 4 hours \(can be hidden under clothes\). You can cum only from anal. Make sure your crotch and armpits are shaved. 

151. Spend 2 days in chastity while dressed like a girl - underwear, makeup, nails, wig \(long hair\) and cute clothes. Cum from anal at least once. Make sure your whole body is shaved smooth. 

152. For 14 days - edge 1 time every day. If you cum, add 7 days to your time 153. For 10 days - edge 2 times every day. Keep yourself in chastity for the rest of the time. If you cum, add 5 days to your time. 

154. For 7 days - edge 3 times a day. Keep yourself locked in chastity for the rest of the time. If you cum, add 3 days to your time. 

155. Hold a 1500ml enema \(any liquid\) for 15 minutes. 

156. Take a 1000ml enema for 10 minutes and drink at least 200ml \(10oz\) of piss in the meantime. 

157. Fill an enema bag \(container\) with 600ml of piss and run the tube down to your mouth. 

Slowly drink it all up. If you tie yourself and use a gag, you can go with just 400ml of piss. 

158. Go in chat or online and request 10 lewd tasks to perform. Take photos/videos while performing them and share them with the others. 

159. Do a 1 hours live stream and perform any sex acts others request in chat \(use a mask\). 

Page 11 

160. Go outside and take a 30 minute walk wearing at least one of the following: fully dressed as a girl or in latex / wearing a tail, animal ears and a collar / wearing chastity cage, a buttplug and a small vibrator / wearing a rope harness, clothespins and cuffs. 

161. Spitroast yourself for 30 minutes with two suction cup dildos \(sizes L and XL\) 162. Fuck yourself in the ass with a dildo \(size XL\) for 20 minutes. Leave it in and then give another one \(size L\) a 15 minutes blowjob with at least 50 deepthroats. 

163. Insert a dildo size XL in your ass and leave it in. Then deepthroat another one \(size L\) for 5 

seconds - 15 times. 

164. For a period of 1 days - wear animal ears, a collar and a tail. Drink and eat from a bowl on the floor. Walk on all fours. Sleep in a cage. You may have four 30 minute rests. 

165. For a period of 4 hours - wear animal ears, a collar and a buttplug tail and tie yourself in a bitchsuit position. 

166. Spread your sex toys or other objects \(20 minimum\) around your apartment so that they could easily be reached by a toddler. Apply animal ears and a buttplug tail. Tie yourself in a bitchsuit position. Start collecting your toys one by one by bringing them to a common place with your mouth. You are done when all the toys have been gathered at one place. You have 3 

hours. 

167. Wear four pieces of fetish clothing or a catsuit for 1 day. 

168. Wear a full catsuit \(bodysuit\) made of out latex/leather/pvc or vinyl for 12 hours. 

169. Wear a full catsuit \(bodysuit\) made out of latex/leather/pvc or vinyl and a gas mask for 6 

hours. 

Page 12 

170. Insert a 8.5mm x 80mm sound 30 times. 

171. Insert a 11.5mm x 120mm sound 10 times. 

172. Wear a catheter 7.5mm x 70mm for 3 hours. 

173. Masturbate to the point of orgasm and continue all stimulation for 5 minutes after cumming. 

174. Masturbate to the point of orgasm and continue all stimulation until you cum again. 

175. For a period of 7 days edge 3 times a day but don't cum. Then on the last day cum 5 times. 

176. Give a blowjob to a dildo \(size L\) for 45 minutes and use cum \(real or fake\) as lube. Reapply it every 5 minutes. 

177. Deepthroat \(23cm/~9inch\) a dildo \(size XL\) 40 times in one sitting. After you're done deepthroat it another 10 times for 6 seconds each. 

178. Use a squirting dildo \(size L\). Give it blowjob for 15 minutes with at least 30 deepthroats \(19cm/~7.5inch\). On your last one, deepthroat it as far as you can and squirt 50ml of fake cum down your throat. 

179. Gag yourself with your fingers 10 times. 

180. Make a clothespin zipper that runs from one of your breasts, around your navel and back to the other breast \(20 clothespins minimum\). Keep it on and spank your ass until it becomes red \(50 times minimum\). Then pull the zipper hard and fast. 

181. Attach clothespins to your nipples and insert a buttplug/vibrator/dildo in your ass. Tie yourself in a hogtie/frog-tie/mummy-tie for 1 hours while blindfolded and gagged. 

Page 13 

182. Go in chat or online and request 10 slave tasks to perform which preferably include bondage and pain. Spank your ass hard 20 times and your balls/pussy 10 times for every task you refuse. 

183. Wear a different Pantie color for each day of the week…or a different style for each day. For example, Monday can be pink or thongs and Tuesday can be purple or fullback panties. 

184. Dresses up as a Sissy and take lots of photos\! Send it to a partner or online friend, they can use that as “consensual blackmail” in the future. 

185. Take a friend to the mall and shop for some sexy panties together. 

186. Suck A Big Fat Cock, this is something that every sissy maid should be able to do\! Start small with a small vibrator or dildo before you move up to something bigger. When you are ready, you can move on to the real thing. But be sure you get lots of practice in before trying it on a real cock so you will not embarrass youself. 

187. Go out to the bar, a dive bar or a gay bar the guys that go to that scene are exactly who you want to approach. Go there and try to talk to some guys while wearing your sissy outfit. Your sissy task for the night is to ask at least 3 guys if you can suck their cocks. Ideally, it’ll be something like in the bathroom or in the parking lot. Make sure to record everything. 

188. Dress up in a pretty outfit and go to the local mall. Your task will be to go to the makeup desk at a big department store and ask for some help or advice on picking out some new makeup. Pick up a concealer or do your eyelashes or pick out a new lipstick. Wear a vibrating butt plug and turn it on when you ask for help. 

Page 14 

189. Dress up as a princess – this works best if you are going to some kind of costume party at a bar or house party. The sissy goal for the night is to make out with someone at the party in your sissy outfit. And remember: you need a picture or it didn’t happen. 

190. Servicing your mistress’s bull is one of the great pleasures of life\! After all, you are taking care of the person giving your Mistress so much pleasure. Learn what he likes and put your blowjob skills up to the test. After all, you must be a good fluffer for her. 

191. A good sissy should take proper care and groom herself. And this means all body hair as well. So shave/wax those legs, armpits, arms, back, chest, and pubic hair\! A favorite is going to the salon to get a real waxing. Now only is it humiliating, but it will be painful too. 

192. Go out to the salon, or to the movies. The catch is you must be wearing a vibrating butt plug that. Imagine being out in public and having a sissygasm. Then you’d have to hide your wet spot or else everyone can see. 

193. Why does he have holes if they aren’t meant to be used…There’s nothing like bending over and have her taking your ass. And don’t forget to call her daddy while she pegs you\! In fact, say “thank you, daddy” every time she thrust into your sissy hole. A pegging session is always a great way to submit. 

194. Shrink your “dick”. The best \(and most fun\) method to accomplish this is with chastity. 

Long-term chastity can effectively shrink your manhood. Why? Well, when you go a long time without an erection, collagen, smooth muscle, elastin, and other erectile tissues will begin to deteriorate. Over the long run, this can result in a loss of penis length and girth along with Page 15 

weaker erections. All in all, chastity is very effective, painless, and a fun way to shrink your manhood. With each passing month, your manhood is getting smaller and smaller. 

195. Train to be as feminine as possible. Makeup is in the advanced tier because it requires more work and skill as opposed to putting on a pair of panties/thongs. But that’s no excuse not to train to get good at putting on makeup. Watch a bunch of makeup tutorials on YouTube before getting some practice in. After every practice, rate your makeup skills from a scale of 1 

to 10. And if you’re not improving, put yourself into chastity for longer to incentivize yourself to improve your performance. 

196. Cum in your chastity cage. It’s kind of like having a ruined orgasm. The cum kind of just dribbles out like with a creampie pussy. Now, keep in mind, you have to be REALLY horny in chastity to be able to cum like this. 

197. Do a Twitter RT Game. Creating a Twitter re-tweet \(RT\) game is also a great way to get exposed. For example, you can do a chastity RT game by posting a photo of dressed as a chastity sissy all locked. Here would be the terms of the game: Comments = 3 days in chastity 

RTs = 2 days in chastity 

Likes = 1 day in chastity 

Make the game last 20 minutes and see how many comments, RTs, and likes it can get. 

This is kind of like “crowdsourcing” your chastity sissy lockup. 

Page 16 

198. Record a video of sucking a big fat cock. Don’t forget to make the cock owner you’re you instructions/tips and call naughty things while you’re doing the dirty deed. Watch it on repeat over and over again. That’s perfect if you want to edge… 

199. Go through airport security…with your cage on. Now, for most airports, going through with a plastic/resin chastity cage \*should\* be fine…keyword: should. 

But you never know if you will set off the detector at airport or if the security guards want to do some extra screening. However, just the thought and idea of being caught like that should get your heart racing at 1000 miles an hour. What would you say to the security guards? That you’re wearing a chastity cage? Would they request a private screening? 

Oh…it’s so humiliating just thinking about that conversation haha. 

Page 17 

****

****

****

****

****

**108 Tips to be **

## **The Perfect Girly Girl **

****

\[play safe, sane and consensual\] 

*February 2023 – Ver. 1.2* 

## **Clothes and Style **

The main color should be pink, or baby blue, or any pastel color if you really want to be girly. Of course, you are your own person, but this is just for the girly girls. Have flouncy little skirts and vest tops teamed with short-sleeved floral blouses in summer, as well as little colored pumps. Another good summer look is short shorts in spunky, bright colors. For winter, invest in cuddly, knitted items in paler colors, preferably grey, blue and silvery colors. On Christmas day wear something red or green, really pretty and cute. For autumn, browns, reds and autumn-leaves colors look pretty and summer style is the same as spring. For sleepwear, go for cute PJs like Cookie Monster ones, or really girly ones with PJ shorts \(Forever 21 is good\) and colored, patterned camisoles and vests. For colder nights, go for cuddly-warm button-ups with long trousers and long sleeves. Go for a pink knee-length silk bathrobe, too, and fluffy mule slippers or velvets. For the Strawberries and Milkshake theme, go for strawberry-printed, pink things. 

Have a sense of style. Being fashionable is important. Try to read more fashion magazines to learn what kinds of clothing go well together. Try mixing and matching the clothes in your closet. The results may not always be great, but you're bound to discover new and cute combinations. 

Be sure to create your own fashion and have your own style, because it's not right to wear something that just isn't you. It's often better to have a basic personal style than to always be chasing the latest 

"fad" look. You could waste hundreds of dollars on clothes just for them to go out of style a few weeks later. When buying clothes to set up your wardrobe, buy the girly girl basics. 

Page 2 

Slowly add special pieces to your wardrobe that will accentuate your look. Pink is a typical girl color, but don't shy away from blacks and blues, as they can also look very cute\! 

## **Your wardrobe should contain **

1. Light-wash and dark-wash denim skirts 

2. Light-wash and dark-wash shorts 

3. Two pairs of dark-wash skinny jeans. 

4. Six plain tank-tops in the colors: pink, peach, black, blue, lavender, and white. These will be good for layering or a weekend casual look when paired with shorts or jeans. 

5. Cute panties. \(No one will see them, of course. But they will make you feel cute, nonetheless.\) 6. At least three comfortable pairs of shoes: one pair of workout sneakers \(a girly girl is never to be seen outside the gym with sneakers\), and a couple of pairs of cute shoes \(heels, moccasins, flats, sandals, take your pick\). Ultimately, a girly girl can never have too many shoes\! 

7. Three cute dresses. When shopping for dresses, remember: short or tight, chose only one. Do not pair them both. Go for neutral colors that can be matched with other things for fancy occasions, but also buy colorful and cute sundresses for the summer time\! 

8. Use mostly pastel colors, but neutrals go with everything. Have enough clothes in both types of colors to mix and match. 

9. Wear clothing that fits. Don't wear low cut jeans if you don't feel comfortable, but make sure your jeans fit you and are not tight or baggy. A belt is okay, but the fit says it all. Try on lots of brands, 

Page 3 

10. styles, cuts, and sizes. Not every size jean will fit the same, depending on the brand. The same goes with shirts. Not tight, not baggy. If your shirt is so tight you can see your bra or you have trouble getting your shirt off of your back, then it's too tight. To see if the shirt is too small, raise your arms up. If your stomach shows when you do this, then the shirt is excessively short\! Things like camisoles are supposed to fit tight. 

11. Remember, you don't have to buy brand name clothing. Brands are just social signifiers meant to make people feel superior. Don't get caught up in that behavior. 

**Good stores to buy girly clothes are **

 Forever 21 \(trendy clothes and accessories for women and men\) 

 Rue 21 \(casual apparel for both women and men\) 

 Wet Seal \(moderately priced clothes and accessories for young women\) 

 Charlotte Russe \(clothing and accessories for teenage girls and young women\) 

 Alloy \(clothes for teens and college students\) 

 Dillard's \(a wide variety of clothes for women and men\) 

 Ardene \(affordable clothing for young women\) 

 Justice \(clothes and lifestyle products for young girls\) 

 Victoria's Secret \(fashionable outer and under wear for women\) Page 4 

**On To Your Behavior **

1. Be graceful. Substitute clumsiness and jerky movements with graceful and fluid actions. True girly girls appear like they're floating. Put your shoulders back and chin up. This is a difficult step, but also a crucial one. Being graceful doesn't mean you have to hate sports and walk on tiptoe. Just make sure you walk with your head up, shoulders rolled back and your back straight. Don't swagger, or swing your hips. It looks exaggerated and weird. Don't swing your arms either - keep them by your side. 

2. Have a bright personality, bubbly and happy. Don't giggle all the time, because people will find that annoying. Instead, make other people laugh, and be cute. Don't take yourself too seriously. 

3. Always be nice and generous. Having a selfish and nasty attitude toward others will drag you far away from being ladylike. Always have a smile on your face, and be willing to let people borrow things from you. Be nice to everyone, even people who you think are losers, because nobody is a loser and everyone is a human being with feelings. Everyone deserves a chance. 

Don't exclude people from games, gifts, etc. keep your promises and don't gossip. Don't be mean or hot headed-always keep 

4. your cool. 

5. Don't let anyone mess with you. If someone is bullying you in any matter, you don't have to put up with it. Don't let anyone walk all over you. This is the time to calmly tell someone who is mistaking your niceness and generosity for weakness that you will no longer be associating Page 5 

with them. Do not "unleash the nasty" as this will cause people to think that you are a fake person. 

6. Have a few comments prepared if someone is insulting you. But always be nice. There are no exceptions. 

7. Be romantic. Girliness is also associated with romance. Be sure to read romance novels and develop a keen interest in poetry. You can also make this your music style by listening to love songs. 

8. Stop swearing. Swearing or talking loudly is most definitely unattractive, and not ladylike. It may be hard to stop, but swearing is one of the worst things you could do if you're trying to be girly. 

9. Try making a deal with your friends about not swearing for a day. Prove to yourself that you can control the things that come out of your mouth. Try saying things like, "Oh, poop" and 

"Darn it." Try not to use hurtful words like "idiot" or "moron." They're not okay. Try to make calm and civil comebacks, not the regular harsh insulting words. It'll take practice, but it's a huge step toward being ladylike and girly. 

10. Learn to talk well. Talking well is quite an art. Find a good tone so that people can hear you without straining their eardrums or covering their ears. A medium tone is best. If you enunciate your words in a strong accent, not many will understand you. 

Page 6 

11. Don't stuff your face with food. Instead, chew your food and don't make any noises or gulp it down. Don't take huge bites either - just normal ones. To look normal as possible when eating take a bite and count to 20 in your head while chewing then swallow. Avoid eating anything that could get messy and sticky. 

12. Don't slouch when you're sitting in a chair - press up against the back of the chair and plant your feet firmly on the floor. Avoid folding your arms too - it gives off a "get lost" vibe, and can make you look unsure about who you are and where you stand. Try not to put your hands in your pockets too much either, -just practice keeping them by your sides. It feels awkward, but actually looks completely normal. 

13. Hang out with gal pals. Girls love the mall, shopping, and almost anything associated with beauty. Get a group of friends and have a shopping spree, makeovers, a sleepover, a bake sale or any girl-related 

14. activity. 

15. Keep a diary. Write down whatever motivated you throughout the course of the day or anything that was interesting. 

16. Be organized. If you are organized, you'll always be able to find the things you're looking for. 

Being disorganized is unladylike. 

Page 7 

17. Make sure your belongings are neat. Make sure you label and cover all of your binders, folders, and textbooks. Try covering them with clear contact paper - it looks a lot neater. If you like patterned contact paper, try the metallic looking varieties that come in red, silver, blue and gold. Label your things and look after them to make sure they don't get lost or damaged. 

Buy some nice pencils and pens. Make sure you always have enough of everything - constantly asking to borrow things 

18. isn't ladylike. When buying a school bag, go for light and neutral colors and posh brands - stuff that's good quality. Don't buy anything in dark colors like navy blue or black. 

19. Concentrate in school. It's important to be intelligent at school. Don't say "like" at all, unless you are using the actual word in a grammatically correct sentence or simile. Try hard in every subject and class you take, and always hand in homework on time. Don't talk during class - you have loads of time for that later. Don't pass notes either its embarrassing if you're caught. Ask questions and participate in class discussions. Try to get involved with the school and its activities too. Reading up on background information about a topic you're studying is good, and can actually be interesting. Help others if they're struggling, and don't suck up to your teachers. 

20. Read Magazines. Magazines are a great way to help you get caught up on everything going on in Hollywood and in the fashion world. The most popular magazines are gossip and fashion, but you can read anything you like. Lots of fashion magazines give you lifestyle tips that come in handy all the time. The gossip magazines keep you updated on what's going on with celebrities. 

Page 8 

## **Tips **

1. A true girly girl knows that a purse is essential. Big or small, your purse should have the basics: mints/gum, perfume, a nail file, makeup, hairbrush, fashion tape, pens and notebooks, nail polish, and any other stuff you need to look amazing 

2. Don't wear too much makeup. Stick with the basics: lip gloss, mascara, and eye shadow \(but not too much. If you resemble a clown while wearing it, you've overdone it\). 

3. A girly girl should not have too much hair on her legs \(a little is okay\), but no hair on underarms. 

4. Get some lipgloss and cute jewelry that suits you, but don't go over the top. 

5. If you want, you can wear both lipstick and lipgloss. First, add a base coat of lipstick and then add some good smelling and sparkly lipgloss to help it shine\! 

6. Make sure your hair is neat all the time. Set it in a different hairstyle every day, to make everyone dazzled. Don't always leave your hair open. Braid it. Curl it. Straighten it. 

Page 9 

7. Make sure you don't pass gas or burp or pick your nose in public. It's very unlady like, and will turn people off. You always want good manners when you are in a public area. 

8. When at school, always have an organized locker and desk. 

9. Wear little pink clips in your hair and mainly bright colored stuff. 

10. At school, keep some lipgloss with you at all times, and maybe a small tin of face moisturizer. 

You never know, you might just get a pimple, or even worse, a spot during the day. 

11. Be friends with everyone. Girly girls are popular girls, and being popular means being friends with everyone. 

12. Don't do anything to get you in trouble. Try not to break too many serious rules, and always think about the consequences of your actions before you actually carry them out. You never know - it might just save you an unladylike detention. 

13. When buying a phone then get a girly color like lime green pink, baby blue, etc. However, if you already have a phone that is not a girly color, you can always buy a cute protective cover for it. 

Page 10 

14. All girly girls play sports. In fact, most girly girls are competitive and that is why they play sports. Soccer, volleyball, softball, figure skating, dance, cheerleading and gymnastics are the ideal girly sports. Gymnastics especially. Just don't get too dirty. 

15. Don't be obnoxious. Don't say the same thing repeatedly and don't act to fake or too happy. 

16. A girly girl has always got attitude with a hint of polite and innocent. 

17. Express yourself and let out your true feelings. Don't try to be someone you are not. No one likes a poser. 

18. Respect your parents or your guardian. 

19. Overall, just bring out that girly part of you and don't just hide yourself. Be confident, be a strong woman, be you. Don't be afraid to get caught in the rain or eat a chocolate bar every once in a while, just try to be yourself and show off your potential and who you really are\! 

Don't forget to wear pink and another dark color with it 

20. Don't be shy. Being a girly girl means you've got personality plus. Don't be afraid to show off. 

21. Write with pretty floral/pink notepaper. It looks really cute if you dot your 'i's with little hearts. 

If you can't get the paper, just work with what you've got. 

Page 11 

22. Always stay calm around boys, and never be scared to talk to them. 

23. Be intelligent. A girly girl should be a great conversationalist. Therefore, it is essential to study things that you find interesting and important for life. Read books and improve your vocabulary. People will admire you because you're smart and have confidence. 

24. If you have any good skill or kind of talent, such as drawing, or dancing, singing or playing any musical instrument, don't hide it; work it. Let people see how good you are by sharing your artwork, or maybe 

25. playing a musical instrument. If you're good at acting, look for a part in any play at theater. 

## **Warnings **

1. If you are naturally a tomboy and are trying to impress someone, think twice before you try to be a girly girl. The guy you are trying to impress should not expect you to change for him. It is better to have a boyfriend who loves you the way you are. 

2. Don't get dirty or muddy. This just ruins your shoes and your outfit. 

3. Try to be a good person because you don't want to be disliked. 

Page 12 

4. Never bite your nails. This can cause damage to your nails and then you can't paint them and they will be jagged and dirty. 

5. Some people may dislike you or call you stuck-up or nerdy. If you know you've done nothing wrong or nasty, simply ignore them. They're trying to bring you down, so don't let them. 

6. Think twice about getting tattoos and body piercings. People tend to judge others by the way they look. Also keep in mind that although tattoos and piercings are individual expressions, they can be permanent 

7. or difficult \(even costly\) to remove if you change your mind in the future. If you are in doubt how tattoos and piercings may affect you in the future, forget about getting them and find other ways to express yourself, such as creating works of art, poetry, hobbies, etc. 

Nevertheless, ear piercings are all ways great for a girly girl. Belly button and clit piercings are more of a bad girl type of thing; you want 

8. to be good and girly. 

9. Don't always hang out with boys; you will start to copy their ways. Instead, hang out with lots of girly girls and try to copy things they do: the catchphrases they say \(Omigosh\! OMG\! Yah\!\), what they eat \(Don't eat exactly the same things they eat, just don't stuff your face with food\!\), and hairstyles \(if they do their hair cute one day you could try it\! However, if it doesn't suit you then try a different hairstyle\!\). 

Page 13 

10. If you're going to copy some aspects of the other girls, don't copy everything they do, say, or wear as they will soon find it annoying and will not want you to hang around with them. They might call you a 

11. wannabe if you copy too much. 

12. If you are doing this in the middle of the school year, you might want to take small steps and change little by little. If you normally wear a hoodie and sweats every day, it won't fly over to well with everyone if one day you come in a miniskirt and heels. 

Page 14 

**Important Things You Need **

1. Shiny lip gloss 

2. Black Mascara for everyday wear 

3. Girly accessories 

4. Foundation, powder, blush, eye shadow, and concealer 

5. Appropriate dresses and denim miniskirts 

6. Nice girly smelling perfumes 

7. Flat irons, hot rollers, Barrel curlers, ringlet curlers, and crimpers 8. Gum, breath mints, a small bottle of hand sanitizer, and a travel-size bottle of lotion 9. Handheld mirror 

10. Fold up brush for those bad hair days 

11. A purse filled with face powder, mascara, and lip gloss 12. Travel-size body spray for when you forget to put it on or need a touch-up 13. Personal girl stuff like tampons, pads, etc. Friends \(for support\) 14. Cute gym outfit. Try not to get to attractive because people will call you a wannabe Page 15 

**If You Don't Want To Look Dull You Should **

1. Wash your face with warm water in the morning before going to school to look fresh. Apply moisturizer to keep it from getting dry \(you don't want dry skin\). 

2. Wear different hairstyles every day to look cute and girly. Wear elegant and stylish hairstyles. 

Comb your hair with a comb, or a plain hairbrush. If you have hair straighteners, or curlers, or hair dryers, use them to style your hair. If you want to have shiny hair, wash it with cold water after shampooing \(your hair will look polished afterward. Also to add some finished touches use a bow in your hair or flowers. \(cute\) 

3. Wear little or no makeup. Makeup is for girly girls, but since you are going to school, you can't wear too much makeup. So, just wear lip balm to prevent your lips from chapping, and then lip gloss...to add that glossy and shiny look to your lips. 

4. If you have boots \(ankle boots, knee-high boots, boots\!\) wear them\! They will look great with a skirt, or you can tuck your pants inside of your boots. Wear ballet flats to look elegant in school. 

Maybe even slippers\! Yes, slippers\! It definitely matches with a skirt. Guys, I can't think of any more information to share with you for the time being. 

5. Accessorize girl\! It's time to bling things up\! Wear bright, bold, or colorful earrings, some bracelets...don't just wear one...you want to be a girly girl, more fashion\! More bling\! Wear 2 or more Page 16 

bracelets \(but not too\). If your bag looks boring, bling bling bling\! Put cute badges, and key chains to it or sew stuff of flowers and stuff\! 

6. Dazzle up your nails. French style if you want\! Add colorful stripes\! Put some sparkle in your nails. 

****

****

Page 17 

**20 Really Important Tips To Consider **

1. Instead of laughing properly, and like, loudly and everything, do a small cute sweet little giggle. 

2. Curl your hair every morning, in loose curls. It's so cute\! Try hair accessories like headbands, barrettes etc... 

3. Wear cute little ballet pumps to school, and walk daintily in them 4. Giggle when anyone tries to be funny, even if it is not, it is cute and polite. 

5. Be as neat as your personality 

6. As soon as winter hits, wear a cute, fluffy, white or pink scarf, hat and gloves 7. Instead of buying normal tissues, buy pretty pink swirl ones, or any bright color\! 

8. Always keep Vaseline, lip gloss, a mini comb and a hand mirror with you at all times. And, -just in case - keep a spare Vaseline, in case it runs out\! 

Page 18 

9. Wear pretty silver jewelry under your school clothes, and have a special bracelet, that you are not allowed to take off\! 

10. Try to avoid wearing trousers. Jeans are ok, but try to stick with skirts and dresses\! 

11. Keep a large supply of pink or white hair bobbles on your wrist\! 

12. Always have perfectly manicured nails, and never ever bite them, even if you are tempted. If you are not allowed nail varnish at your school, wear a clear one with a hint of glitter, or wear a pearly colored one close to your nail color. 

13. Dress really well and always look cute 24/7. Take care of yourself and have very good hygiene.14. 

14. For makeup, try a foundation that matches your skin tone, neutral, smoky eye, eyeliner, blush, mascara and lip gloss. 

15. Be polite say 'thank you' and 'please' manners make you look even sweeter and more innocent. 

16. Always have a planner with you, to keep u organized 

Page 19 

17. Have your own special pen that you always use. E.g. A pink personal gel pen that you ALWAYS use-That's super cute\!\! 

18. Love others as much as you love yourself. Care for others :\) 19. Be a good listener, show them that you really care. 

20. Always have a purse with you and try to keep it organized. 

Follow these guidelines to the best of your ability and you'll be pleased with the results. 

Page 20 

12 Steps 

To Sissification 

Without a Partner 

\[play safe, sane and consensual\] 

* *

*February 2023 – Ver. 1.2 *

It’s a process and one that true Sissies need and crave. If you are one or you fantasize about becoming one you will appreciate and enjoy this book. This is just a soft introduction of becoming a Sissy on your own. Buying new clothes, going into chastity, learning how to follow the rules to help you reach your goal of becoming more of a Sissy. 

**1. Underwear – First Week of Training Underwear **

If you are working on becoming more of a Sissy on your own than you will need to get rid of all of your boxers and other male undergarments. Ideally the best option would be for you to go to a lingerie store and pick out your own colorful array of women’s panties. To make the experience even more humiliating and exciting than I would suggest asking a sale associate what they think would fit you. Do not pretend you are buying this for a girlfriend or wife. Getting matching sets of bras and panties. Get at least 7 pairs of underwear and two or three bras. You will also need stockings, buy a few different sizes to find the right fit. After you have done this you can return for the next chapter. Until than you may not continue reading. You got it? Excellent. Was it embarrassing? I hope so. Did your face turn red? Did the other women look at you funny? Did they giggle? 

You must wear your new panties every day beneath your boy clothing. This means going to work, errands whatever. When you are home and alone you must put your bra and stockings on. In bed, you must keep your new sexy panties on. You will wear your new undies for two weeks. During these two weeks, you can begin looking forward to what will happen at the beginning of the third week. 

**2. Remain fully shaved at all times** 

You may shave now. I am assuming you have worn your girly undies for the past two weeks daily. If you have done so you may proceed with this step. If not, you may not continue. You must shave your entire body except your arms. Toes, calves, knees, thighs, private areas, bottom, chest Page 2 

and face. You must do this every two days or as often as needed to remain smooth. After you remove all of that gross hair from your body you must moisturize your entire body and put your panties, stockings and bra back on. Now, you get to feel how nice and sexy it feels to wear girl’s undies and be completely shaven. No more nasty man hair. You are trying to become as good of a Sissy as you can. You must do this for two weeks before you are allowed to proceed with step three – but you MAY begin your shopping now. 

**3. Shopping for your new wardrobe **

You must be dressed for 10 Hours every week, minimum. Now, you are wearing girl’s undies and completely shaven. If you have accomplished this you may continue. Your new rule is that you must be fully dressed in women’s clothing at least 10 hours a week. You will need to do some shopping now. Measure your feet and buy yourself a pair of high heels – many sites including amazon sell large sizes in heels. The higher the better. Every evening you will need to practice wearing them around the house. A corset or waist cincher to help give your curves, a woman’s nighty, some very short skirts and stretchy tops \(keep in mind men have broader backs so you will need to buy these in larger sizes that stretch. Shoes of Prey offers some higher end shoes in very high quality. For the clothing, I would PREFER you bought it in person. The entire humiliating experience of buying a bunch of sexy clothing for yourself would be good for you. On your days off you will need to designate time to being dressed. You may dress only after you have completed two weeks of undies and two weeks of being fully shaved. If you have completed that you may begin to dress. You may start shopping for your new chastity device but you may not try it on until you have completed two weeks of dressing at least 10 hours per week. 

**4. Lock up your manhood and throw away the key **

You must wear your device as much and for as long as possible until you wear it 24/7 Obviously, I don’t know your measurements but I can make a few suggestions on the TYPE of chastity device you need to purchase. It should be clear, plastic and have a lock on it. Some of them are made to Page 3 

go through metal detectors for constant wear and others are more of a torture fest. I want you to find one that you can wear ALL the time. They are made of plastic and are designed so you can go to the bathroom and not take them off. You will start out slow, wearing it a few hours every day, working your way up to every night. Before you know it, it will be on 24/7. Showering is the same deal – simply soap up the entire area and make sure you sanitize it. Expect that you will not find the PERFECT chastity device upon first selection – my husband and I have purchased at least 6 of them. Do not buy cheap ones, they will rub you raw and you won’t be able to wear them. Before you know it, it will be constantly worn day after day, night after night. Your manhood will be useless. Please note, common sense must be used with this. If the device is irritating, rubbing marks or hurting you than take it off\! You are not wearing the right size, a good quality one or one that is meant for your body. Its primary purpose is to prevent you from having an erection. It is not meant to hurt you. 

## **5. Closet Space **

Designated area for all of your girly things. Nothing will make you happier than when you open a closet or a drawer and you have multiple skirts, bras, tops and heels to choose from. A designated area for your Sissy wardrobe is a must\! Treat your clothing with respect, meaning if it gets wrinkled bring it to the dry cleaner. Do you think they will wonder if it’s yours? Either way, it doesn’t matter. You are to designate areas in your home for your new Sissy wardrobe. Dresses should be hung properly, undies folded neatly in a drawer... 

## **6. Scent **

You must wear perfume...So, have you been doing as you have been instructed? If so, you may treat yourself. Go to any large department store that has a great selection of women’s fragrances. 

Begin smelling them until you find the one that makes you feel the sexiest, the one that turns you on the most. This will become your scent; all of your clothes will have this scent. When you get Page 4 

home, lightly mist your new girly wardrobe with perfume. When you dress up you must always put your fragrance on. Real Sissies wear perfume. 

**7. Maid’s Outfit **

Your house must be clean at all times. A true Sissy would do their best to keep a nice house for their Mistress or Master. Even if you are singly now, you are practicing. You must train to be the best submissive Sissy. Once a week you will put your Maid’s outfit on and thoroughly clean your home or apartment. You will do this on your hands and knees and with a toothbrush if need be. Your purpose in life is to please and if you find the proper Mistress or Master - don’t you want to show them you have some value? Obviously, your manhood is useless at this point. So, if you have dishes in your sink, or a dirty shower, get up now, get dressed and begin cleaning. You are not permitted to continue with this book until you have finished your domestic house duties. You can purchase cute maids outfits right here on amazon\! How convenient is that. 

## **8. Anal plug **

You will begin wearing plug when you are dressed. Since you have lost use of your manhood you have two other openings that you can use to please and offer. When you dress you are to lube yourself and place your plug in. Buy one that is smaller at first and work your way up. You need to keep yourself stretched for your new Mistress or Master. If they decide they want to use a dildo or offer your bottom to someone that is a true man than you must be prepared and willing. Sissy’s don’t have choices. They serve and do as they are told. 

**9. Watch Video’s on how to give pleasure** 

Watch video’s on how to give proper oral sex to both male and females. Also watch videos of Sissy’s on the receiving end of anal sex. You will be dressed and wearing your chastity device and Page 5 

have your plug in so this will become very frustrating for you. Oh well… you are just a Sissy after all. Learn from these video’s. Purchase a dildo and practice oral sex, buy one that you can mount on the side of the tub so you can practice humping it. Your chastity device is to remain on at all times. This is about pleasing others, not you. You are a Sissy and your purpose is to serve in all ways. To be as sexy as possible and to please as much as you can. 

**10. Get a wig & makeup **

Online has many videos of makeup tutorials. Practice makes perfect and it will take time for you to find your perfect look. Get to it\! 

**11. Take some photos of yourself all Sissified **

This will help you determine what you need to work on. Do your Sissy clothes make you look sexy? Do you feel sexy? If not, change your look, take more photos and study the results. 

**12. Joining Sissy groups, talk to others like you **

When you feel like you have reached your potential, months of being dressed, cleaning, being as sexy as possible and you feel more like yourself dressed than you do any other way you may move onto this step. Start joining Sissy groups, talk to others like you. Find out about meet ups or dinner parties. IT DOES EXIST you just need to find it. Many successful business people have 

“double” lives. Place ads, go to “parties”. If you have done your work than you will not be recognizable. 

Page 6

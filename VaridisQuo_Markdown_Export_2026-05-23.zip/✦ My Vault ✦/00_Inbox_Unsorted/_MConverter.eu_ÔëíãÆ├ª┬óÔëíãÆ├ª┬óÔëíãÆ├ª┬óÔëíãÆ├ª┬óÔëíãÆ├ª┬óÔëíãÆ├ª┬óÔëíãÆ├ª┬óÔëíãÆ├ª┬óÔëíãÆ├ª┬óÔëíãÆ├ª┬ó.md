---
class: B
---
**What Kind Of **

**Sissy Are You? **

****

\[play safe, sane and consensual\] 

*February 2023 – Ver. 1.2* 

****

****

****

**The Gay/Effeminate Sissy **

Page 2 

**The Bisexual Sissy **

**The Transgender/Gender Fluid Sissy **

It’s not just about role-playing but role actualization. 

Page 6 

**The Straight Sissy **

**Crossdreamer **

Page 8 

**Slutty Sissy **

**Sissy Maid **

Page 9 

**Little Sissy **

**Sordid Sissy **

Page 10 

**Sweet Sissy Cross-Dresser **

**Secret Sissy **

Page 11 

**Show-off Sissy **

Page 12 

****

**Why **

**Sissy Chastity **

**Matters **

****

**\+13 Tips to make Chastity Life easier **

\[play safe, sane and consensual\] 

*February 2023 – Ver. 1.2* 

Page 2 

Page 3 

Page 6 

**13 Tips to make Chastity Life easier **

 Wash his cage in pure alcohol. 

 Absolutely no complaining, bitching or whining will be permitted…. PERIOD. 

 When won’t enter his cage, use Ice 

Page 7

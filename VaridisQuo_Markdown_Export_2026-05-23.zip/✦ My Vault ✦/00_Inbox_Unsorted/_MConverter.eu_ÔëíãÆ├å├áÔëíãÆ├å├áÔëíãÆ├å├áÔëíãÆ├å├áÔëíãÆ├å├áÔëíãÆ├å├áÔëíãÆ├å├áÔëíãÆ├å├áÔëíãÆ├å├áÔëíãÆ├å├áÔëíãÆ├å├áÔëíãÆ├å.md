---
class: B
---
Have your male give you oral. Smear your cum on his face and don’t al ow him to wash it off for twenty-four hours. For added humiliation, take him out in public while stil covered with your lovely cum. 

Make him approach women he doesn’t know at the mal and beg to kiss their feet. 

Make him ask for permission to use the restroom. 

Forbid him from voting or tel him who he is al owed to vote for. 

Have him crawl around on al fours, fetch objects for you, and “beg” 

Transform him into a sultry French maid and have him work cleaning, add extra humiliation by making him clean particularly dirty or difficult-to-reach areas, like scrubbing the floor on her hands and knees. 

Urinate on him and make her “wear” it for a while before cleaning up. 

Remember to start slow – a few spots here and then, then level up. 

Flick cigarette ashes on them or use them as an ashtray during playtime. 

Giver him an intense cavity check. 

Make him lick you clean after you use the restroom. 

Have him perform rimming on you as a form of sexual submission. 

Make him perform awkward or strange masturbation methods, such as humping a stuffed animal or into food while adding mean comments,. 

Do the same as above but this time put limits on his orgasm and video him. 

Peg him. 

Require that he urinate sitting down. 

Make him write and read fan erotic while also acting out the scenes. 

Make him suck on dildos or other sex toys, especial y weird or unconventional ones like tentacles. Extra points for practicing deep-throating, 

Fil his mp3 player with feminist podcasts for him to listen to. 

Place him in sex furniture or equipment in an embarrassing position. 

Same as above but this time invite others over to use them Have him create a blog detailing their most humiliating experiences. 

He should write candidly and vividly about their shame-inducing moments.\*

Task him with singing a difficult song and critique their performance. 

Make him pre-wash your intimates and socks with his tongue. 

Make him wash your socks and intimates by hand. 

Film embarrassing moments and make him watch. Try adding humiliating chal enges, games, events for even more fun. 

Have him hold a sign with an embarrassing message in a busy area. 

Ignore them completely, denying them any attention. 

Roleplay scenarios of consensual blackmail. 

Require him to cal you by an extravagant title and flatter you every morning

Buy a male chastity cage and have him wear it for the day Make your misbehaving sub pay your bil s for the next week Have your sub print out a picture of your tits, hang it on his wal and worship it every morning in slave position. 

Have your sub read or sing you to sleep. 

Urinate in your submissives mouth 

Have your sub perform a serious strip tease and masturbation session for you. He must make sure everything is perfect. Rate his performance and reward or punish accordingly

Put your submissive in the wardrobe, secure the wardrobe so they cannot leave until you feel like letting them out Have them write a 1000 word paper on al your great qualities Require that he thank you for any punishments you give him. If he forgets to do so, repeat the punishment. 

Bring them to a club and make them sing or dance on stage Dye his hair an outlandish color. 

Have him masturbate beside an open window. 

Spank hisbare ass with a flogger for 5 minutes straight \(use a timer\). 

Chew his meals up for him before spitting them into his doggy dish. 

Have him cook and make you dinner while he waits on you in the nude 

Have you submissive ´pocket dialśomeone on their phone while masturbating. 

Have him masturbate with her face hidden and post it to a public porn site 

Sit on his face and face fuck him 

Put hot sauce on their nipples and twist 

Make him tan while wearing a bikini. 

Have them shave off al their body hair, eyebrows too. 

Berate him publicly. 

Spit on his face during sex. 

Write insults on his body with permanent marker. 

Make him wear feminine deodorant or perfume. 

Make them wear an O-ring gag and have them talk … 

Have him eat directly off the floor for al their meal for ´xńumber of days 

Make him eat boiled mushy cauliflour until she is ful . 

Spil uncooked rice on the floor and have him count and pick up every grain. 

Buy a muzzle for your sub and put in on her when you need some peace. 

Have him clean the entire house top to bottom with a toothbrush, naked. 

Squirt a water bottle at her, like you would a cat Enforced squat - have him strip naked and squat, use her as a footstool until you are satisfied, punish him if he can´t hold it for a satisfactory period of time. 

Make him wear high heels. 

Forced chastity – rol some dice to see how long they must go without an orgasm. 

Make them give a live webcam show. 

. 

**Punishment Level 1 - **Must not wear clothes for specified amount of time

**Punishment Level 2 - **He must crawl on al fours naked with a dog col ar 

**Punishment Level 2 - **Bare bottom belt whipping - 10 hits, light 

**Punishment Level 3- **Have him act like a cat for the next 4 hours. 

**Punishment Level 3 - **Make him cum in his panties, then stuff them in his mouth while his juices are stil on them, he must keep these in her mouth for the next hour while walking around with no underwear or pants 

**Punishment Level 3- **Make him get on al fours and beg while you ignore him

**Punishment Level 3 - **Force him to watch a movie he hates, make her pay attention or she wil be assigned a level 4 punishment **Punishment Level 3 - **Have him listen to a song he hates on replay 10

times

**Punishment Level 3 - **Have him eat a plate of food he hates** **

**Punishment Level 3 - **Make him write a 10 page essay on a topic of your choice 

**Punishment Level 3- **Toss water on his pants to make it look like he wet herself and make him walk around the block **Punishment Level 3-** Have him walk around the block with his dog col ar on 

**Punishment Level 3 - **Slap his face 10 times 

**Punishment Level 3 - **He must only urinate outdoors for the entire day 

**Punishment Level 3 - **Have him hump a stuffed toy until he cums while you watch 

**Punishment Level 4- **Have him walk across the floor on LEGO or uncooked rice** **

**Punishment Level 4- **Soak a dildo in very cold water and fuck him with it 

**Punishment Level 4 - **Have him masturbate completely naked in front of another man 

**Punishment Level 4 - **Force him to wear a ridiculous outfit of your choosing out 

hours 

punishment 

**Punishment Level 5 - **Fuck him anal y with an object on cam in a group chatroom while you degrade and spank him **Punishment Level 5 - **Have him crawl from one side of the house to the other completely naked pushing a penny with his nose while you spank him with a belt and degrade her

**Punishment Level 5 - **Edge him for three days straight bring him to the brink 5 times, repeat 3 times a day for three days **Punishment Level 5 - **Put him in a tub of ice-cold water and pour a bag of ice on top of him

**Punishment Level 5 - **Piss on his face and video it **Punishment Level 5 - **Tie him up to the bed, gag him and fuck him in the ass while you slap and degrade him 

**Punishment Level 5 - **Flick his dick 10 times 

**Reward Level 1 -**Brush his hair** **

**Reward Level 1- **Let him deviate from her meal plan and have some snacks or even a meal of her choice if sheś been very good **Reward Level 1- **Give him a wildcard - he can skip a fitness session of his choosing any time this week 

**Reward Level 2 - **Run him a warm bath with candles **Reward Level 2 - **Watch his favourite movie or show with him** **

**Reward Level 2 - **Bring him a coffee and pastry from her favourite coffee shop 

**Reward Level 2- **Buy him a stuffed toy** **

**Reward Level 2 - **Help him with his daily chores **Reward Level 2 - **Give him a shoulder massage** **

**Reward Level 3 - **Service him sexual y ** **

**Reward Level 3 - **Cuddle him on the couch for the evening 

**Reward Level 4- **Bring him out for fancy dinner **Reward Level 4 - **Give him a ful body massage with oil/music **Reward Level 4 - **Tel him how much you love him **Reward Level 4- **Relieve him of his chores for a week** **

**Reward Level 4 - **Cook dinner for the next week** **

**Reward Level 5 **- Bring him shopping and let him buy whatever he likes. . 

**Reward Level 5 - **Write him a love letter

Have her mop the kitchen floor with her tongue, record it and send it to you. 

Have her remote vibrator control ed by your phone at al times. 

Switch on and off at your convenience. 

Have your sub write out a scene she would love to do with you. 

Inspect her breasts on camera, praise or criticise as you see fit. 

Have her write a story about something that embarrasses her kink-wise. 

Have her write a set number of lines everyday. 

. 

Enema - Have your sub insert water into her rectum. 

Cavity check - Inspect al your subs holes intensely on camera, every single one\! 

Send your submissive a col ar and toys of your choosing. 

Send the Dominant a worn \(but hygenic\) pair of panties or bra to keep

Send the submissive a worn \(but hygenic\) pair of underwear or shirt to keep. 

. 

Have the submissive do a strip tease while you masturbate Have the submissive spank themselves while you masturbate Have the submissive give a 'speech' about something like: who owns them, that they are your property, that providing you with pleasure satisfies them while you masturbate

Have the Submissive shave the Dominant's initial into their pussy hair

Have her wear pegs on her nipples for a specified period of time each day. 

Have your sub wear her col ar out in public and provide evidence. 

Have your sub recite rules at specified times and send you evidence. 

Make your sub practice body worshipping skil s by licking their own hand 

Have your sub read you to sleep

Have your sub send you pics of themselves in slave position Have your sub go somewhere in public, \(somewhere discreet of course\) and masturbate, have her send you video evidence Use a remote blue tooth chastity device on your sub Have her edge herself over on cam until she begs for the torture to stop

Send her pictures of celebrities you find attractive and compare her to them 

10 Sissy Cuckold 

Training Ideas 

\[play safe, sane and consensual\] 

February 2023 – Ver. 1.2 

## **1. Sissy Cuckold Dirty Talk **

Page 2 

## **2. Permanent Chastity **

## **3. Cock Sucking Practice **

You don’t want her embarrassing you in the bedroom. 

Page 3 

**4. Take Her on a Sexy Shopping Trip **

**5. Find Your New Lover Together **

**6. Have Her Help You to Prepare for Your Date** Now that the rendezvous is set-up, have your sissy help you to get ready for your date. Allow her paint your toenails then lay out the outfit that you bought while shopping together. 

Page 4 

**7. Buy or Build a Sissy Cuckold Cage **

How erotically evil is that? 

**8. Turn Your Sissy into Your Cuckold Chauffeur** You can have your sissy serve as your appropriately dressed chauffeur, driving you and your boyfriend to dinner dates and then back home again. She, of course, waits patiently in the car thinking of the romantic time you’re having. 

Page 5 

**10. Turn Him Into Your Lover’s Fuck Doll **

Page 6

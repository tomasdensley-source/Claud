﻿---
class: B
type: readme
created: "2026-02-17"
---

> [!structure]
> Role: child
> Parent: 
Notes & Fragments Hub
> Sibling class: 
Notes & Fragments
> Link rule: parent points to this note; this note does not point back

# Attachment Notes Catalog
This folder contains **one Markdown note per attachment** (PDF / Base) so each attachment is connected in Obsidian's graph.
## How it works
- Each note embeds the attachment using Obsidian's internal link syntax.
- Each note links â€œupâ€ to the relevant **Category MOC** + the **Vault Index**, so the notes are not orphans even if you hide attachments in the graph.
## Graph tip
In **Graph view**, enable **Attachments** if you want the PDF files themselves to show as nodes.
## Manifest
See `_attachment_notes_manifest.csv` for a full mapping of:
- attachment path â†’ catalog note path

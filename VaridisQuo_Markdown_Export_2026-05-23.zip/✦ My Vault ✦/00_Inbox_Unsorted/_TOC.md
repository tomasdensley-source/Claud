---
class: B
---

# Substance Content Sweep — Table of Contents (flat)

**76 files across 4 content folders + 1 user-upload folder.**

Open the zip. You see 4 content folders + 1 uploads folder + this TOC + the manifest. Inside each folder: only files, no further nesting.

## Folder map

### `01_liber_novus_plant_teachers/` — 22 files

Liber Novus Densley plant-teacher chapters. The Datura sub-decomposition (§31-25 / §31-35..40), Amanita, Salvia, Psilocybin, LSD, Nutmeg, and adjacent session work. Originally from §31 Adjudications in the LoA codex.

- `0.3_HUB.md` (3K)
- `31-13_the-mechanical-wheel-of-spiritual-debt.md` (10K)
- `31-19_03c-convergence-log.md` (18K)
- `31-21_the-cigarette-i-was-not-smoking.md` (14K)
- `31-23_the-datura-sequence-threshold-companion-daylight-return.md` (13K)
- `31-25_datura-the-refused.md` (3K)
- `31-26_galanthus-the-antidote.md` (19K)
- `31-27_lsa-the-eleusinian-descent.md` (20K)
- `31-28_amanita-the-siberian-ascent.md` (24K)
- `31-29_blue-lotus-the-egyptian-apparatus.md` (21K)
- `31-30_nutmeg-the-control-case.md` (15K)
- `31-31_salvia-the-wheel-vision.md` (21K)
- `31-32_psilocybin-the-confirmation.md` (22K)
- `31-33_lsd-the-synthetic-heir.md` (22K)
- `31-34_synthesis-cumulative-argument.md` (17K)
- `31-35_datura-preface-and-framing.md` (12K)
- `31-36_datura-cultural-and-historical-survey.md` (24K)
- `31-37_datura-the-psychological-anatomy.md` (26K)
- `31-38_datura-the-three-witnesses.md` (14K)
- `31-39_datura-the-elements-that-recur.md` (22K)
- `31-40_datura-the-wilderness-frame-and-the-empty-city.md` (16K)
- `31-5_storage-and-stored-source.md` (21K)

### `02_nootropics_and_compendia/` — 19 files

Nootropic profiles and substance compendia. Iterative nootropic profile docs, master substance indices, herbal tea field guides, deep-dive substance notes. Originally from §9C Prompts and §9 Reference Compendia.

- `9-12_nootropic-evidence-atlas.md` (1K)
- `9-13_psychoactive-risk-matrix.md` (1K)
- `9C-114_compendium-of-metaphysical-entities-and.md` (33K)
- `9C-115_compendium-of-metaphysical-entities-and.md` (31K)
- `9C-116_compendium-of-metaphysical-entities-and.md` (540K)
- `9C-125_nootropic-compendium.md` (88K)
- `9C-126_nootropic-compendium-pretty-linked.md` (22K)
- `9C-127_nootropic-compendium-pretty-plainurls.md` (130K)
- `9C-128_nootropic-profiles-iterative-105-reva.md` (330K)
- `9C-129_nootropic-profiles-iterative-140-reva.md` (114K)
- `9C-130_nootropic-profiles-iterative-pretty-final3.md` (630K)
- `9C-131_nootropic-profiles-iterative-33-revb.md` (1K)
- `9C-132_nootropic-profiles-iterative-75-reva.md` (13K)
- `9C-133_nootropic-profiles-iterative-90-reva.md` (23K)
- `9C-78_books-about-nootropics-arushanian.md` (389K)
- `9C-83_deep-dive-substance.md` (138K)
- `9C-86_hypnagogia-and-creative-thinking.md` (22K)
- `9C-87_hypnagogia-and-creative-thinking-magazine.md` (33K)
- `9C-97_master-substance-index-deep-dive.md` (13K)

### `03_drug_references_and_prescribing/` — 20 files

Pharmaceutical and drug references: prescribing info, drug interaction guides, FDA labels, neuropsychopharmacology refs, ketamine/Spravato docs, LSD legality, polysubstance use charts. Originally from §12 Influence Atlas and §27 Misc.

- `12-110_017078s042lbl.md` (38K)
- `12-127_drug-interactions-what-you-should.md` (14K)
- `12-130_ews-000002.md` (5K)
- `12-13_cafergot.md` (14K)
- `12-145_piis.md` (120K)
- `12-146_polysubstance-use-chart-2-0-with.md` (5K)
- `12-149_shopping-list-250923-191237.md` (24K)
- `12-152_supplement-label-pack-from-pdf.md` (10K)
- `12-153_switchguide-2017-oct.md` (18K)
- `12-207_1p-lsd.md` (15K)
- `12-23_intech-the-neuropsychopharmacology-of-stimulants.md` (70K)
- `12-25_kratom.md` (3K)
- `12-32_strattera-side-effects-uses-dosage.md` (102K)
- `12-43_all-hiv-2018-feb.md` (268K)
- `12-5_gaba.md` (4K)
- `12-8_3920p.md` (17K)
- `27-33_november-2025-bank-statement.md` (32K)
- `27-41_spravato-pi.md` (132K)
- `27-48_adhd-medication-conversion.md` (10K)
- `27-55_kotowski-lsd-derivatives-current-legal.md` (28K)

### `04_other_substance_notes/` — 10 files

Remaining files with strong substance content that don't fit the three primary categories — items from §2, §5A, §10, §18, §25, and attachments.

- `10-14_psychedelic-odyssey-into-the-mind-s-eternal-wheel.md` (10K)
- `2-25_childhood-memory-wind-tar-hanging-paracosm.md` (7K)
- `25-22_2025-10-01.md` (15K)
- `5A-165_ct-watermelon-moon-shrooms-lab.md` (26K)
- `5A-214_downloaded-document.md` (17K)
- `5A-217_basss.md` (9K)
- `5A-219_file-name.md` (34K)
- `5A-309_pdf-reorg-move-map.md` (522K)
- `CHANGELOG.md` (81K)
- `README.md` (5K)

### `_user_uploads_2026-05-12/` — 5 files

Files Thomas uploaded supplementing the codex sweep. Treated as confirmed substance content by inclusion intent — not subject to the keyword/density filter.

- `Compendium_Research_Dossier-_Plants.txt` (64K)
- `Liber_Novus_Densley_First_and_Second_Compendia_Combined.md` (1.2M)
- `deep-research-report__2_.md` (50K)
- `lanmaoa_asiatica_brief.pdf` (262K)
- `plants_of_power_and_plants_that_teach_dossier.md` (204K)

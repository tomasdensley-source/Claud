---
class: B
---
**For subs without a Domme, i’m on Telegram**** **👑** **

****

## **Task List **

4. Request my permission every single time you need to use the bathroom today. 

5. Ask me before you do anything at al today, I control your schedule now. 

6. Speak in baby talk to everyone you interact with for the rest of the day. 

7. Serve me online for the day, doing whatever I command immediately. 

8. Beg for my attention, but you only get one chance every hour. Use it wisely. 

9. Tie up your cock and bal s, and record a video of your humiliation. 

10. Buy a tiny G-string and post a selfie of you wearing it proudly. 

11. Purchase a chastity cage and wear it non-stop for the whole day. 

13. Buy oversized granny panties and wear them around the house al day. 

14. Purchase a pair of sky-high black heels and strut around in them for me. 

16. Walk around al day with a handbag slung over your shoulder like a woman. 

17. Change your Instagram handle and add my initials for everyone to see. 

18. Col ect the mail while wearing only your most revealing lingerie. 

19. Step outside to check the mail, but you’re completely naked this time. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

20. Deepthroat a dildo until you can’t hold back the gag reflex, then show me. 

21. Clean your entire home while gagged, taking selfies as you go. 

25. Cum onto a dinner plate and then lick it completely clean for me. 

26. Cum onto your bed sheets every night for a week—no changing them. 

27. After you cum on your own feet, give yourself a nice, humiliating foot rub. 

28. Cut holes around your nipples on a shirt, and wear it to the grocery store. 

29. Slice your food into tiny pieces like a toddler, then eat it slowly for me. 

30. Deepthroat the biggest dildo you have and send me a video of your struggle. 

31. Do 50 push-ups fol owed by 50 sit-ups to prove you’re not a weak sissy. 

32. Put on a ful face of makeup and garden in the front yard for al to see. 

36. Act like a cow for the day—crawl on al fours and moo in private or public. 

37. Drink from the dog’s water bowl whenever you’re thirsty from now on. 

38. Drive around town with nothing on below the waist, no exceptions. 

39. Dye your hair a bright, attention-grabbing color, then show me the results. 

40. Eat your next meal on the floor in the bathroom, no utensils al owed. 

41. Use a dog bowl for your next meal, eating it while on your hands and knees. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

42. No utensils at your next meal—use your fingers only to eat. 

44. Film yourself licking both armpits, and send me the embarrassing footage. 

46. Lick a public toilet seat clean and record it to show me. 

48. Freeze your cum into ice cubes and enjoy it in a cocktail. 

49. Place ice cubes in your underwear and wear them until they melt completely. 

50. Get a tan wearing only a bikini or bra to make those lines last. 

51. Buy a penis extender and show me how much "bigger" it makes you feel. 

53. Fil up your car in just a G-string, bending over to give people a show. 

55. Treat yourself to a facial at a salon, just like a pampered sissy should. 

57. Schedule a waxing appointment and remove al that body hair. 

58. Visit a sex shop and buy the weirdest item you can find—send me proof. 

59. Ask a sex shop employee for the biggest dildo they sel , then buy it. 

60. Go makeup shopping for me and get everything on the list I send you. 

61. Go for a jog in public wearing a sports bra and leggings, no exceptions. 

62. Masturbate under the table at a restaurant, send me a video for proof. 

63. Sunbathe outside in a bikini while thinking about how ridiculous you look. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

64. Swim in a public pool or beach while wearing a revealing bikini. 

65. Go to a bra shop and request a proper bra fitting from the staff. 

66. Book an appointment at a tanning salon and get your skin glowing. 

67. Buy condoms at the chemist and ask for help finding the smal est size. 

68. Buy only a cucumber and lube from the grocery store, nothing else. 

69. Head to the gym in a matching set of lingerie and work out without shame. 

70. Wear lingerie to the gym, and make sure people notice your lacy attire. 

71. Buy jewelry for “someone special,” but tel the clerk it's for me. 

73. Buy the brightest, sexiest lingerie from the women’s section and wear it. 

74. Go commando to work today, no underwear al owed. 

75. Handcuff one arm to your bed and throw the key far—cal a friend for help. 

76. Handcuff yourself to a shopping cart and film yourself trying to shop. 

77. Have a ruined orgasm while wearing a cock cage and enjoy the frustration. 

78. Hump a stuffed animal until you cum al over it, then show me the mess. 

80. Cum on a mirror and lick it off, cleaning every drop with your tongue. 

84. Film your most humiliating moment and let me laugh at your misery. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

92. For today, the only name you can use for yourself is "bitch." 

93. Paint your fingernails bright yel ow, then flaunt them for everyone to see. 

94. Paint your toenails in my favorite color, and hope you guessed right. 

95. Color your toenails a hot pink and wear sandals in public to show them off. 

104. Put on a dog col ar and leash, crawling around on al fours for an hour. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

138. Cum into your morning coffee and drink it down, tel ing me how it tastes. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

153. Suck on a pacifier al day long, no matter where you are or who sees you. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

“fashion choice” while shopping. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

"pathetic" and "loser" somewhere. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

"This is what I deserve." 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

"masterpiece." 

"This is my new style." 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

"real man," while narrating how much better they are than you. 

389. Cal your least favorite restaurant and ask if they have a "loser special" 

available—record the conversation and send it to me. 

updating me each time you "speak" to one. 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**© Dominatrix Findom Shop | Do not resell or redistribute. **

👉** Get Free Stuff\! **👈** **

*Score free scripts when you sign up to our email list\! *

**Email list signup HERE ** 

* *

*Like this product? Get over 140,000 words and 46\+ products below. *

**Grab our Whole Store Bundle** **\(save 75%\) ** 

**© Dominatrix Findom Shop | Do not resell or redistribute. **

**SPH**

**SPH**

**SPH**

**Verbal Degradation**

**Measure against**

**Measure with ruler**

**small objects**

**Think of the nastiest**

**Knowing you have a**

## **putdowns and insults**

**Baby carrots, fries, **

**small dick is one**

**and abuse your spm**

## **your pinky or**

**thing, but to**

**until he is close to**

**anything else small**

## **ACTUALLY know how**

**tears. Then, deny**

## **and thin**

**small? **

**orgasm. **

**SPH**

**SPH**

**SPH**

**Pinky Wiggle **

**Ribbon **

## **Google Cock \#1**

**Clench your fist & hold**

**Tie ribbon around it, **

**Make him look at**

**your hand close to**

**maybe a nice pink**

**pictures of big cocks**

## **your face while**

**one? **

**and tell you how much **

**smiling and wiggle**

**bigger and thicker**

**your pinky at him. **

**they are than his. **

**SPH**

**SPH**

**SPH**

**Truth Time **

**Change his name**

## **Google Cock \#2**

**Have him tell you, how**

## **Maybe something**

**Google "what do**

**small, pathetic & **

**humiliating like "itty**

**woman think of small**

## **useless his lil member**

**bitty dicky" or go the**

**dicks". Read aloud**

**is until you are**

**whole hog and change**

**while you laugh and**

**satisfied. **

**his name to Stacy. **

## **snigger. **

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

## **SPH**

**SPH**

**SPH**

**SPH**

**Verbal Degradation**

**Verbal Degragation**

## **Compare**

**Well, it's too small to**

**Compare his cock to a**

**be considered a dick so**

**Compare his dick**

**dildo. **

## **an enlarged clitoris is**

**to previous lovers & **

**more appropriate. **

**partners. **

**SPH**

**SPH**

**SPH**

**Sharing is Caring**

**Active Listening**

**Truth**

**Call your friends and**

**Listen to her**

**Tell him how size does**

**tell them. Think one**

## **masturbate while she**

**matter, and women**

## **woman laughing at**

### **tells you that you don't**

## **only want large**

**you is bad? Try 2 or 3, **

**measure up. **

## **penises. **

**even 4? **

**SPH**

**SPH**

**SPH**

**Warm Air **

**Weights**

**Ice cold**

**Sarcastically try to**

## **Attach a ball weight to**

**Rub ice water on it to**

**help it grow by**

**the shaft and try**

**make it shrivel while**

**making it warm and**

**strech it to make it**

## **you laugh. **

**rubbing it to see if it**

**bigger. **

**can resemble**

**something that look**

## **like a dick. **

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

## **SPH**

**SPH**

**SPH**

**SPH**

**Laugh on Cam **

**Online Pics**

**Dress up **

## **Go on video sharing**

**Well, it's so small you**

## **site and show others**

**Take a picture online, **

**barely class as a man**

**his little member**

**on a reddit or another**

**so why should you**

## **while you all laugh. **

**"rate it" site and have**

**dress like one? Get**

## **others comment on its**

**those sissy knickers, **

**size. **

**stockings and frilly**

**dresses on. **

**SPH**

**SPH**

**SPH**

**Two fingers**

**Memory Game**

**Watch**

**Have him masturbate**

**Have him list all the**

**Have him watch you**

**using only two fingers. **

**women that rejected**

**pleasure yourself but**

**Real me use a whole**

## **him or refused to sleep**

### **don't let him**

**fist but then again, **

## **with him because they**

**masturabte. It's so**

**he's not a real man. **

**saw/ could sense his**

**ridiculously small, **

**tiny member. **

**why should he be**

## **allowed any pleasure**

**with it? **

**SPH**

**SPH**

**SPH**

**Truth Time **

**Get Hard**

**Lil Tuck **

**Have him try to justify**

**Make him get hard**

**Have him took it**

**him small penis. Yawn**

**and laugh at the**

**between his legs. It**

**and looked bored**

**stump. **

**practically makes him**

**while you listen to his**

**a woman so why not**

## **pathetic drivel. **

**act as one? **

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

## **SPH**

**SPH**

**SPH**

**SPH**

**Sit down **

**Push it **

**Online Time **

## **Real men stand up to**

**If it's small enough, **

**Find a guy with a big**

**pee. Little dick losers**

**which it likely is. Get**

**dick on a cam sharing**

**sit down. **

## **him to push his cock**

**site, masturbate with**

**inside his body and**

**him while he watches. **

**mock him for having a**

**pussy or extra belly**

**button. **

**SPH**

**SPH**

## **SPH**

### **T-shirt Time**

**Learning **

## **Tweeze the dick **

### **Wear a T-Shirt saying**

**Make him read a**

## **Have him masturbate**

**"I only Fuck Men with**

**pamphlet on small**

## **with a tweezers. Since**

**Big Dicks" **

## **penises. **

### **he can't get a whole**

**hand around it, this**

**should work just fine? **

**SPH**

**SPH**

**SPH**

**Confession **

**Panties**

## **Phone Call**

**Have him tell you, how**

**He doesn't deserve**

## **Call a friend and talk**

### **he can't get women to**

**male briefs, make him**

**about his itty-bitty**

**sleep with him and his**

## **wear panties. **

### **dicky like he's not**

**only relief is wanking. **

## **there. **

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

## **SPH**

**SPH**

**SPH**

**SPH**

**Satisfy yourself \#1**

**Satisfy yourself \#2**

**Chastity **

**Lock up his member**

**Have him watch you**

**Have him watch you**

**for however long you**

**fuck another man with**

## **fuck another man with**

**decide. It's not useful**

## **a large penis. **

**a large penis, however, **

**to anyone so put it**

**he is not allowed to**

**away. **

**pleasure himself. **

**SPH**

**SPH**

**SPH**

**Ouch **

**Truth **

**Send Nudes**

**His cock should be**

## **Make him tell you his**

**Send a pic of his small**

**punished for being so**

## **most humiliationg**

**dick to your friend/s**

**small and useless. Spit**

**Small Dick experience. **

**and laugh at it**

**on it and slap it**

**together. **

**around. **

**SPH**

**SPH**

**SPH**

**Measure Up **

**Camshare**

**Pay up **

## **Measure his teeny tiny**

**Have him go on a cam**

**You need sex, but not**

**member with a ruler**

**share site and have his**

**with that useless dick. **

**and take photo**

**dick rated by different**

**Have him pay you**

**evidence. **

## **people. **

**$200 for your pussy or**

**go out and cheat on**

## **the loser. **

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

**SPH**

## **SPH**

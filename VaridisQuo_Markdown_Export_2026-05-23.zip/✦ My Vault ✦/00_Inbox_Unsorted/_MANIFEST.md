---
class: B
---

# Substance Content Sweep — Manifest (v2, stricter)

Scanned: 2248 markdown files.
Matched: 71 files with real substance content.
Rejected as incidental: 588 files that matched substance keywords but only on incidental terms (tea, coffee, wine, smoke, drug-as-metaphor, etc.).

## Inclusion rule (v2)

A file is included if AND ONLY IF:

- The filename matches a STRONG keyword (specific compound or pharmacological term), OR
- The body contains 3+ STRONG matches.

STRONG keywords are specific compounds (psilocybin, Adderall, fluoxetine, ketamine, etc.), specific named medications, and real pharmacological vocabulary (neurotransmitter, receptor agonist, microdose, half-life, blood-brain barrier, etc.).

WEAK keywords (tea, coffee, wine, beer, smoke, spirit, ceremony, drug-as-metaphor) are tracked for context but do NOT trigger inclusion on their own. This excludes Tolstoy, song lyrics, scripture mentioning wine, business notes mentioning coffee, and casual conversation about drinks.

## Matched files (ranked by STRONG hit count, then density)

| File | Strong hits | Density/1k | Words | Top strong keywords |
|---|---:|---:|---:|---|
| `vaults/library-of-alexandria/9C_prompts/9C-130_nootropic-profiles-iterative-pretty-final3.md` | 851 | 18.0 | 47,362 | half-life×276, dependence×122, dopamine×39 |
| `vaults/library-of-alexandria/9C_prompts/9C-128_nootropic-profiles-iterative-105-reva.md` | 574 | 18.1 | 31,637 | half-life×114, psychoactive×107, dependence×102 |
| `vaults/library-of-alexandria/9C_prompts/9C-78_books-about-nootropics-arushanian.md` | 553 | 10.0 | 55,090 | nootropic×190, melatonin×84, piracetam×59 |
| `vaults/library-of-alexandria/27_misc/27-41_spravato-pi.md` | 489 | 34.0 | 14,384 | spravato×301, esketamine×89, ketamine×26 |
| `vaults/library-of-alexandria/9C_prompts/9C-83_deep-dive-substance.md` | 454 | 21.2 | 21,432 | benzodiazepine×34, withdrawal×30, xanax×29 |
| `vaults/library-of-alexandria/12_influence-atlas/12-23_intech-the-neuropsychopharmacology-of-stimulants.md` | 404 | 40.1 | 10,083 | amphetamine×132, dopamine×118, methylphenidate×53 |
| `vaults/library-of-alexandria/9C_prompts/9C-129_nootropic-profiles-iterative-140-reva.md` | 260 | 23.0 | 11,310 | psychoactive×37, half-life×35, dependence×34 |
| `vaults/library-of-alexandria/9C_prompts/9C-127_nootropic-compendium-pretty-plainurls.md` | 187 | 18.0 | 10,366 | nootropic×44, neurotransmitter×10, lithium×10 |
| `vaults/library-of-alexandria/12_influence-atlas/12-43_all-hiv-2018-feb.md` | 149 | 10.9 | 13,639 | hrt×12, pharmacology×5, ketamine×4 |
| `vaults/library-of-alexandria/12_influence-atlas/12-110_017078s042lbl.md` | 117 | 23.0 | 5,095 | dexedrine×67, dextroamphetamine×15, amphetamine×15 |
| `vaults/library-of-alexandria/9C_prompts/9C-125_nootropic-compendium.md` | 109 | 13.4 | 8,117 | nootropic×23, neurotransmitter×11, dopamine×9 |
| `vaults/library-of-alexandria/27_misc/27-55_kotowski-lsd-derivatives-current-legal.md` | 105 ★ | 28.3 | 3,714 | lsd×72, psychoactive×16, lysergic×7 |
| `vaults/library-of-alexandria/31_adjudications/31-33_lsd-the-synthetic-heir.md` | 97 | 28.7 | 3,382 | lsd×63, psilocybin×10, lysergic×6 |
| `vaults/library-of-alexandria/31_adjudications/31-28_amanita-the-siberian-ascent.md` | 97 | 26.1 | 3,711 | amanita×36, muscaria×22, datura×7 |
| `vaults/library-of-alexandria/31_adjudications/31-32_psilocybin-the-confirmation.md` | 90 | 26.9 | 3,349 | psilocybin×49, psilocin×10, psychedelic×6 |
| `vaults/library-of-alexandria/9C_prompts/9C-97_master-substance-index-deep-dive.md` | 82 | 49.6 | 1,654 | ketamine×5, dependence×4, codeine×4 |
| `vaults/library-of-alexandria/31_adjudications/31-30_nutmeg-the-control-case.md` | 77 | 32.2 | 2,389 | nutmeg×39, psychoactive×8, datura×6 |
| `vaults/library-of-alexandria/31_adjudications/31-36_datura-cultural-and-historical-survey.md` | 69 | 17.9 | 3,851 | datura×55, pharmacology×3, shamanic×2 |
| `vaults/library-of-alexandria/31_adjudications/31-31_salvia-the-wheel-vision.md` | 67 | 20.7 | 3,235 | opioid×12, salvia divinorum×8, datura×8 |
| `vaults/library-of-alexandria/31_adjudications/31-34_synthesis-cumulative-argument.md` | 63 | 25.9 | 2,433 | datura×5, lsd×5, pharmacology×5 |
| `vaults/library-of-alexandria/12_influence-atlas/12-8_3920p.md` | 58 | 31.4 | 1,845 | khat×51, tobacco×2, cocaine×2 |
| `vaults/library-of-alexandria/31_adjudications/31-26_galanthus-the-antidote.md` | 56 | 18.7 | 2,987 | datura×20, galanthus×19, acetylcholine×11 |
| `vaults/library-of-alexandria/12_influence-atlas/12-32_strattera-side-effects-uses-dosage.md` | 55 | 4.1 | 13,391 | maoi×8, paroxetine×7, fluoxetine×7 |
| `vaults/library-of-alexandria/12_influence-atlas/12-149_shopping-list-250923-191237.md` | 51 | 17.0 | 2,999 | methylphenidate×4, benzodiazepine×3, mdma×3 |
| `vaults/library-of-alexandria/31_adjudications/31-29_blue-lotus-the-egyptian-apparatus.md` | 51 | 15.0 | 3,404 | blue lotus×24, pharmacology×7, entheogen×3 |
| `vaults/library-of-alexandria/12_influence-atlas/12-145_piis.md` | 49 | 5.2 | 9,336 | datura×10, hallucinogenic×8, tobacco×8 |
| `vaults/library-of-alexandria/31_adjudications/31-27_lsa-the-eleusinian-descent.md` | 48 | 15.9 | 3,027 | datura×10, lsd×9, galanthus×5 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-309_pdf-reorg-move-map.md` | 47 | 2.2 | 21,005 | psychedelic×24, kratom×11, lsd×6 |
| `vaults/library-of-alexandria/27_misc/27-48_adhd-medication-conversion.md` | 45 | 41.6 | 1,081 | amphetamine×17, methylphenidate×11, dextroamphetamine×6 |
| `vaults/library-of-alexandria/12_influence-atlas/12-5_gaba.md` | 43 | 87.0 | 494 | methylphenidate×3, dopamine×3, ketamine×3 |
| `vaults/library-of-alexandria/31_adjudications/31-35_datura-preface-and-framing.md` | 42 | 21.4 | 1,965 | datura×30, acetylcholine×3, psychedelic×2 |
| `vaults/library-of-alexandria/31_adjudications/31-38_datura-the-three-witnesses.md` | 38 | 16.6 | 2,288 | datura×30, psychedelic×7, shamanic×1 |
| `vaults/library-of-alexandria/attachments/liber-novus-sessions/2026-05-08_plant-teachers/README.md` | 36 | 43.2 | 833 | datura×12, nutmeg×4, psilocybin×4 |
| `00_meta/CHANGELOG.md` | 36 | 3.1 | 11,533 | datura×22, galanthus×3, amanita×2 |
| `vaults/library-of-alexandria/31_adjudications/31-37_datura-the-psychological-anatomy.md` | 35 | 7.8 | 4,473 | datura×34, psychedelic×1 |
| `vaults/library-of-alexandria/31_adjudications/31-40_datura-the-wilderness-frame-and-the-empty-city.md` | 34 | 12.8 | 2,646 | datura×30, psychedelic×3, shamanic×1 |
| `vaults/library-of-alexandria/31_adjudications/31-39_datura-the-elements-that-recur.md` | 33 | 9.3 | 3,544 | datura×33 |
| `vaults/library-of-alexandria/9C_prompts/9C-87_hypnagogia-and-creative-thinking-magazine.md` | 32 | 8.4 | 3,810 | acetylcholine×16, serotonin×3, dopamine×3 |
| `vaults/library-of-alexandria/12_influence-atlas/12-25_kratom.md` | 29 | 55.8 | 520 | kratom×24, addiction×3, withdrawal×1 |
| `vaults/library-of-alexandria/9C_prompts/9C-86_hypnagogia-and-creative-thinking.md` | 29 | 9.2 | 3,151 | acetylcholine×13, serotonin×3, dopamine×3 |
| `vaults/library-of-alexandria/31_adjudications/31-5_storage-and-stored-source.md` | 29 | 7.8 | 3,716 | addiction×29 |
| `vaults/library-of-alexandria/12_influence-atlas/12-146_polysubstance-use-chart-2-0-with.md` | 27 | 58.4 | 462 | cannabis×5, ketamine×5, mdma×5 |
| `vaults/library-of-alexandria/31_adjudications/31-19_03c-convergence-log.md` | 20 | 7.7 | 2,586 | datura×15, deliriant×3, withdrawal×2 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-165_ct-watermelon-moon-shrooms-lab.md` | 19 | 10.1 | 1,877 | dmt×9, psilocybin×4, psilocin×4 |
| `vaults/library-of-alexandria/31_adjudications/0.3_HUB.md` | 18 | 30.1 | 598 | datura×9, amanita×2, galanthus×1 |
| `vaults/library-of-alexandria/9C_prompts/9C-132_nootropic-profiles-iterative-75-reva.md` | 18 | 12.8 | 1,407 | nootropic×18 |
| `vaults/library-of-alexandria/12_influence-atlas/12-127_drug-interactions-what-you-should.md` | 18 | 10.1 | 1,780 | drug interaction×10, nicotine×5, tobacco×1 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-219_file-name.md` | 18 | 6.5 | 2,784 | withdrawal×18 |
| `vaults/library-of-alexandria/27_misc/27-33_november-2025-bank-statement.md` | 16 | 6.2 | 2,589 | withdrawal×16 |
| `vaults/library-of-alexandria/12_influence-atlas/12-153_switchguide-2017-oct.md` | 15 | 8.1 | 1,841 | methadone×3, hrt×2, duloxetine×2 |
| `vaults/library-of-alexandria/31_adjudications/31-25_datura-the-refused.md` | 13 | 30.9 | 421 | datura×12, psychedelic×1 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-214_downloaded-document.md` | 11 | 8.1 | 1,353 | withdrawal×11 |
| `vaults/library-of-alexandria/12_influence-atlas/12-13_cafergot.md` | 10 | 4.4 | 2,261 | nicotine×3, amphetamine×2, cocaine×2 |
| `vaults/library-of-alexandria/9C_prompts/9C-115_compendium-of-metaphysical-entities-and.md` | 10 | 3.7 | 2,721 | datura×8, deliriant×2 |
| `vaults/library-of-alexandria/12_influence-atlas/12-207_1p-lsd.md` | 9 ★ | 15.6 | 576 | lsd×8, lysergic×1 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-217_basss.md` | 8 | 11.2 | 715 | withdrawal×8 |
| `vaults/library-of-alexandria/9_reference-compendia/9-12_nootropic-evidence-atlas.md` | 7 | 33.0 | 212 | nootropic×5, pharmacology×1, half-life×1 |
| `vaults/library-of-alexandria/10_creative-mythic/10-14_psychedelic-odyssey-into-the-mind-s-eternal-wheel.md` | 7 | 5.4 | 1,298 | psychedelic×5, shamanic×1, ecstasy×1 |
| `vaults/library-of-alexandria/9_reference-compendia/9-13_psychoactive-risk-matrix.md` | 6 | 44.8 | 134 | psychoactive×5, dependence×1 |
| `vaults/library-of-alexandria/9C_prompts/9C-114_compendium-of-metaphysical-entities-and.md` | 6 | 4.8 | 1,254 | datura×5, deliriant×1 |
| `vaults/library-of-alexandria/31_adjudications/31-23_the-datura-sequence-threshold-companion-daylight-return.md` | 6 ★ | 2.7 | 2,226 | datura×5, trip report×1 |
| `vaults/library-of-alexandria/31_adjudications/31-21_the-cigarette-i-was-not-smoking.md` | 6 | 2.2 | 2,690 | datura×4, lsd×1, dmt×1 |
| `vaults/library-of-alexandria/31_adjudications/31-13_the-mechanical-wheel-of-spiritual-debt.md` | 5 | 3.1 | 1,625 | psychedelic×3, psilocybin×2 |
| `vaults/library-of-alexandria/9C_prompts/9C-116_compendium-of-metaphysical-entities-and.md` | 5 | 2.7 | 1,850 | datura×3, deliriant×2 |
| `vaults/library-of-alexandria/9C_prompts/9C-133_nootropic-profiles-iterative-90-reva.md` | 5 | 2.6 | 1,937 | nootropic×3, melatonin×1, neurotransmitter×1 |
| `vaults/library-of-alexandria/12_influence-atlas/12-130_ews-000002.md` | 4 | 6.5 | 618 | morphine×1, codeine×1, opiate×1 |
| `vaults/library-of-alexandria/9C_prompts/9C-131_nootropic-profiles-iterative-33-revb.md` | 3 | 15.9 | 189 | nootropic×3 |
| `vaults/library-of-alexandria/12_influence-atlas/12-152_supplement-label-pack-from-pdf.md` | 3 | 4.2 | 722 | nootropic×1, dopamine×1, neurotransmitter×1 |
| `vaults/library-of-alexandria/9C_prompts/9C-126_nootropic-compendium-pretty-linked.md` | 3 | 3.0 | 1,016 | nootropic×3 |
| `vaults/library-of-alexandria/25_scans/25-22_2025-10-01.md` | 3 | 2.2 | 1,348 | withdrawal×3 |
| `vaults/library-of-alexandria/2_thomas-profile/2-25_childhood-memory-wind-tar-hanging-paracosm.md` | 3 | 2.2 | 1,354 | ecstasy×2, serotonin×1 |

★ = filename also matches a STRONG keyword.

## Files excluded as incidental

These files matched substance keywords but only on WEAK terms (wine, tea, coffee, etc.). They are mentioned for transparency but NOT included in this zip. Top 20:

| File | Weak hits | Top weak keywords |
|---|---:|---|
| `vaults/library-of-alexandria/9A_reference-payload/9A-0002_fragments-registry.md` | 4514 | high×4410, coffee×26, smoke×15 |
| `vaults/library-of-alexandria/9C_prompts/9C-136_1012movies.md` | 2520 | high×2511, smoking×3, hangover×3 |
| `vaults/library-of-alexandria/9C_prompts/9C-47_backrooms-codex-prompts-all-print.md` | 1780 | high×1762, spirits×12, substance×5 |
| `vaults/library-of-alexandria/12_influence-atlas/12-3_bazingaa-b0x-0ffice-full-1029.md` | 998 | high×995, substance×1, smoking×1 |
| `vaults/library-of-alexandria/9A_reference-payload/9A-0000_film-registry.md` | 835 | high×824, hangover×4, spirits×3 |
| `vaults/library-of-alexandria/9C_prompts/9C-135_amazing-movies.md` | 780 | high×777, hangover×1, smoking×1 |
| `vaults/library-of-alexandria/30_messaging/30-4_nickolle-whatsapp.md` | 180 | high×45, dose×32, alcohol×26 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-299_external-brain-quiz-1000-obsidian.md` | 155 | high×141, substance×10, alcohol×2 |
| `vaults/library-of-alexandria/12_influence-atlas/12-81_merged-100-playlist-super-arc.md` | 148 | high×52, ceremony×42, coffee×24 |
| `vaults/library-of-alexandria/9C_prompts/9C-124_herbal-tea-field-guide-styled.md` | 123 | tea×66, caffeine×20, high×14 |
| `vaults/library-of-alexandria/9C_prompts/9C-123_herbal-tea-field-guide.md` | 120 | tea×66, caffeine×19, high×16 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-113_shs-5mile-client-list-1580s500w.md` | 118 | high×80, coffee×29, beer×5 |
| `vaults/library-of-alexandria/24_nsfw/24-27_all-of-sissy.md` | 110 | high×64, coffee×20, wine×8 |
| `vaults/library-of-alexandria/12_influence-atlas/12-248_distilled-resources-combined-registry.md` | 106 | high×59, substance×20, mushroom×14 |
| `vaults/library-of-alexandria/12_influence-atlas/12-82_music-library-refactor-clean-color.md` | 106 | high×55, coffee×21, drunk×7 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-41_sharphousesolutions-masterpacket-combined-expanded.md` | 88 | high×88 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-297_external-brain-quiz-1000-compact.md` | 78 | high×71, substance×5, alcohol×1 |
| `vaults/library-of-alexandria/9C_prompts/9C-142_chatgpt.md` | 78 | high×77, coffee×1 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-8_sharp-house-master-binder.md` | 69 | high×65, coffee×2, tea×1 |
| `vaults/library-of-alexandria/5A_sharp-house-solutions/5A-328_client-prospecting-within-three-miles.md` | 68 | high×43, coffee×23, beer×2 |

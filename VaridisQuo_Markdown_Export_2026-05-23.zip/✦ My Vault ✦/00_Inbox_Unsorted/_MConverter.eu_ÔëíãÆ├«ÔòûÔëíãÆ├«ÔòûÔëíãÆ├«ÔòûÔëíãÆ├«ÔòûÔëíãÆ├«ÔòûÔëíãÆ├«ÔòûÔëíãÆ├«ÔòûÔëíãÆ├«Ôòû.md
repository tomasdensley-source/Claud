---
class: B
---
How To 

Feminize Him 

\[play safe, sane and consensual\] 

* *

*January 2023 – Ver. 1.1* 

**Why Feminize? **

**Ways To Objectify Him** 

o Dress him like a slut 

o Offer him $5 in exchange for his services 

o Pinch his butt 

o Wolf whistle as he walks by 

o Tell him that he is just a sex toy to get you off. 

Page 3 

**Role Playing the Housewife/Whore** 

Page 4 

o Make him feel like a whore by trading him out to other Mistresses. 

**Ways to Humiliate** 

o Use negative labels like whore, slut, cocksucker, boy, girl, bitch, etc. 

o Treat him like a child or be condescending. 

Page 5 

o Punish or discipline him publicly. 

o Make him do things which he finds humiliating or taboo. 

**Mildly Painful Pleasures** 

o Nipple pinching 

o Cropping \(lightly\) 

Page 6 

o Flicking nipples, cock, etc with a finger o Mildly squeezing genitals 

o Nipple clamps 

o Cock leash i.e. leather cock harness with dog lead o Penetration of his ass with a finger or two, a small butt plug, or a small dildo 5. **Vulnerability** -- similar to pain in that men are socialized to be invulnerable. But men have a great need to let go of their control and be vulnerable and get in touch with a more feminine side. I think it is helpful to them in connecting with their emotions and in connecting with others. But they are so caught up in the rigid role that society expects of them that they need a safe place in which to let go which does not spoil their image in real life. They often do not want to let go of control in front of their wife or girlfriend. Being feminized gets men in touch with that vulnerability element and they will express emotions and feelings that they don't express normally. It allows them to experience a more feminine type of pleasure which is about opening up and receiving rather than conquering and penetrating. 

**Ways to Help Men to be Vulnerable** 

o Treat him like a girl in every way. Help him to feel feminine. 

Page 7 

o Emphasize the fact that you are going to "take" him and not vice versa. 

o Get him to spread his legs like a slut. 

o Call his ass a pussy and his cock a clit. 

I feel that the feminine and masculine orgasms are very different in their nature. When I am role-playing as a male, I imagine my clit growing and becoming elongated. I imagine myself actually penetrating the sub with my clit and the strapon just becoming the substitute or proxy for my Page 8 

"innie" orgasm is much different than that of an "outie" orgasm. 

Page 9 

Page 10 

The Easy Way to 

Sissygasm 

\[play safe, sane and consensual\] 

*February 2023 – Ver. 1.1* 

Let’s talk all about it here, without any “taboos”\! 

**What Is a Sissygasm? **

**The Power of Feminine Sexuality **

“femme fatale” but like a goddess\! 

**How Can it Boost Your Feminine Energy? **

**How to Get There? **

**Practice, Practice, and Practice Girl\! **

**Safety Is the Number One Mistress **

Page 4 

**Prostate Gland **

**Clean up and Prepare **

**BE GENTLE, GO SLOW, AND USE A GENEROUS AMOUNT OF LUBE. **

**Comfortable Positions and Toys **

Page 6 

Page 7
